package com.planon.app.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public final class ImageUtil {
    private ImageUtil() {
    }

    private static final int MAX_SIDE = 1600;

    /** 카메라 촬영 결과를 저장할 임시 파일 (FileProvider 경로: cache/images) */
    public static File newCameraFile(Context context) throws IOException {
        File dir = new File(context.getCacheDir(), "images");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("임시 폴더를 만들 수 없어요");
        return new File(dir, "camera_" + System.currentTimeMillis() + ".jpg");
    }

    /**
     * 갤러리/카메라 이미지를 업로드용으로 줄여서 JPEG 파일로 저장합니다.
     * (백그라운드 스레드에서 호출하세요)
     */
    public static File prepareForUpload(Context context, Uri uri) throws IOException {
        ImageDecoder.Source source = ImageDecoder.createSource(context.getContentResolver(), uri);
        Bitmap bitmap = ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
            int w = info.getSize().getWidth();
            int h = info.getSize().getHeight();
            int longest = Math.max(w, h);
            if (longest > MAX_SIDE) {
                float scale = MAX_SIDE / (float) longest;
                decoder.setTargetSize(Math.round(w * scale), Math.round(h * scale));
            }
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
        File dir = new File(context.getCacheDir(), "images");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("임시 폴더를 만들 수 없어요");
        File out = new File(dir, "upload_" + System.currentTimeMillis() + ".jpg");
        try (FileOutputStream fos = new FileOutputStream(out)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos);
        }
        bitmap.recycle();
        return out;
    }

    public static boolean isValidImage(File f) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        return o.outWidth > 0;
    }
}
