package com.planon.app.ui.notification;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.AppNotification;
import com.planon.app.ui.verify.VerifyReviewActivity;
import com.planon.app.util.Async;
import com.planon.app.util.DateUtil;

import java.util.ArrayList;
import java.util.List;

/** 알림함: 투표 요청, 미인정 표, 결과, 주간 결산, 레벨 업 … (휴대폰 알림을 놓쳐도 여기서 볼 수 있음) */
public class NotificationActivity extends AppCompatActivity {

    private final Repository repo = RepositoryProvider.get();
    private final List<AppNotification> items = new ArrayList<>();
    private Adapter adapter;
    private TextView textEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.getMenu().add("모두 읽음").setOnMenuItemClickListener(item -> {
            Async.run(() -> {
                repo.markAllNotificationsRead();
                return true;
            }, ok -> load(), this::toast);
            return true;
        }).setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);

        textEmpty = findViewById(R.id.text_empty);
        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter();
        rv.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        Async.run(repo::getNotifications, list -> {
            if (isDestroyed()) return;
            items.clear();
            items.addAll(list);
            adapter.notifyDataSetChanged();
            textEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        }, this::toast);
    }

    private void open(AppNotification n) {
        if (!n.read) {
            n.read = true;
            adapter.notifyDataSetChanged();
            Async.run(() -> {
                repo.markNotificationRead(n.id);
                return true;
            }, ok -> { }, msg -> { });
        }
        if (n.planId != null) startActivity(VerifyReviewActivity.open(this, n.planId));
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    /** "2026-10-28T23:05" → 오늘이면 "23:05", 아니면 "10/27(화)" */
    static String when(String createdAt) {
        if (createdAt == null || createdAt.length() < 16) return "";
        String date = createdAt.substring(0, 10);
        if (date.equals(DateUtil.todayStr())) return createdAt.substring(11, 16);
        try {
            return DateUtil.shortKorean(DateUtil.parse(date));
        } catch (Exception e) {
            return date;
        }
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            final View dot;
            final TextView title, body, time;

            VH(View v) {
                super(v);
                dot = v.findViewById(R.id.dot_unread);
                title = v.findViewById(R.id.text_title);
                body = v.findViewById(R.id.text_body);
                time = v.findViewById(R.id.text_time);
            }
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_notification, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            AppNotification n = items.get(position);
            h.dot.setVisibility(n.read ? View.INVISIBLE : View.VISIBLE);
            h.title.setText(n.title);
            h.title.setTextColor(ContextCompat.getColor(NotificationActivity.this, n.read ? R.color.muted : R.color.ink));
            h.body.setText(n.body);
            h.time.setText(when(n.createdAt));
            h.itemView.setOnClickListener(v -> open(n));
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }
}
