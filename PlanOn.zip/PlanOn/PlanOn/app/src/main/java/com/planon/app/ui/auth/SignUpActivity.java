package com.planon.app.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.util.Async;

public class SignUpActivity extends AppCompatActivity {

    public static final String EXTRA_LOGIN_ID = "login_id";

    private final Repository repo = RepositoryProvider.get();

    private TextInputLayout inputId, inputPw, inputPw2, inputNick;
    private TextInputEditText editId, editPw, editPw2, editNick;
    private MaterialButton btnSignUp;

    /** 중복확인을 통과한 아이디 (아이디를 고치면 다시 확인해야 함) */
    private String checkedId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        inputId = findViewById(R.id.input_login_id);
        inputPw = findViewById(R.id.input_password);
        inputPw2 = findViewById(R.id.input_password_confirm);
        inputNick = findViewById(R.id.input_nickname);
        editId = findViewById(R.id.edit_login_id);
        editPw = findViewById(R.id.edit_password);
        editPw2 = findViewById(R.id.edit_password_confirm);
        editNick = findViewById(R.id.edit_nickname);
        btnSignUp = findViewById(R.id.btn_signup);

        editId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                checkedId = null;
                inputId.setError(null);
                inputId.setHelperText("영문, 숫자 4~16자");
            }
        });

        findViewById(R.id.btn_check_id).setOnClickListener(v -> checkId());
        btnSignUp.setOnClickListener(v -> signUp());
    }

    private void checkId() {
        String id = text(editId);
        if (!id.matches("^[A-Za-z0-9]{4,16}$")) {
            inputId.setError("영문, 숫자 4~16자로 입력해 주세요");
            return;
        }
        Async.run(() -> repo.isLoginIdAvailable(id), available -> {
            if (available) {
                checkedId = id;
                inputId.setError(null);
                inputId.setHelperText("사용 가능한 아이디입니다.");
            } else {
                checkedId = null;
                inputId.setError("이미 사용 중인 아이디예요");
            }
        }, this::toast);
    }

    private void signUp() {
        String id = text(editId);
        String pw = text(editPw);
        String pw2 = text(editPw2);
        String nick = text(editNick);

        boolean ok = true;
        if (checkedId == null || !checkedId.equals(id)) {
            inputId.setError("아이디 중복확인을 해 주세요");
            ok = false;
        }
        if (pw.length() < 8 || !pw.matches(".*[A-Za-z].*") || !pw.matches(".*[0-9].*")) {
            inputPw.setError("8자 이상, 영문과 숫자를 함께 써 주세요");
            ok = false;
        } else {
            inputPw.setError(null);
        }
        if (!pw.equals(pw2)) {
            inputPw2.setError("비밀번호가 일치하지 않아요");
            ok = false;
        } else {
            inputPw2.setError(null);
        }
        if (nick.isEmpty()) {
            inputNick.setError("닉네임을 입력해 주세요");
            ok = false;
        } else {
            inputNick.setError(null);
        }
        if (!ok) return;

        btnSignUp.setEnabled(false);
        Async.run(() -> repo.signUp(id, pw, nick), user -> {
            Toast.makeText(this, "가입이 완료되었어요. 로그인해 주세요.", Toast.LENGTH_SHORT).show();
            Intent data = new Intent();
            data.putExtra(EXTRA_LOGIN_ID, id);
            setResult(RESULT_OK, data);
            finish();
        }, msg -> {
            btnSignUp.setEnabled(true);
            toast(msg);
        });
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private static String text(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }
}
