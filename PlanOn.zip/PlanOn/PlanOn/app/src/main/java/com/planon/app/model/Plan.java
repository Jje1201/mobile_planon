package com.planon.app.model;

import java.util.ArrayList;
import java.util.List;

/** 일정 한 건 + 인증 상태 (서버 PlanDto 와 필드 이름이 같아야 합니다) */
public class Plan {
    /** 아직 인증 전 */
    public static final String TODO = "TODO";
    /** 인증 사진 제출, 파티원 투표 중 (결과는 자정에 확정) */
    public static final String VOTING = "VOTING";
    /** 자정 집계에서 인정 → +10P */
    public static final String APPROVED = "APPROVED";
    /** 자정 집계에서 미인정이 인정보다 많음 → 미수행, −10P */
    public static final String REJECTED = "REJECTED";
    /** 날짜가 지나도록 인증하지 않음 → 0P */
    public static final String MISSED = "MISSED";

    public long id;
    public long userId;
    public String ownerNickname;
    public int ownerCharacterId;
    /** 작성자 캐릭터 성장 단계 1~5 */
    public int ownerStage = 1;

    /** yyyy-MM-dd */
    public String date;
    public String title;
    /** HH:mm, 없으면 null */
    public String time;
    public String category;
    public String memo;

    public String status = TODO;
    /** 인증 사진들 (로컬 모드: 파일 경로, 서버 모드: 이미지 URL) */
    public List<String> imageUrls = new ArrayList<>();
    /** 사진별 id·올린 시각·수정 가능 여부 (바꾸기·지우기용) */
    public List<PlanPhoto> photos = new ArrayList<>();
    public String comment;
    public String submittedAt;

    /** 사진 등록·추가 마감 (yyyy-MM-ddTHH:mm, 일정 날짜 23:30) */
    public String photoDeadline;
    /** 투표 마감 = 결과 확정 시각 (다음 날 00:00) */
    public String voteDeadline;
    public boolean finalized;

    /** 확정 뒤에만 채워짐 (본인에게는 투표 중에도 미인정 수를 보여줌) */
    public int approveCount;
    public int rejectCount;
    /** 투표한 사람 수 / 투표권이 있는 사람 수 (본인 제외, 제출 시점의 파티원) */
    public int votedCount;
    public int voterCount;
    /** 내 투표: 1 인정, -1 미인정, 0 아직 안 함 */
    public int myVote;

    public boolean canSubmit;
    public boolean canAddPhotos;
    public boolean canVote;

    /** 검토 화면에서만 채워짐 */
    public List<VoteInfo> votes;

    public boolean isStatus(String s) {
        return s.equals(status);
    }

    public boolean isFinished() {
        return isStatus(APPROVED) || isStatus(REJECTED) || isStatus(MISSED);
    }

    public String firstImage() {
        return imageUrls == null || imageUrls.isEmpty() ? null : imageUrls.get(0);
    }
}
