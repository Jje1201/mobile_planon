package com.planon.app.ui.verify;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.Plan;
import com.planon.app.util.Async;
import com.planon.app.util.DateUtil;
import com.planon.app.util.ImageUtil;
import com.planon.app.util.LevelRule;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 내 일정 수행 인증.
 * - 처음 제출: 사진 1~5장 + 코멘트 (일정 당일 23:30 까지)
 * - 사진 추가 모드: 이미 제출한 인증에 사진을 보탬 (미인정을 받았을 때 등, 23:30 까지, 합계 10장)
 */
public class VerifyUploadActivity extends AppCompatActivity {

    public static final String EXTRA_PLAN_ID = "plan_id";
    public static final String EXTRA_ADD_MODE = "add_mode";

    public static Intent addPhotos(Context context, long planId) {
        Intent i = new Intent(context, VerifyUploadActivity.class);
        i.putExtra(EXTRA_PLAN_ID, planId);
        i.putExtra(EXTRA_ADD_MODE, true);
        return i;
    }

    private final Repository repo = RepositoryProvider.get();

    private long planId;
    private boolean addMode;
    /** 이번에 올릴 사진 (줄인 JPEG) */
    private final List<File> photos = new ArrayList<>();
    /** 이번에 더 올릴 수 있는 장수 */
    private int maxThisTime = LevelRule.MAX_FIRST_PHOTOS;
    private Uri cameraUri;

    private LinearLayout containerPhotos;
    private View boxPhoto, progressPhoto;
    private TextView textPhotoCount;
    private MaterialButton btnSubmit;
    private TextInputEditText editComment;

    private final ActivityResultLauncher<PickVisualMediaRequest> pickImages = registerForActivityResult(
            new ActivityResultContracts.PickMultipleVisualMedia(LevelRule.MAX_FIRST_PHOTOS), uris -> {
                if (uris == null) return;
                List<Uri> list = new ArrayList<>(uris);
                int room = maxThisTime - photos.size();
                if (list.size() > room) {
                    toast("사진은 " + maxThisTime + "장까지 고를 수 있어요. 앞의 " + room + "장만 넣었어요");
                    list = list.subList(0, Math.max(0, room));
                }
                usePhotos(list);
            });

    private final ActivityResultLauncher<Uri> takePicture = registerForActivityResult(
            new ActivityResultContracts.TakePicture(), success -> {
                if (Boolean.TRUE.equals(success) && cameraUri != null) {
                    List<Uri> one = new ArrayList<>();
                    one.add(cameraUri);
                    usePhotos(one);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_upload);

        planId = getIntent().getLongExtra(EXTRA_PLAN_ID, 0);
        addMode = getIntent().getBooleanExtra(EXTRA_ADD_MODE, false);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        if (addMode) toolbar.setTitle("인증 사진 추가");

        containerPhotos = findViewById(R.id.container_photos);
        boxPhoto = findViewById(R.id.box_photo);
        progressPhoto = findViewById(R.id.progress_photo);
        textPhotoCount = findViewById(R.id.text_photo_count);
        btnSubmit = findViewById(R.id.btn_submit);
        editComment = findViewById(R.id.edit_comment);
        if (addMode) {
            findViewById(R.id.layout_comment).setVisibility(View.GONE);
            btnSubmit.setText("사진 추가하기");
        }

        boxPhoto.setOnClickListener(v -> choosePhotoSource());
        btnSubmit.setOnClickListener(v -> submit());

        loadPlan();
    }

    private void loadPlan() {
        Async.run(() -> repo.getVerification(planId), this::bindPlan, msg -> {
            toast(msg);
            finish();
        });
    }

    private void bindPlan(Plan p) {
        if (isDestroyed()) return;
        StringBuilder meta = new StringBuilder(DateUtil.korean(DateUtil.parse(p.date)));
        if (p.time != null) meta.append(" · ").append(p.time);
        if (p.category != null) meta.append(" · ").append(p.category);
        ((TextView) findViewById(R.id.text_meta)).setText(meta);
        ((TextView) findViewById(R.id.text_title)).setText(p.title);
        TextView memo = findViewById(R.id.text_memo);
        if (p.memo != null) memo.setText("인증 메모: " + p.memo);
        else memo.setVisibility(View.GONE);

        String info;
        if (addMode) {
            if (!p.canAddPhotos) {
                toast(p.isStatus(Plan.VOTING) ? "사진 추가는 23:30 까지만 할 수 있어요" : "검토 중인 인증에만 사진을 추가할 수 있어요");
                finish();
                return;
            }
            int have = p.imageUrls == null ? 0 : p.imageUrls.size();
            maxThisTime = Math.min(LevelRule.MAX_FIRST_PHOTOS, LevelRule.MAX_PHOTOS - have);
            info = "지금 " + have + "장이 올라가 있어요. 23:30 까지 " + maxThisTime + "장을 더 올릴 수 있고, "
                    + "파티원이 이미 한 투표는 그대로 유지돼요. 추가하면 투표한 파티원에게 알림이 가요.";
        } else {
            if (!p.isStatus(Plan.TODO)) {
                toast("이미 인증을 제출한 일정이에요");
                finish();
                return;
            }
            if (!p.canSubmit) {
                toast("인증은 일정 당일 " + LevelRule.PHOTO_DEADLINE + " 까지만 제출할 수 있어요");
                finish();
                return;
            }
            maxThisTime = LevelRule.MAX_FIRST_PHOTOS;
            if (p.voterCount == 0) {
                info = "파티원이 나 혼자라 투표할 사람이 없어요. 자정에 인정으로 확정되고 +" + LevelRule.PLAN_POINT + "P를 받아요.";
            } else {
                info = "사진은 " + LevelRule.MAX_FIRST_PHOTOS + "장까지, 오늘 " + LevelRule.PHOTO_DEADLINE + " 까지 올릴 수 있어요.\n"
                        + "파티원 " + p.voterCount + "명이 자정까지 투표하고, 자정에 결과가 확정돼요. "
                        + "미인정이 인정보다 많으면 미수행(−" + LevelRule.FAIL_PENALTY + "P), 같거나 적으면 인정(+"
                        + LevelRule.PLAN_POINT + "P)이에요. 투표하지 않은 사람은 세지 않아요.";
            }
        }
        // 올린 뒤에는 10분 동안만 바꾸거나 지울 수 있음을 미리 알림
        info += "\n\n" + LevelRule.PHOTO_EDIT_NOTICE + " 그 뒤에는 수정할 수 없으니 올리기 전에 사진을 꼭 확인해 주세요.";
        ((TextView) findViewById(R.id.text_info)).setText(info);
        refreshPhotos();
    }

    private void choosePhotoSource() {
        if (photos.size() >= maxThisTime) {
            toast("사진은 " + maxThisTime + "장까지 올릴 수 있어요");
            return;
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle("인증 사진")
                .setItems(new String[]{"카메라로 촬영", "갤러리에서 선택 (여러 장)"}, (d, which) -> {
                    if (which == 0) openCamera();
                    else pickImages.launch(new PickVisualMediaRequest.Builder()
                            .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                            .build());
                })
                .show();
    }

    private void openCamera() {
        try {
            File f = ImageUtil.newCameraFile(this);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            takePicture.launch(cameraUri);
        } catch (ActivityNotFoundException e) {
            toast("카메라 앱을 찾을 수 없어요");
        } catch (Exception e) {
            toast("카메라를 열 수 없어요");
        }
    }

    private void usePhotos(List<Uri> uris) {
        if (uris.isEmpty()) return;
        progressPhoto.setVisibility(View.VISIBLE);
        Async.run(() -> {
            List<File> files = new ArrayList<>();
            for (Uri uri : uris) files.add(ImageUtil.prepareForUpload(this, uri));
            return files;
        }, files -> {
            if (isDestroyed()) return;
            progressPhoto.setVisibility(View.GONE);
            for (File f : files) if (photos.size() < maxThisTime) photos.add(f);
            refreshPhotos();
        }, msg -> {
            progressPhoto.setVisibility(View.GONE);
            toast("사진을 불러오지 못했어요");
        });
    }

    /** 선택한 사진 썸네일 다시 그리기 (✕ 로 빼기) */
    private void refreshPhotos() {
        while (containerPhotos.getChildCount() > 1) containerPhotos.removeViewAt(0);
        int size = dp(132);
        for (int i = 0; i < photos.size(); i++) {
            final File f = photos.get(i);
            FrameLayout cell = new FrameLayout(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMarginEnd(dp(8));
            cell.setLayoutParams(lp);

            ImageView img = new ImageView(this);
            img.setLayoutParams(new FrameLayout.LayoutParams(size, size));
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setContentDescription("선택한 인증 사진 " + (i + 1));
            img.setBackgroundResource(R.drawable.bg_rounded_12);
            img.setClipToOutline(true);
            Glide.with(this).load(f).into(img);
            cell.addView(img);

            TextView remove = new TextView(this);
            FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.END | Gravity.TOP);
            rp.setMargins(0, dp(4), dp(4), 0);
            remove.setLayoutParams(rp);
            remove.setGravity(Gravity.CENTER);
            remove.setText("✕");
            remove.setTextColor(ContextCompat.getColor(this, R.color.white));
            remove.setBackgroundResource(R.drawable.bg_remove);
            remove.setContentDescription("사진 빼기");
            remove.setOnClickListener(v -> {
                photos.remove(f);
                refreshPhotos();
            });
            cell.addView(remove);
            containerPhotos.addView(cell, containerPhotos.getChildCount() - 1);
        }
        boxPhoto.setVisibility(photos.size() >= maxThisTime ? View.GONE : View.VISIBLE);
        textPhotoCount.setText(photos.size() + " / " + maxThisTime + "장");
        btnSubmit.setEnabled(!photos.isEmpty());
    }

    private void submit() {
        if (photos.isEmpty()) {
            toast("인증 사진을 추가해 주세요");
            return;
        }
        String comment = editComment.getText() == null ? "" : editComment.getText().toString().trim();
        final List<File> upload = new ArrayList<>(photos);
        btnSubmit.setEnabled(false);
        Async.run(() -> addMode
                ? repo.addVerificationPhotos(planId, upload)
                : repo.submitVerification(planId, upload, comment), p -> {
            toast(addMode ? "사진을 추가했어요" : "인증을 제출했어요. 결과는 자정에 확정돼요!");
            finish();
        }, msg -> {
            btnSubmit.setEnabled(true);
            toast(msg);
        });
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
