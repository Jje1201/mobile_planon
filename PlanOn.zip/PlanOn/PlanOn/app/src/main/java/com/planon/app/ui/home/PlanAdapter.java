package com.planon.app.ui.home;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.planon.app.R;
import com.planon.app.model.Plan;
import com.planon.app.util.LevelRule;

import java.util.ArrayList;
import java.util.List;

/** 일정 목록. 상태(인증 전/검토 중/인정/미인정)에 따라 버튼과 배지가 달라집니다. */
public class PlanAdapter extends RecyclerView.Adapter<PlanAdapter.VH> {

    public interface Listener {
        /** 내 일정 인증하기 */
        void onVerify(Plan plan);

        /** 인증 사진 보기 / 검토하기 */
        void onReview(Plan plan);

        /** 내 일정 삭제 (길게 누르기) */
        void onDelete(Plan plan);
    }

    private final List<Plan> items = new ArrayList<>();
    private final Listener listener;
    private long myId;

    public PlanAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<Plan> plans, long myId) {
        this.myId = myId;
        items.clear();
        if (plans != null) items.addAll(plans);
        notifyDataSetChanged();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView check, title, meta, chip;
        final MaterialButton action;

        VH(View v) {
            super(v);
            check = v.findViewById(R.id.text_check);
            title = v.findViewById(R.id.text_title);
            meta = v.findViewById(R.id.text_meta);
            chip = v.findViewById(R.id.text_chip);
            action = v.findViewById(R.id.btn_action);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_plan, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Context c = h.itemView.getContext();
        Plan p = items.get(position);
        boolean mine = p.userId == myId;
        boolean done = p.isStatus(Plan.APPROVED);
        boolean failed = p.isStatus(Plan.REJECTED);
        boolean missed = p.isStatus(Plan.MISSED);
        boolean voting = p.isStatus(Plan.VOTING);

        // 체크 박스
        if (done || failed || missed) {
            h.check.setText(done ? "✓" : missed ? "–" : "✕");
            h.check.setBackgroundResource(R.drawable.bg_rounded_8);
            h.check.setBackgroundTintList(ColorStateList.valueOf(color(c,
                    done ? R.color.success : missed ? R.color.muted : R.color.danger)));
        } else {
            h.check.setText("");
            h.check.setBackgroundTintList(null);
            h.check.setBackgroundResource(R.drawable.bg_check_empty);
        }

        // 제목 (확정된 일정은 취소선)
        h.title.setText(p.title);
        boolean closed = done || failed || missed;
        h.title.setTextColor(color(c, closed ? R.color.muted : R.color.ink));
        if (closed) h.title.setPaintFlags(h.title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        else h.title.setPaintFlags(h.title.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);

        // 보조 정보
        StringBuilder meta = new StringBuilder();
        if (p.time != null) meta.append(p.time);
        if (p.category != null) meta.append(meta.length() > 0 ? " · " : "").append(p.category);
        String detail;
        switch (p.status == null ? Plan.TODO : p.status) {
            case Plan.APPROVED:
                detail = "+" + LevelRule.PLAN_POINT + "P";
                break;
            case Plan.REJECTED:
                detail = "미수행 · −" + LevelRule.FAIL_PENALTY + "P";
                break;
            case Plan.MISSED:
                detail = "미인증 · 0P";
                break;
            case Plan.VOTING:
                int photos = p.imageUrls == null ? 0 : p.imageUrls.size();
                detail = "투표 " + p.votedCount + "/" + p.voterCount + " · 사진 " + photos + "장 · 자정에 확정";
                break;
            default:
                detail = p.canSubmit || !mine ? "인정 시 +" + LevelRule.PLAN_POINT + "P" : "인증은 당일 " + LevelRule.PHOTO_DEADLINE + "까지";
        }
        meta.append(meta.length() > 0 ? " · " : "").append(detail);
        h.meta.setText(meta.toString());

        // 오른쪽 버튼 / 배지
        h.action.setVisibility(View.GONE);
        h.chip.setVisibility(View.GONE);
        if (mine && p.canSubmit) {
            showButton(c, h.action, "인증하기", true);
            h.action.setOnClickListener(v -> listener.onVerify(p));
        } else if (!mine && p.canVote && p.myVote == 0) {
            showButton(c, h.action, "투표하기", false);
            h.action.setOnClickListener(v -> listener.onReview(p));
        } else if (voting) {
            if (mine) {
                if (p.rejectCount > 0) showChip(c, h.chip, "미인정 " + p.rejectCount, R.color.danger_soft, R.color.danger);
                else showChip(c, h.chip, "투표 중", R.color.warn_soft, R.color.warn);
            } else if (p.myVote != 0) {
                showChip(c, h.chip, p.myVote > 0 ? "내가 인정" : "내가 미인정", R.color.primary_soft, R.color.primary);
            } else {
                showChip(c, h.chip, "투표 중", R.color.warn_soft, R.color.warn);
            }
        } else if (done) {
            showChip(c, h.chip, "인정", R.color.success_soft, R.color.success);
        } else if (failed) {
            showChip(c, h.chip, "미수행", R.color.danger_soft, R.color.danger);
        } else if (missed) {
            showChip(c, h.chip, "미인증", R.color.fill, R.color.muted);
        } else if (mine) {
            showChip(c, h.chip, "예정", R.color.fill, R.color.muted);
        } else {
            showChip(c, h.chip, "진행 전", R.color.fill, R.color.muted);
        }

        // 항목 누르기: 인증이 있으면 검토 화면, 내 오늘 일정이면 인증 화면
        h.itemView.setOnClickListener(v -> {
            if (voting || done || failed) listener.onReview(p);
            else if (mine && p.canSubmit) listener.onVerify(p);
        });
        h.itemView.setOnLongClickListener(v -> {
            if (mine && p.isStatus(Plan.TODO)) {
                listener.onDelete(p);
                return true;
            }
            return false;
        });
    }

    private static void showButton(Context c, MaterialButton b, String text, boolean filled) {
        b.setVisibility(View.VISIBLE);
        b.setText(text);
        if (filled) {
            b.setBackgroundTintList(ColorStateList.valueOf(color(c, R.color.primary)));
            b.setTextColor(color(c, R.color.white));
            b.setStrokeWidth(0);
        } else {
            b.setBackgroundTintList(ColorStateList.valueOf(color(c, R.color.white)));
            b.setTextColor(color(c, R.color.primary));
            b.setStrokeColor(ColorStateList.valueOf(color(c, R.color.primary)));
            b.setStrokeWidth(Math.round(c.getResources().getDisplayMetrics().density));
        }
    }

    private static void showChip(Context c, TextView chip, String text, int bg, int fg) {
        chip.setVisibility(View.VISIBLE);
        chip.setText(text);
        chip.setTextColor(color(c, fg));
        chip.setBackgroundTintList(ColorStateList.valueOf(color(c, bg)));
    }

    private static int color(Context c, int res) {
        return ContextCompat.getColor(c, res);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
