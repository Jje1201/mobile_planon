package com.planon.app.push;

import android.content.Context;
import android.util.Log;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import com.planon.app.R;
import com.planon.app.data.RepositoryProvider;

import java.util.concurrent.TimeUnit;

/**
 * 푸시 알림 준비.
 * - res/values/firebase.xml 에 값이 있으면 Firebase 를 직접 초기화하고 FCM 토큰을 서버에 등록
 *   (google-services 플러그인 없이 동작하도록 값으로 초기화)
 * - 값이 없으면 FCM 없이, 15분마다 알림함을 확인해 새 알림을 휴대폰 알림으로 보여줌 (NotificationPollWorker)
 */
public final class PushSetup {
    private PushSetup() {
    }

    private static final String TAG = "PushSetup";
    private static final String POLL_WORK = "planon_notification_poll";
    private static boolean fcmReady;

    public static void init(Context context) {
        Context app = context.getApplicationContext();
        NotificationHelper.createChannel(app);
        fcmReady = initFirebase(app);
        schedulePolling(app);
        refreshToken();
    }

    public static boolean isFcmEnabled() {
        return fcmReady;
    }

    private static boolean initFirebase(Context app) {
        String appId = app.getString(R.string.firebase_app_id).trim();
        String apiKey = app.getString(R.string.firebase_api_key).trim();
        String projectId = app.getString(R.string.firebase_project_id).trim();
        String senderId = app.getString(R.string.firebase_sender_id).trim();
        if (appId.isEmpty() || apiKey.isEmpty() || projectId.isEmpty() || senderId.isEmpty()) {
            Log.i(TAG, "Firebase 설정이 비어 있어 FCM 없이 알림함 확인 방식으로 동작합니다");
            return false;
        }
        try {
            if (FirebaseApp.getApps(app).isEmpty()) {
                FirebaseOptions options = new FirebaseOptions.Builder()
                        .setApplicationId(appId)
                        .setApiKey(apiKey)
                        .setProjectId(projectId)
                        .setGcmSenderId(senderId)
                        .build();
                FirebaseApp.initializeApp(app, options);
            }
            return true;
        } catch (Exception e) {
            Log.w(TAG, "Firebase 초기화 실패", e);
            return false;
        }
    }

    /** 로그인 직후·앱 시작 때 호출: FCM 토큰을 받아 서버에 등록 */
    public static void refreshToken() {
        if (!fcmReady) return;
        try {
            FirebaseMessaging.getInstance().getToken().addOnSuccessListener(PushSetup::sendToken);
        } catch (Exception e) {
            Log.w(TAG, "FCM 토큰 요청 실패", e);
        }
    }

    static void sendToken(String token) {
        if (token == null || token.isEmpty()) return;
        new Thread(() -> {
            try {
                RepositoryProvider.get().registerPushToken(token);
            } catch (Exception e) {
                Log.w(TAG, "푸시 토큰 등록 실패 (다음 실행 때 다시 시도)", e);
            }
        }).start();
    }

    /** FCM 이 없을 때 대신 쓰는 주기 확인 (안드로이드 제한상 최소 15분 간격) */
    private static void schedulePolling(Context app) {
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(NotificationPollWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build();
        WorkManager.getInstance(app).enqueueUniquePeriodicWork(POLL_WORK, ExistingPeriodicWorkPolicy.KEEP, request);
    }
}
