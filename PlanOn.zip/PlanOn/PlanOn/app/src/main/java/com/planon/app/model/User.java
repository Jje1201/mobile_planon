package com.planon.app.model;

import com.planon.app.util.LevelRule;

/** 로그인한 사용자 정보 (서버 응답 JSON과 필드 이름이 같아야 합니다). */
public class User {
    public long id;
    public String loginId;
    public String nickname;

    /** 소속 파티. 없으면 0 */
    public long partyId;
    public String partyName;

    /** 선택한 캐릭터 1~4. 아직 고르지 않았으면 0 */
    public int characterId;

    /** 지금까지 받은 경험치 합계. 레벨은 이 값으로 계산합니다. */
    public int totalExp;

    /** 이번 주(월~일) 포인트 */
    public int weeklyPoints;
    /** 누적 포인트 */
    public int totalPoints;
    /** 이번 주 파티 내 순위 (모르면 0) */
    public int weeklyRank;

    public int getLevel() {
        return LevelRule.levelFor(totalExp);
    }

    /** 현재 레벨에서 쌓은 경험치 */
    public int getExpInLevel() {
        return LevelRule.expInLevel(totalExp);
    }

    /** 다음 레벨까지 필요한 경험치 (최고 레벨이면 0) */
    public int getExpForNext() {
        int level = getLevel();
        return level >= LevelRule.MAX_LEVEL ? 0 : LevelRule.needForNext(level);
    }

    public int getStage() {
        return LevelRule.stageFor(getLevel());
    }

    public boolean hasParty() {
        return partyId > 0;
    }
}
