package com.planon.app.push;

import androidx.annotation.NonNull;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/**
 * FCM 수신.
 * - 앱이 백그라운드면 서버가 보낸 notification 블록을 안드로이드가 직접 표시
 * - 앱이 켜져 있으면 여기로 와서 직접 표시
 */
public class PlanOnMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        PushSetup.sendToken(token);
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        Map<String, String> data = message.getData();
        String title = data.get("title");
        String body = data.get("body");
        if ((title == null || title.isEmpty()) && message.getNotification() != null) {
            title = message.getNotification().getTitle();
            body = message.getNotification().getBody();
        }
        if (title == null) return;
        Long planId = null;
        String raw = data.get("planId");
        if (raw != null && !raw.isEmpty()) {
            try {
                planId = Long.parseLong(raw);
            } catch (NumberFormatException ignored) {
                // 잘못된 값이면 알림함으로
            }
        }
        NotificationHelper.show(this, (int) (System.currentTimeMillis() & 0x7fffffff), title, body == null ? "" : body, planId);
    }
}
