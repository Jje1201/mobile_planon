package com.planon.app.push;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.data.local.DbHelper;
import com.planon.app.model.AppNotification;

import java.util.List;

/**
 * FCM 이 설정되지 않았을 때: 알림함에서 아직 보여주지 않은 안 읽은 알림을 휴대폰 알림으로 띄웁니다.
 * (FCM 이 켜져 있으면 서버가 바로 푸시하므로 아무것도 하지 않음)
 */
public class NotificationPollWorker extends Worker {

    public NotificationPollWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        if (PushSetup.isFcmEnabled()) return Result.success();
        try {
            RepositoryProvider.init(getApplicationContext());
            Repository repo = RepositoryProvider.get();
            if (!repo.isLoggedIn()) return Result.success();
            showNew(getApplicationContext(), repo.getNotifications());
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    /** 처음 한 번은 기준점만 잡고(옛 알림이 한꺼번에 뜨지 않게), 그다음부터 새 알림만 표시 */
    static void showNew(Context context, List<AppNotification> list) {
        DbHelper db = DbHelper.get(context);
        String saved = db.getSetting(DbHelper.KEY_LAST_SHOWN_NOTIFICATION);
        long last = saved == null ? -1 : Long.parseLong(saved);
        long max = last;
        for (AppNotification n : list) max = Math.max(max, n.id);
        if (last >= 0) {
            for (int i = list.size() - 1; i >= 0; i--) { // 오래된 것부터
                AppNotification n = list.get(i);
                if (n.id > last && !n.read) NotificationHelper.show(context, (int) n.id, n.title, n.body, n.planId);
            }
        }
        if (max != last) db.putSetting(DbHelper.KEY_LAST_SHOWN_NOTIFICATION, String.valueOf(Math.max(max, 0)));
    }
}
