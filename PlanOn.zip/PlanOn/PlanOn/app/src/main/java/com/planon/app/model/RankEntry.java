package com.planon.app.model;

import com.planon.app.util.LevelRule;

public class RankEntry {
    public int rank;
    public long userId;
    public String nickname;
    public int characterId;
    public int totalExp;
    /** 해당 기간의 포인트 */
    public int points;
    /** 해당 기간에 인정받은 일정 수 */
    public int doneCount;
    /** 주간: 지급(예정) 경험치, 월간: 그 달에 받은 경험치 */
    public int exp;

    public int getLevel() {
        return LevelRule.levelFor(totalExp);
    }
}
