package com.planon.app.data.remote;

import com.planon.app.model.User;

/** 서버와 주고받는 요청/응답 JSON 형식 (docs/server-api.md 참고) */
public final class Dtos {
    private Dtos() {
    }

    public static class SignUpRequest {
        public String loginId;
        public String password;
        public String nickname;

        public SignUpRequest(String loginId, String password, String nickname) {
            this.loginId = loginId;
            this.password = password;
            this.nickname = nickname;
        }
    }

    public static class LoginRequest {
        public String loginId;
        public String password;
        /** true 면 서버가 rememberToken 을 발급 */
        public Boolean remember;
        public String deviceName;

        public LoginRequest(String loginId, String password, boolean remember, String deviceName) {
            this.loginId = loginId;
            this.password = password;
            this.remember = remember;
            this.deviceName = deviceName;
        }
    }

    public static class QuickLoginRequest {
        public String rememberToken;

        public QuickLoginRequest(String rememberToken) {
            this.rememberToken = rememberToken;
        }
    }

    public static class LoginResponse {
        public String token;
        public User user;
        /** 저장을 선택했을 때만 */
        public String rememberToken;
    }

    public static class AvailableResponse {
        public boolean available;
    }

    public static class PartyCreateRequest {
        public String name;

        public PartyCreateRequest(String name) {
            this.name = name;
        }
    }

    public static class JoinRequest {
        public String inviteCode;

        public JoinRequest(String inviteCode) {
            this.inviteCode = inviteCode;
        }
    }

    public static class CharacterRequest {
        public int characterId;

        public CharacterRequest(int characterId) {
            this.characterId = characterId;
        }
    }

    public static class PlanRequest {
        public String date;
        public String title;
        public String time;
        public String category;
        public String memo;

        public PlanRequest(String date, String title, String time, String category, String memo) {
            this.date = date;
            this.title = title;
            this.time = time;
            this.category = category;
            this.memo = memo;
        }
    }

    public static class VoteRequest {
        public boolean approve;

        public VoteRequest(boolean approve) {
            this.approve = approve;
        }
    }

    public static class TokenRequest {
        public String token;

        public TokenRequest(String token) {
            this.token = token;
        }
    }

    public static class CountResponse {
        public int count;
    }

    /** 서버 오류 응답: {"message": "사용자에게 보여줄 문구"} */
    public static class ErrorResponse {
        public String message;
    }
}
