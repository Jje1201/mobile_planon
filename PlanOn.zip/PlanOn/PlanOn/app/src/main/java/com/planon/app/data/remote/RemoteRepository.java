package com.planon.app.data.remote;

import com.google.gson.Gson;
import com.planon.app.data.ApiException;
import com.planon.app.data.Repository;
import com.planon.app.data.SavedLoginExpiredException;
import com.planon.app.data.local.DbHelper;
import com.planon.app.model.AchievementList;
import com.planon.app.model.AppNotification;
import com.planon.app.model.Party;
import com.planon.app.model.Plan;
import com.planon.app.model.RankingResult;
import com.planon.app.model.User;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Spring 서버와 통신하는 Repository (Wi-Fi/네트워크 사용).
 * 로그인 토큰은 SQLite session 테이블에 저장해 앱을 다시 켜도 유지됩니다.
 */
public class RemoteRepository implements Repository {

    private static final MediaType JPEG = MediaType.parse("image/jpeg");
    private static final MediaType TEXT = MediaType.parse("text/plain; charset=utf-8");

    private final DbHelper db;
    private final String baseUrl;
    private final ApiService api;
    private final Gson gson = new Gson();

    public RemoteRepository(DbHelper db, String baseUrl) {
        this.db = db;
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl : baseUrl + "/";

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)   // 사진 여러 장 업로드
                .addInterceptor(chain -> {
                    Request.Builder b = chain.request().newBuilder();
                    String token = db.getSessionToken();
                    if (token != null) b.header("Authorization", "Bearer " + token);
                    return chain.proceed(b.build());
                })
                .build();

        api = new Retrofit.Builder()
                .baseUrl(this.baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
                .create(ApiService.class);
    }

    // ---------- 회원 ----------

    @Override
    public boolean isLoginIdAvailable(String loginId) throws Exception {
        Dtos.AvailableResponse r = exec(api.checkLoginId(loginId.trim()));
        return r != null && r.available;
    }

    @Override
    public User signUp(String loginId, String password, String nickname) throws Exception {
        return exec(api.signUp(new Dtos.SignUpRequest(loginId.trim(), password, nickname.trim())));
    }

    @Override
    public User login(String loginId, String password, boolean remember) throws Exception {
        Dtos.LoginResponse r = exec(api.login(new Dtos.LoginRequest(loginId.trim(), password, remember,
                android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL)));
        if (r == null || r.token == null || r.user == null) throw new ApiException("로그인 응답이 올바르지 않아요");
        db.saveSession(r.user.id, r.token);
        if (remember && r.rememberToken != null) db.saveAccount(baseUrl, r.user, r.rememberToken);
        registerPushAfterLogin();
        return r.user;
    }

    @Override
    public java.util.List<com.planon.app.model.SavedAccount> getSavedAccounts() {
        return db.getSavedAccounts(baseUrl);
    }

    @Override
    public User quickLogin(com.planon.app.model.SavedAccount account) throws Exception {
        Response<Dtos.LoginResponse> response;
        try {
            response = api.quickLogin(new Dtos.QuickLoginRequest(account.rememberToken)).execute();
        } catch (java.io.IOException e) {
            throw new ApiException(connectionMessage(e));
        }
        if (response.code() == 401 || response.code() == 400) {
            // 서버에서 만료·폐기된 저장 로그인 → 목록에서 지우고 비밀번호로 다시
            db.deleteSavedAccount(baseUrl, account.userId);
            throw new SavedLoginExpiredException("저장된 로그인 정보가 만료됐어요. 비밀번호로 다시 로그인해 주세요");
        }
        if (!response.isSuccessful() || response.body() == null || response.body().user == null) {
            throw new ApiException("서버 오류가 발생했어요 (" + response.code() + ")");
        }
        Dtos.LoginResponse r = response.body();
        db.saveSession(r.user.id, r.token);
        db.saveAccount(baseUrl, r.user, account.rememberToken);
        registerPushAfterLogin();
        return r.user;
    }

    @Override
    public void forgetAccount(com.planon.app.model.SavedAccount account) {
        db.deleteSavedAccount(baseUrl, account.userId);
        Call<Void> call = api.forget(new Dtos.QuickLoginRequest(account.rememberToken));
        new Thread(() -> {
            try {
                call.execute(); // 서버 쪽 토큰 폐기 (실패해도 기기 목록에서는 이미 지움)
            } catch (Exception ignored) {
                // 무시
            }
        }).start();
    }

    private void registerPushAfterLogin() {
        // 로그인 전에 받아둔 푸시 토큰이 있으면 이 계정으로 등록
        String push = db.getSetting(DbHelper.KEY_PUSH_TOKEN);
        if (push != null) {
            try {
                exec(api.saveDeviceToken(new Dtos.TokenRequest(push)));
            } catch (Exception ignored) {
                // 푸시 등록 실패는 로그인 실패가 아님
            }
        }
    }

    @Override
    public void logout() {
        // 이 기기로 다른 계정의 푸시가 오지 않게 서버에서 토큰 삭제 (실패해도 로그아웃은 진행)
        final String push = db.getSetting(DbHelper.KEY_PUSH_TOKEN);
        final String session = db.getSessionToken();
        if (push != null && session != null) {
            Call<Void> call = api.deleteDeviceToken(push);
            new Thread(() -> {
                try {
                    call.execute();
                } catch (Exception ignored) {
                    // 무시
                }
            }).start();
        }
        db.clearSession();
    }

    @Override
    public boolean isLoggedIn() {
        return db.getSessionToken() != null;
    }

    @Override
    public User getMe() throws Exception {
        User me = exec(api.me());
        db.updateSavedProfile(baseUrl, me); // 로그인 화면 목록의 닉네임·캐릭터도 최신으로
        return me;
    }

    // ---------- 파티 ----------

    @Override
    public Party createParty(String name) throws Exception {
        return exec(api.createParty(new Dtos.PartyCreateRequest(name.trim())));
    }

    @Override
    public Party joinParty(String inviteCode) throws Exception {
        return exec(api.joinParty(new Dtos.JoinRequest(inviteCode.trim().toUpperCase())));
    }

    @Override
    public Party getMyParty() throws Exception {
        return exec(api.myParty()); // 204 → null
    }

    @Override
    public void leaveParty() throws Exception {
        exec(api.leaveParty());
    }

    @Override
    public void selectCharacter(int characterId) throws Exception {
        exec(api.selectCharacter(new Dtos.CharacterRequest(characterId)));
    }

    // ---------- 일정 ----------

    @Override
    public List<Plan> getPlans(long userId, String date) throws Exception {
        List<Plan> list = exec(api.plans(userId, date));
        if (list == null) return new ArrayList<>();
        for (Plan p : list) fixImageUrls(p);
        return list;
    }

    @Override
    public Set<String> getMyPlanDates(String yearMonth) throws Exception {
        List<String> list = exec(api.planDates(yearMonth));
        return list == null ? new LinkedHashSet<>() : new LinkedHashSet<>(list);
    }

    @Override
    public Plan addPlan(String date, String title, String time, String category, String memo) throws Exception {
        return exec(api.addPlan(new Dtos.PlanRequest(date, title, time, category, memo)));
    }

    @Override
    public void deletePlan(long planId) throws Exception {
        exec(api.deletePlan(planId));
    }

    // ---------- 인증 ----------

    @Override
    public Plan submitVerification(long planId, List<File> images, String comment) throws Exception {
        RequestBody text = RequestBody.create(TEXT, comment == null ? "" : comment);
        return fixImageUrls(exec(api.submitVerification(planId, parts(images), text)));
    }

    @Override
    public Plan addVerificationPhotos(long planId, List<File> images) throws Exception {
        return fixImageUrls(exec(api.addPhotos(planId, parts(images))));
    }

    @Override
    public Plan deleteVerificationPhoto(long planId, long photoId) throws Exception {
        return fixImageUrls(exec(api.deletePhoto(planId, photoId)));
    }

    @Override
    public Plan replaceVerificationPhoto(long planId, long photoId, File image) throws Exception {
        MultipartBody.Part part = MultipartBody.Part.createFormData("image", image.getName(), RequestBody.create(JPEG, image));
        return fixImageUrls(exec(api.replacePhoto(planId, photoId, part)));
    }

    @Override
    public Plan getVerification(long planId) throws Exception {
        return fixImageUrls(exec(api.verification(planId)));
    }

    @Override
    public Plan vote(long planId, boolean approve) throws Exception {
        return fixImageUrls(exec(api.vote(planId, new Dtos.VoteRequest(approve))));
    }

    private static List<MultipartBody.Part> parts(List<File> images) throws ApiException {
        if (images == null || images.isEmpty()) throw new ApiException("인증 사진을 추가해 주세요");
        List<MultipartBody.Part> parts = new ArrayList<>();
        for (File f : images) {
            parts.add(MultipartBody.Part.createFormData("images", f.getName(), RequestBody.create(JPEG, f)));
        }
        return parts;
    }

    // ---------- 랭킹 ----------

    @Override
    public RankingResult getRanking(String period) throws Exception {
        RankingResult r;
        switch (period) {
            case RankingResult.WEEK_LAST:
                r = exec(api.weeklyRanking("last"));
                break;
            case RankingResult.MONTH_CURRENT:
                r = exec(api.monthlyRanking("current"));
                break;
            case RankingResult.MONTH_LAST:
                r = exec(api.monthlyRanking("last"));
                break;
            default:
                r = exec(api.weeklyRanking("current"));
        }
        if (r == null) r = new RankingResult();
        if (r.period == null) r.period = period;
        return r;
    }

    // ---------- 업적 ----------

    @Override
    public AchievementList getAchievements() throws Exception {
        AchievementList r = exec(api.achievements());
        return r == null ? new AchievementList() : r;
    }

    // ---------- 알림 ----------

    @Override
    public List<AppNotification> getNotifications() throws Exception {
        List<AppNotification> list = exec(api.notifications(50));
        return list == null ? new ArrayList<>() : list;
    }

    @Override
    public int getUnreadCount() throws Exception {
        Dtos.CountResponse r = exec(api.unreadCount());
        return r == null ? 0 : r.count;
    }

    @Override
    public void markNotificationRead(long id) throws Exception {
        exec(api.markRead(id));
    }

    @Override
    public void markAllNotificationsRead() throws Exception {
        exec(api.markAllRead());
    }

    @Override
    public void registerPushToken(String token) throws Exception {
        db.putSetting(DbHelper.KEY_PUSH_TOKEN, token);
        if (isLoggedIn()) exec(api.saveDeviceToken(new Dtos.TokenRequest(token)));
    }

    // ---------- 공통 ----------

    public String getBaseUrl() {
        return baseUrl;
    }

    /** GET /api/health 로 서버 연결 확인 */
    public void checkServer() throws Exception {
        exec(api.health());
    }

    private <T> T exec(Call<T> call) throws Exception {
        Response<T> response;
        try {
            response = call.execute();
        } catch (java.io.IOException e) {
            android.util.Log.w("RemoteRepository", "연결 실패: " + baseUrl, e);
            throw new ApiException(connectionMessage(e));
        }
        if (response.isSuccessful()) return response.body();

        if (response.code() == 401) {
            db.clearSession();
            throw new ApiException("로그인이 만료되었어요. 다시 로그인해 주세요.");
        }
        String message = "서버 오류가 발생했어요 (" + response.code() + ")";
        try (okhttp3.ResponseBody body = response.errorBody()) {
            if (body != null) {
                Dtos.ErrorResponse err = gson.fromJson(body.charStream(), Dtos.ErrorResponse.class);
                if (err != null && err.message != null && !err.message.isEmpty()) message = err.message;
            }
        } catch (Exception ignored) {
            // 오류 본문이 JSON이 아니면 기본 문구 사용
        }
        throw new ApiException(message);
    }

    /** 토스트가 두 줄에서 잘리므로 원인을 앞에 짧게 */
    private String connectionMessage(java.io.IOException e) {
        String detail = e.getMessage() == null ? "" : e.getMessage();
        if (e instanceof java.net.ConnectException) {
            return "연결 거부: " + baseUrl + " 에 서버가 실행 중이 아니에요 (PC에서 ServerApplication 실행·오류 확인)";
        }
        if (e instanceof java.net.SocketTimeoutException) {
            return "응답 없음: " + baseUrl + " (방화벽 8080 허용·같은 Wi-Fi 확인)";
        }
        if (e instanceof java.net.UnknownServiceException || detail.contains("CLEARTEXT")) {
            return "http 차단: 앱을 다시 설치해 주세요 (network_security_config)";
        }
        if (e instanceof java.net.UnknownHostException) {
            return "주소를 찾을 수 없어요: " + baseUrl;
        }
        return "연결 실패(" + e.getClass().getSimpleName() + "): " + baseUrl + " " + detail;
    }

    /** 서버가 "/uploads/a.jpg" 같은 상대 경로를 주면 전체 URL로 바꿉니다. */
    private Plan fixImageUrls(Plan p) {
        if (p == null || p.imageUrls == null) return p;
        List<String> fixed = new ArrayList<>();
        for (String url : p.imageUrls) {
            if (url == null) continue;
            if (url.startsWith("http")) fixed.add(url);
            else fixed.add(baseUrl + (url.startsWith("/") ? url.substring(1) : url));
        }
        p.imageUrls = fixed;
        if (p.photos != null) {
            for (com.planon.app.model.PlanPhoto ph : p.photos) {
                if (ph.url != null && !ph.url.startsWith("http")) {
                    ph.url = baseUrl + (ph.url.startsWith("/") ? ph.url.substring(1) : ph.url);
                }
            }
        }
        return p;
    }
}
