package com.planon.app.model;

import com.planon.app.util.LevelRule;

/** 파티원 한 명 + 오늘의 진행도 */
public class Member {
    public long userId;
    public String nickname;
    public int characterId;
    public int totalExp;
    public boolean leader;

    /** 오늘 등록된 일정 수 */
    public int todayTotal;
    /** 오늘 인정(완료)된 일정 수 */
    public int todayDone;

    public int getLevel() {
        return LevelRule.levelFor(totalExp);
    }

    public int getStage() {
        return LevelRule.stageFor(getLevel());
    }

    public int getTodayPercent() {
        if (todayTotal == 0) return 0;
        return Math.round(todayDone * 100f / todayTotal);
    }
}
