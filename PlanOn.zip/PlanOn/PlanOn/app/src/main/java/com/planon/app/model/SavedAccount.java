package com.planon.app.model;

/** 이 기기에서 로그인했던 계정 (로그인 화면의 "계정 선택" 목록) */
public class SavedAccount {
    public long userId;
    public String loginId;
    public String nickname;
    public int characterId;
    public int stage = 1;
    /** 비밀번호 없이 로그인할 때 서버에 보내는 토큰 (서버에는 해시만 저장됨) */
    public String rememberToken;
    /** 마지막 로그인 시각 (ms) */
    public long lastLoginAt;
}
