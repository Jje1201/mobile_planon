package com.planon.app.ui.party;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.Member;
import com.planon.app.model.Party;
import com.planon.app.model.User;
import com.planon.app.ui.Router;
import com.planon.app.ui.main.MainActivity;
import com.planon.app.util.Async;
import com.planon.app.util.Characters;

import java.util.HashMap;
import java.util.Map;

public class CharacterSelectActivity extends AppCompatActivity {

    private final Repository repo = RepositoryProvider.get();

    /** 캐릭터 번호 → 이미 고른 파티원 닉네임 */
    private final Map<Integer, String> taken = new HashMap<>();
    private int selected = 0;

    private Adapter adapter;
    private TextView textSelected;
    private MaterialButton btnStart;

    private static class Data {
        User me;
        Party party;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_select);

        textSelected = findViewById(R.id.text_selected);
        btnStart = findViewById(R.id.btn_start);

        RecyclerView rv = findViewById(R.id.recycler_characters);
        rv.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new Adapter();
        rv.setAdapter(adapter);

        btnStart.setOnClickListener(v -> confirm());
        load();
    }

    private void load() {
        Async.run(() -> {
            Data d = new Data();
            d.me = repo.getMe();
            d.party = repo.getMyParty();
            return d;
        }, d -> {
            if (d.party == null) {
                Router.go(this, PartyJoinActivity.class);
                return;
            }
            taken.clear();
            for (Member m : d.party.members) {
                if (m.userId != d.me.id && m.characterId > 0) taken.put(m.characterId, m.nickname);
            }
            if (taken.containsKey(selected)) selected = 0;
            refresh();
        }, this::toast);
    }

    private void refresh() {
        adapter.notifyDataSetChanged();
        btnStart.setEnabled(selected > 0);
        textSelected.setText(selected > 0 ? "선택: " + Characters.name(selected) : "캐릭터를 선택해 주세요");
    }

    private void confirm() {
        if (selected == 0) return;
        btnStart.setEnabled(false);
        Async.run(() -> {
            repo.selectCharacter(selected);
            return true;
        }, ok -> Router.go(this, MainActivity.class), msg -> {
            toast(msg);
            load(); // 그사이 다른 사람이 골랐을 수 있으니 새로고침
        });
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {

        class VH extends RecyclerView.ViewHolder {
            final MaterialCardView card;
            final ImageView image;
            final TextView name, tag;

            VH(View v) {
                super(v);
                card = v.findViewById(R.id.card);
                image = v.findViewById(R.id.image_character);
                name = v.findViewById(R.id.text_name);
                tag = v.findViewById(R.id.text_tag);
            }
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_character, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            int id = position + 1;
            String owner = taken.get(id);
            boolean isTaken = owner != null;
            boolean isSelected = selected == id;

            h.image.setImageResource(Characters.image(id, 1)); // 성장 모습은 숨기고 알 모습으로만 고름
            h.name.setText(Characters.name(id));
            h.card.setChecked(isSelected);
            h.card.setEnabled(!isTaken);
            h.card.setAlpha(isTaken ? 0.5f : 1f);
            h.card.setStrokeColor(color(isSelected ? R.color.primary : R.color.line));
            h.card.setCardBackgroundColor(color(R.color.white)); // 캐릭터 뒤 배경은 항상 흰색, 선택은 테두리로 표시
            h.card.setStrokeWidth(dp(isSelected ? 3 : 1));

            if (isTaken) {
                h.tag.setText(owner + " 선택함");
                h.tag.setTextColor(color(R.color.muted));
                h.tag.setBackgroundTintList(ColorStateList.valueOf(color(R.color.line_soft)));
            } else if (isSelected) {
                h.tag.setText("선택됨");
                h.tag.setTextColor(color(R.color.white));
                h.tag.setBackgroundTintList(ColorStateList.valueOf(color(R.color.primary)));
            } else {
                h.tag.setText("선택 가능");
                h.tag.setTextColor(color(R.color.muted));
                h.tag.setBackgroundTintList(ColorStateList.valueOf(color(R.color.fill)));
            }

            h.card.setOnClickListener(v -> {
                if (isTaken) return;
                selected = id;
                refresh();
            });
        }

        @Override
        public int getItemCount() {
            return Characters.COUNT;
        }
    }

    private int color(int res) {
        return ContextCompat.getColor(this, res);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
