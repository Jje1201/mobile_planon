package com.planon.app.ui.mypage;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.Achievement;
import com.planon.app.model.AchievementList;
import com.planon.app.model.Party;
import com.planon.app.model.User;
import com.planon.app.ui.Router;
import com.planon.app.ui.party.PartyJoinActivity;
import com.planon.app.util.Async;
import com.planon.app.util.Characters;
import com.planon.app.util.LevelRule;

/** 마이페이지: 캐릭터, 레벨, 경험치, 소속 파티, 포인트 */
public class MyPageFragment extends Fragment {

    private final Repository repo = RepositoryProvider.get();

    private ImageView imageCharacter;
    private TextView textCharacter, textNickname, textLevel, textExp, textPartyName, textPartySize, textPoints, textPointsSub;
    private LinearProgressIndicator progressExp;
    private LinearLayout containerStages, containerAchievements;
    private TextView textAchievementCount, textStreak;

    private Party party;

    private static class Data {
        User me;
        Party party;
        AchievementList achievements;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_mypage, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        imageCharacter = v.findViewById(R.id.image_character);
        textCharacter = v.findViewById(R.id.text_character);
        textNickname = v.findViewById(R.id.text_nickname);
        textLevel = v.findViewById(R.id.text_level);
        textExp = v.findViewById(R.id.text_exp);
        progressExp = v.findViewById(R.id.progress_exp);
        containerStages = v.findViewById(R.id.container_stages);
        textPartyName = v.findViewById(R.id.text_party_name);
        textPartySize = v.findViewById(R.id.text_party_size);
        textPoints = v.findViewById(R.id.text_points);
        textPointsSub = v.findViewById(R.id.text_points_sub);
        containerAchievements = v.findViewById(R.id.container_achievements);
        textAchievementCount = v.findViewById(R.id.text_achievement_count);
        textStreak = v.findViewById(R.id.text_streak);

        v.findViewById(R.id.btn_invite_code).setOnClickListener(x -> showInvite());
        v.findViewById(R.id.btn_leave).setOnClickListener(x -> confirmLeave());
        v.findViewById(R.id.btn_logout).setOnClickListener(x -> {
            repo.logout();
            Router.toLogin(requireActivity());
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isHidden()) load();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) load();
    }

    private void load() {
        Async.run(() -> {
            Data d = new Data();
            d.me = repo.getMe();
            d.party = repo.getMyParty();
            try {
                d.achievements = repo.getAchievements();
            } catch (Exception e) {
                d.achievements = null; // 업적을 못 불러와도 나머지 정보는 보여줌
            }
            return d;
        }, d -> {
            if (isAdded()) bind(d);
        }, this::toast);
    }

    private void bind(Data d) {
        User me = d.me;
        party = d.party;
        int level = me.getLevel();
        int stage = me.getStage();

        imageCharacter.setImageResource(Characters.image(me.characterId, stage));
        textCharacter.setText(Characters.name(me.characterId) + " · " + stage + "단계");
        textNickname.setText(me.nickname);
        textLevel.setText("Lv." + level);

        if (level >= LevelRule.MAX_LEVEL) {
            textExp.setText("최고 레벨 달성!");
            progressExp.setProgressCompat(100, false);
        } else {
            // 레벨이 오를수록 필요한 경험치가 2씩 늘어남 (Lv.1→2: 15, Lv.2→3: 17 …)
            textExp.setText(me.getExpInLevel() + " / " + me.getExpForNext() + " EXP · 누적 " + me.totalExp);
            progressExp.setMax(me.getExpForNext());
            progressExp.setProgressCompat(me.getExpInLevel(), false);
        }
        bindStages(stage);

        textPartyName.setText(me.partyName != null ? me.partyName : "-");
        textPartySize.setText(party != null ? "파티원 " + party.size() + "명" : "");
        textPoints.setText(me.weeklyPoints + "P");
        textPointsSub.setText((me.weeklyRank > 0 ? "현재 " + me.weeklyRank + "위 · " : "") + "누적 " + me.totalPoints + "P");
        bindAchievements(d.achievements);
    }

    private void bindStages(int current) {
        containerStages.removeAllViews();
        for (int s = 1; s <= LevelRule.MAX_STAGE; s++) {
            TextView t = new TextView(requireContext());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (s > 1) lp.setMarginStart(dp(6));
            t.setLayoutParams(lp);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(8), 0, dp(8));
            t.setTextSize(11);
            int from = (s - 1) * LevelRule.LEVELS_PER_STAGE + 1;
            int to = s * LevelRule.LEVELS_PER_STAGE;
            t.setText(s + "단계\nLv." + from + "~" + to);
            t.setBackgroundResource(R.drawable.bg_rounded_8);
            int bg, fg;
            if (s == current) {
                bg = R.color.primary;
                fg = R.color.white;
            } else if (s < current) {
                bg = R.color.primary_soft;
                fg = R.color.primary;
            } else {
                bg = R.color.fill;
                fg = R.color.muted;
            }
            t.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), bg)));
            t.setTextColor(ContextCompat.getColor(requireContext(), fg));
            containerStages.addView(t);
        }
    }

    private void bindAchievements(AchievementList list) {
        containerAchievements.removeAllViews();
        if (list == null) {
            textAchievementCount.setText("");
            textStreak.setText("업적을 불러오지 못했어요");
            return;
        }
        textAchievementCount.setText(list.earnedCount + " / " + list.totalCount);
        textStreak.setText("연속 올클 " + list.clearStreak + "일 · 최고 " + list.bestClearStreak + "일"
                + "  (올클 = 하루 일정 3개 이상 모두 인정)");
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        for (Achievement a : list.items) {
            View row = inflater.inflate(R.layout.item_achievement, containerAchievements, false);
            TextView badge = row.findViewById(R.id.text_badge);
            int dark = categoryColor(a.category);
            int soft = categorySoft(a.category);
            badge.setText(a.earned ? categoryIcon(a.category) : (a.hidden ? "?" : "·"));
            badge.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(),
                    a.earned ? soft : R.color.fill)));
            badge.setTextColor(ContextCompat.getColor(requireContext(), a.earned ? dark : R.color.muted));

            TextView name = row.findViewById(R.id.text_name);
            name.setText(a.name);
            name.setTextColor(ContextCompat.getColor(requireContext(), a.earned ? R.color.ink : R.color.muted));
            String desc = a.description;
            if (a.earned && a.firstAchievedAt != null && a.firstAchievedAt.length() >= 10) {
                desc += "\n처음 달성 " + a.firstAchievedAt.substring(0, 10).replace('-', '.');
            }
            ((TextView) row.findViewById(R.id.text_desc)).setText(desc);

            TextView right = row.findViewById(R.id.text_right);
            if (a.earned) {
                right.setText(a.count > 1 ? "×" + a.count : "달성");
                right.setTextColor(ContextCompat.getColor(requireContext(), dark));
            } else {
                right.setText(a.rewardPoints > 0 ? "+" + a.rewardPoints + "P" : "");
                right.setTextColor(ContextCompat.getColor(requireContext(), R.color.muted));
            }
            containerAchievements.addView(row);
        }
    }

    /** 분류별 색: 연속 블루 · 파티 그린 · 재미 레드 · 월간 옐로 */
    private static int categoryColor(String c) {
        if (Achievement.PARTY.equals(c)) return R.color.char_2;
        if (Achievement.FUN.equals(c)) return R.color.char_3;
        if (Achievement.MONTHLY.equals(c)) return R.color.char_4;
        return R.color.char_1;
    }

    private static int categorySoft(String c) {
        if (Achievement.PARTY.equals(c)) return R.color.char_2_soft;
        if (Achievement.FUN.equals(c)) return R.color.char_3_soft;
        if (Achievement.MONTHLY.equals(c)) return R.color.char_4_soft;
        return R.color.char_1_soft;
    }

    private static String categoryIcon(String c) {
        if (Achievement.PARTY.equals(c)) return "♣";
        if (Achievement.FUN.equals(c)) return "★";
        if (Achievement.MONTHLY.equals(c)) return "♛";
        return "✓";
    }

    private void showInvite() {
        if (party == null) return;
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("초대 코드")
                .setMessage(party.inviteCode + "\n\n현재 인원 " + party.size() + " / " + Party.MAX_MEMBERS)
                .setPositiveButton("공유하기", (dlg, w) -> PartyJoinActivity.shareCode(requireContext(), party))
                .setNegativeButton("닫기", null)
                .show();
    }

    private void confirmLeave() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("파티 나가기")
                .setMessage("파티를 나가면 캐릭터 선택이 해제돼요. 레벨과 포인트 기록은 유지됩니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("나가기", (dlg, w) -> Async.run(() -> {
                    repo.leaveParty();
                    return true;
                }, ok -> {
                    if (isAdded()) Router.go(requireActivity(), PartyJoinActivity.class);
                }, this::toast))
                .show();
    }

    private void toast(String msg) {
        if (isAdded()) Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
