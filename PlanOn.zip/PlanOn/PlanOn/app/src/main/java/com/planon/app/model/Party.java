package com.planon.app.model;

import java.util.ArrayList;
import java.util.List;

public class Party {
    public static final int MAX_MEMBERS = 4;

    public long id;
    public String name;
    public String inviteCode;
    public long leaderId;
    public List<Member> members = new ArrayList<>();

    public Member findMember(long userId) {
        if (members == null) return null;
        for (Member m : members) {
            if (m.userId == userId) return m;
        }
        return null;
    }

    public int size() {
        return members == null ? 0 : members.size();
    }
}
