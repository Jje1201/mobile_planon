package com.planon.app.model;

import java.util.ArrayList;
import java.util.List;

public class RankingResult {
    public static final String WEEK_CURRENT = "WEEK_CURRENT";
    public static final String WEEK_LAST = "WEEK_LAST";
    public static final String MONTH_CURRENT = "MONTH_CURRENT";
    public static final String MONTH_LAST = "MONTH_LAST";

    /** 위 네 값 중 하나 */
    public String period;
    /** 집계 기간 시작 (주간: 월요일, 월간: 1일, yyyy-MM-dd) */
    public String weekStart;
    /** 집계 기간 끝 (주간: 일요일, 월간: 말일) */
    public String weekEnd;
    /** true: 결산 완료(경험치 지급됨), false: 실시간 집계 중 */
    public boolean settled;
    public List<RankEntry> entries = new ArrayList<>();

    public boolean isMonthly() {
        return MONTH_CURRENT.equals(period) || MONTH_LAST.equals(period);
    }
}
