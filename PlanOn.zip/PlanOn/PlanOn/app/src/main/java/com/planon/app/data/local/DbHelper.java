package com.planon.app.data.local;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * 휴대폰 내부 SQLite 데이터베이스.
 *
 * - session / settings 테이블: 로그인 정보, 푸시 토큰 등 (로컬/서버 모드 공통)
 * - 나머지 테이블: 로컬 데모 모드에서 서버(MySQL) 역할을 대신합니다. 규칙은 서버와 같습니다.
 */
public class DbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "planon.db";
    /** 2: 사진 여러 장, 자정 확정, 알림함, 경험치 장부 · 3: 최근 로그인 계정 목록 */
    private static final int DB_VERSION = 3;
    /** 로그인 화면에 보여줄 최근 계정 수 */
    public static final int MAX_SAVED_ACCOUNTS = 5;

    public static final String KEY_PUSH_TOKEN = "push_token";
    public static final String KEY_LAST_SHOWN_NOTIFICATION = "last_shown_notification";

    private static DbHelper instance;

    public static synchronized DbHelper get(Context context) {
        if (instance == null) instance = new DbHelper(context.getApplicationContext());
        return instance;
    }

    private DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE session (" +
                "id INTEGER PRIMARY KEY CHECK (id = 1)," +
                "user_id INTEGER NOT NULL," +
                "token TEXT)");
        db.execSQL("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)");
        createSavedAccounts(db);

        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "login_id TEXT NOT NULL UNIQUE," +
                "password_hash TEXT NOT NULL," +
                "nickname TEXT NOT NULL," +
                "total_exp INTEGER NOT NULL DEFAULT 0," +
                "created_date TEXT NOT NULL)");

        db.execSQL("CREATE TABLE parties (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "invite_code TEXT NOT NULL UNIQUE," +
                "leader_id INTEGER NOT NULL," +
                "created_date TEXT NOT NULL)");

        // 한 사용자는 한 파티에만 소속 (user_id가 PK)
        db.execSQL("CREATE TABLE party_members (" +
                "user_id INTEGER PRIMARY KEY," +
                "party_id INTEGER NOT NULL," +
                "character_id INTEGER NOT NULL DEFAULT 0," +
                "joined_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE plans (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL," +
                "party_id INTEGER NOT NULL DEFAULT 0," +
                "plan_date TEXT NOT NULL," +
                "title TEXT NOT NULL," +
                "start_time TEXT," +
                "category TEXT," +
                "memo TEXT," +
                "status TEXT NOT NULL DEFAULT 'TODO'," +
                "comment TEXT," +
                "submitted_at TEXT," +
                "finalized_at TEXT," +
                "approve_count INTEGER NOT NULL DEFAULT 0," +
                "reject_count INTEGER NOT NULL DEFAULT 0," +
                "reminded INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX idx_plans_user_date ON plans(user_id, plan_date)");

        db.execSQL("CREATE TABLE plan_photos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "plan_id INTEGER NOT NULL," +
                "path TEXT NOT NULL," +
                "uploaded_at TEXT NOT NULL)");

        // 투표권은 제출 순간의 파티원으로 고정 (vote NULL = 아직 안 함), 나간 사람은 active = 0
        db.execSQL("CREATE TABLE votes (" +
                "plan_id INTEGER NOT NULL," +
                "voter_id INTEGER NOT NULL," +
                "vote INTEGER," +
                "active INTEGER NOT NULL DEFAULT 1," +
                "change_count INTEGER NOT NULL DEFAULT 0," +
                "PRIMARY KEY (plan_id, voter_id))");

        // 포인트: 일정당 한 번 (plan_id UNIQUE), 날짜는 일정 날짜
        db.execSQL("CREATE TABLE point_events (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL," +
                "plan_id INTEGER UNIQUE," +
                "points INTEGER NOT NULL," +
                "event_date TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_points_user_date ON point_events(user_id, event_date)");

        db.execSQL("CREATE TABLE weekly_settlements (" +
                "party_id INTEGER NOT NULL," +
                "week_start TEXT NOT NULL," +
                "PRIMARY KEY (party_id, week_start))");

        db.execSQL("CREATE TABLE weekly_results (" +
                "party_id INTEGER NOT NULL," +
                "week_start TEXT NOT NULL," +
                "user_id INTEGER NOT NULL," +
                "rank INTEGER NOT NULL," +
                "points INTEGER NOT NULL," +
                "done_count INTEGER NOT NULL," +
                "exp INTEGER NOT NULL," +
                "PRIMARY KEY (party_id, week_start, user_id))");

        // 경험치 장부 (users.total_exp 는 합계 캐시, 같은 트랜잭션에서만 갱신)
        db.execSQL("CREATE TABLE exp_events (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL," +
                "week_start TEXT," +
                "source TEXT NOT NULL," +
                "amount INTEGER NOT NULL," +
                "UNIQUE (user_id, week_start, source))");

        db.execSQL("CREATE TABLE notifications (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL," +
                "type TEXT NOT NULL," +
                "title TEXT NOT NULL," +
                "body TEXT NOT NULL," +
                "plan_id INTEGER," +
                "is_read INTEGER NOT NULL DEFAULT 0," +
                "created_at TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_notifications_user ON notifications(user_id, is_read)");
    }

    /** 최근 로그인 계정. scope = 서버 주소 (로컬 데모는 "local") → 서버를 바꾸면 목록도 따로 */
    private static void createSavedAccounts(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS saved_accounts (" +
                "scope TEXT NOT NULL," +
                "user_id INTEGER NOT NULL," +
                "login_id TEXT NOT NULL," +
                "nickname TEXT," +
                "character_id INTEGER NOT NULL DEFAULT 0," +
                "stage INTEGER NOT NULL DEFAULT 1," +
                "remember_token TEXT NOT NULL," +
                "last_login_at INTEGER NOT NULL," +
                "PRIMARY KEY (scope, user_id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion >= 2) {
            // 2 → 3: 테이블만 추가 (데모 데이터·로그인 유지)
            createSavedAccounts(db);
            return;
        }
        // 데모 데이터만 담고 있으므로 구조가 바뀌면 새로 만듭니다 (로그인도 다시 해야 함)
        String[] tables = {"session", "settings", "saved_accounts", "users", "parties", "party_members", "plans", "plan_photos",
                "votes", "point_events", "weekly_settlements", "weekly_results", "exp_events", "notifications"};
        for (String t : tables) db.execSQL("DROP TABLE IF EXISTS " + t);
        onCreate(db);
    }

    // ---------------- 세션 ----------------

    public synchronized long getSessionUserId() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT user_id FROM session WHERE id = 1", null)) {
            return c.moveToFirst() ? c.getLong(0) : 0;
        }
    }

    public synchronized String getSessionToken() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT token FROM session WHERE id = 1", null)) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    public synchronized void saveSession(long userId, String token) {
        ContentValues v = new ContentValues();
        v.put("id", 1);
        v.put("user_id", userId);
        v.put("token", token);
        getWritableDatabase().insertWithOnConflict("session", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void clearSession() {
        getWritableDatabase().delete("session", null, null);
    }

    // ---------------- 최근 로그인 계정 ----------------

    public synchronized java.util.List<com.planon.app.model.SavedAccount> getSavedAccounts(String scope) {
        java.util.List<com.planon.app.model.SavedAccount> list = new java.util.ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT user_id, login_id, nickname, character_id, stage, "
                + "remember_token, last_login_at FROM saved_accounts WHERE scope = ? ORDER BY last_login_at DESC LIMIT "
                + MAX_SAVED_ACCOUNTS, new String[]{scope})) {
            while (c.moveToNext()) {
                com.planon.app.model.SavedAccount a = new com.planon.app.model.SavedAccount();
                a.userId = c.getLong(0);
                a.loginId = c.getString(1);
                a.nickname = c.getString(2);
                a.characterId = c.getInt(3);
                a.stage = c.getInt(4);
                a.rememberToken = c.getString(5);
                a.lastLoginAt = c.getLong(6);
                list.add(a);
            }
        }
        return list;
    }

    /** 로그인 성공 때 저장·갱신. 오래된 계정은 MAX_SAVED_ACCOUNTS 개만 남기고 정리 */
    public synchronized void saveAccount(String scope, com.planon.app.model.User u, String rememberToken) {
        if (u == null || rememberToken == null) return;
        ContentValues v = new ContentValues();
        v.put("scope", scope);
        v.put("user_id", u.id);
        v.put("login_id", u.loginId);
        v.put("nickname", u.nickname);
        v.put("character_id", u.characterId);
        v.put("stage", u.getStage());
        v.put("remember_token", rememberToken);
        v.put("last_login_at", System.currentTimeMillis());
        SQLiteDatabase db = getWritableDatabase();
        db.insertWithOnConflict("saved_accounts", null, v, SQLiteDatabase.CONFLICT_REPLACE);
        db.execSQL("DELETE FROM saved_accounts WHERE scope = ? AND user_id NOT IN (SELECT user_id FROM saved_accounts "
                + "WHERE scope = ? ORDER BY last_login_at DESC LIMIT " + MAX_SAVED_ACCOUNTS + ")", new Object[]{scope, scope});
    }

    /** 내 정보를 새로 받을 때마다 목록의 닉네임·캐릭터 갱신 (저장된 계정일 때만) */
    public synchronized void updateSavedProfile(String scope, com.planon.app.model.User u) {
        if (u == null) return;
        ContentValues v = new ContentValues();
        v.put("nickname", u.nickname);
        v.put("character_id", u.characterId);
        v.put("stage", u.getStage());
        getWritableDatabase().update("saved_accounts", v, "scope = ? AND user_id = ?", new String[]{scope, String.valueOf(u.id)});
    }

    public synchronized void touchSavedAccount(String scope, long userId) {
        ContentValues v = new ContentValues();
        v.put("last_login_at", System.currentTimeMillis());
        getWritableDatabase().update("saved_accounts", v, "scope = ? AND user_id = ?", new String[]{scope, String.valueOf(userId)});
    }

    public synchronized void deleteSavedAccount(String scope, long userId) {
        getWritableDatabase().delete("saved_accounts", "scope = ? AND user_id = ?", new String[]{scope, String.valueOf(userId)});
    }

    // ---------------- 설정 ----------------

    public synchronized String getSetting(String key) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT value FROM settings WHERE key = ?", new String[]{key})) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    public synchronized void putSetting(String key, String value) {
        ContentValues v = new ContentValues();
        v.put("key", key);
        v.put("value", value);
        getWritableDatabase().insertWithOnConflict("settings", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }
}
