package com.planon.app.model;

/** 알림함 한 줄 (서버 NotificationDto 와 같은 필드) */
public class AppNotification {
    public static final String VOTE_REQUEST = "VOTE_REQUEST";
    public static final String VOTE_REMINDER = "VOTE_REMINDER";
    public static final String VOTE_RECEIVED = "VOTE_RECEIVED";
    public static final String VERIFY_RESULT = "VERIFY_RESULT";
    public static final String PLAN_MISSED = "PLAN_MISSED";
    public static final String PHOTO_ADDED = "VERIFICATION_PHOTO_ADDED";
    public static final String WEEKLY_SETTLED = "WEEKLY_SETTLED";
    public static final String LEVEL_UP = "LEVEL_UP";
    public static final String CHARACTER_GROWN = "CHARACTER_GROWN";
    public static final String PARTY_JOINED = "PARTY_JOINED";
    public static final String PARTY_LEFT = "PARTY_LEFT";
    public static final String ACHIEVEMENT_UNLOCKED = "ACHIEVEMENT_UNLOCKED";
    public static final String MONTHLY_RANKING = "MONTHLY_RANKING";

    public long id;
    public String type;
    public String title;
    public String body;
    /** 관련 일정 (없으면 null) */
    public Long planId;
    public boolean read;
    /** yyyy-MM-ddTHH:mm */
    public String createdAt;
}
