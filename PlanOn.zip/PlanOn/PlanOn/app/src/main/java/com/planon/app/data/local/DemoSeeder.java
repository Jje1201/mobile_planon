package com.planon.app.data.local;

import android.content.ContentValues;
import android.content.Context;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.planon.app.model.AppNotification;
import com.planon.app.model.Plan;
import com.planon.app.util.DateUtil;
import com.planon.app.util.LevelRule;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 로컬 데모 모드용 샘플 데이터.
 * 계정: demo1 ~ demo4 / 비밀번호 demo1234 (모두 같은 파티)
 * 지난 일정은 결과가 확정된 상태로, 오늘 일정 일부는 투표 중(VOTING)으로 만듭니다.
 */
final class DemoSeeder {
    private DemoSeeder() {
    }

    static final String PASSWORD = "demo1234";
    private static final String[] IDS = {"demo1", "demo2", "demo3", "demo4"};
    private static final String[] NICKS = {"지민", "도윤", "서연", "하준"};
    /** 시작 경험치 (장부에 ADJUST 로 기록) → 대략 Lv.13 / 14 / 10 / 8 */
    private static final int[] START_EXP = {300, 340, 210, 140};
    /** 지난주(월~일) 인정 / 미인정 / 미인증 일정 수 */
    private static final int[][] LAST_WEEK = {{12, 0, 1}, {11, 1, 0}, {6, 2, 2}, {5, 0, 3}};
    private static final String[] TITLES = {"영단어 30개", "전공 복습 1시간", "러닝 3km", "독서 20쪽", "알고리즘 1문제"};

    static String seed(Context context, SQLiteDatabase db) throws IOException {
        long exists = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM users WHERE login_id = ?", new String[]{IDS[0]});
        if (exists > 0) return "이미 데모 데이터가 있어요. demo1~demo4 / " + PASSWORD + " 로 로그인하세요.";

        LocalDate today = DateUtil.today();
        LocalDate thisMon = DateUtil.weekStart(today);
        LocalDate lastMon = thisMon.minusWeeks(1);
        String created = DateUtil.format(lastMon.minusWeeks(1)); // 2주 전에 만든 파티 → 지난주 결산 대상

        File proofDir = new File(context.getFilesDir(), "proofs");
        if (!proofDir.exists() && !proofDir.mkdirs()) throw new IOException("폴더 생성 실패");

        db.beginTransaction();
        try {
            long[] uid = new long[4];
            for (int i = 0; i < 4; i++) {
                ContentValues u = new ContentValues();
                u.put("login_id", IDS[i]);
                u.put("password_hash", LocalRepository.hash(IDS[i], PASSWORD));
                u.put("nickname", NICKS[i]);
                u.put("total_exp", START_EXP[i]);
                u.put("created_date", created);
                uid[i] = db.insertOrThrow("users", null, u);

                ContentValues e = new ContentValues();
                e.put("user_id", uid[i]);
                e.put("source", "ADJUST");
                e.put("amount", START_EXP[i]);
                db.insertOrThrow("exp_events", null, e);
            }

            String code = "DEMO42";
            if (DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM parties WHERE invite_code = ?",
                    new String[]{code}) > 0) code = "DEMO" + (10 + (int) (Math.random() * 89));
            ContentValues p = new ContentValues();
            p.put("name", "기말고사 정복단");
            p.put("invite_code", code);
            p.put("leader_id", uid[0]);
            p.put("created_date", created);
            long partyId = db.insertOrThrow("parties", null, p);

            long now = System.currentTimeMillis();
            for (int i = 0; i < 4; i++) {
                ContentValues m = new ContentValues();
                m.put("user_id", uid[i]);
                m.put("party_id", partyId);
                m.put("character_id", i + 1);
                m.put("joined_at", now + i);
                db.insertOrThrow("party_members", null, m);
            }

            // 지난주: 결과가 확정된 일정 (월요일 결산은 앱이 열릴 때 자동으로 실행됨)
            for (int i = 0; i < 4; i++) {
                int k = 0;
                for (int n = 0; n < LAST_WEEK[i][0]; n++, k++) {
                    finished(db, uid, i, partyId, lastMon.plusDays(k % 7), TITLES[k % TITLES.length], Plan.APPROVED);
                }
                for (int n = 0; n < LAST_WEEK[i][1]; n++, k++) {
                    finished(db, uid, i, partyId, lastMon.plusDays(k % 7), TITLES[k % TITLES.length], Plan.REJECTED);
                }
                for (int n = 0; n < LAST_WEEK[i][2]; n++, k++) {
                    finished(db, uid, i, partyId, lastMon.plusDays(k % 7), TITLES[k % TITLES.length], Plan.MISSED);
                }
            }

            // 이번 주 오늘 이전: 확정된 일정 몇 개
            for (LocalDate d = thisMon; d.isBefore(today); d = d.plusDays(1)) {
                for (int i = 0; i < 4; i++) {
                    String status = (i == 3 && d.getDayOfMonth() % 2 == 0) ? Plan.MISSED : Plan.APPROVED;
                    finished(db, uid, i, partyId, d, TITLES[(i + d.getDayOfMonth()) % TITLES.length], status);
                }
            }

            // 오늘
            String yy = DateUtil.format(today);
            plan(db, uid[0], partyId, today, "영단어 50개 암기", "09:00", "공부", Plan.VOTING, "아침에 끝!");
            long algo = plan(db, uid[0], partyId, today, "알고리즘 문제 3개", "13:00", "공부", Plan.VOTING, "백준 3문제 완료!");
            photo(db, algo, fakePhoto(proofDir, "algo1", "알고리즘 풀이 화면", Color.rgb(52, 87, 213)));
            photo(db, algo, fakePhoto(proofDir, "algo2", "제출 결과 '맞았습니다'", Color.rgb(39, 174, 96)));
            voters(db, algo, uid, 0);
            vote(db, algo, uid[2], 1);
            plan(db, uid[0], partyId, today, "운동 30분", "19:00", "운동", Plan.TODO, null);
            plan(db, uid[0], partyId, today.plusDays(1), "스터디 발표 자료 만들기", "15:00", "공부", Plan.TODO, null);

            long gym = plan(db, uid[1], partyId, today, "헬스장 가기", "18:00", "운동", Plan.VOTING, "하체 루틴 완료");
            photo(db, gym, fakePhoto(proofDir, "gym", "헬스장 인증샷", Color.rgb(242, 153, 74)));
            voters(db, gym, uid, 1);
            vote(db, gym, uid[3], -1);
            plan(db, uid[1], partyId, today, "일기 쓰기", "22:00", "생활", Plan.TODO, null);

            plan(db, uid[2], partyId, today, "코딩 테스트 연습", "15:00", "공부", Plan.TODO, null);
            plan(db, uid[2], partyId, today, "방 청소", "20:00", "생활", Plan.TODO, null);
            plan(db, uid[3], partyId, today, "자격증 기출 2회", "10:00", "공부", Plan.TODO, null);
            plan(db, uid[3], partyId, today, "스트레칭 15분", "22:30", "운동", Plan.TODO, null);

            // 첫 번째 일정의 사진 + 투표권
            long first = DatabaseUtils.longForQuery(db, "SELECT id FROM plans WHERE user_id = ? AND plan_date = ? AND title = ?",
                    new String[]{String.valueOf(uid[0]), yy, "영단어 50개 암기"});
            photo(db, first, fakePhoto(proofDir, "voca", "단어장 체크 완료", Color.rgb(187, 107, 217)));
            voters(db, first, uid, 0);

            note(db, uid[0], AppNotification.VOTE_REQUEST, "인증 검토 요청", "도윤님이 '헬스장 가기' 인증을 올렸어요. 자정 전까지 투표해 주세요", gym);
            note(db, uid[1], AppNotification.VOTE_RECEIVED, "미인정 표를 받았어요",
                    "'헬스장 가기' 인증에 미인정 표가 있어요. 23:30 전까지 사진을 더 올릴 수 있어요", gym);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return "데모 데이터를 만들었어요. demo1~demo4 / " + PASSWORD + " 로 로그인할 수 있어요.";
    }

    /** 결과가 확정된 지난 일정 + 포인트 */
    private static void finished(SQLiteDatabase db, long[] uid, int owner, long partyId, LocalDate date, String title, String status) {
        long id = plan(db, uid[owner], partyId, date, title, null, "공부", status, null);
        db.execSQL("UPDATE plans SET finalized_at = ? WHERE id = ?", new Object[]{DateUtil.format(date) + "T23:59:59", id});
        if (Plan.MISSED.equals(status)) return;
        // 투표권 + 표 (검토 참여 경험치 계산에 쓰임): 모두 투표한 것으로
        int value = Plan.APPROVED.equals(status) ? 1 : -1;
        for (int i = 0; i < uid.length; i++) {
            if (i == owner) continue;
            db.execSQL("INSERT INTO votes (plan_id, voter_id, vote, active) VALUES (?, ?, ?, 1)", new Object[]{id, uid[i], value});
        }
        db.execSQL("UPDATE plans SET approve_count = ?, reject_count = ? WHERE id = ?",
                new Object[]{value > 0 ? 3 : 0, value < 0 ? 3 : 0, id});
        ContentValues e = new ContentValues();
        e.put("user_id", uid[owner]);
        e.put("plan_id", id);
        e.put("points", value > 0 ? LevelRule.PLAN_POINT : -LevelRule.FAIL_PENALTY);
        e.put("event_date", DateUtil.format(date));
        db.insertOrThrow("point_events", null, e);
    }

    private static long plan(SQLiteDatabase db, long userId, long partyId, LocalDate date, String title,
                             String time, String category, String status, String comment) {
        ContentValues v = new ContentValues();
        v.put("user_id", userId);
        v.put("party_id", partyId);
        v.put("plan_date", DateUtil.format(date));
        v.put("title", title);
        v.put("start_time", time);
        v.put("category", category);
        v.put("status", status);
        v.put("comment", comment);
        if (!Plan.TODO.equals(status) && !Plan.MISSED.equals(status)) {
            v.put("submitted_at", DateUtil.format(date) + "T" + (time != null ? time : "12:00") + ":00");
        }
        return db.insertOrThrow("plans", null, v);
    }

    private static void photo(SQLiteDatabase db, long planId, String path) {
        ContentValues v = new ContentValues();
        v.put("plan_id", planId);
        v.put("path", path);
        v.put("uploaded_at", LocalDateTime.now().withNano(0).toString());
        db.insertOrThrow("plan_photos", null, v);
    }

    /** 제출 순간의 파티원(본인 제외)에게 투표권 */
    private static void voters(SQLiteDatabase db, long planId, long[] uid, int owner) {
        for (int i = 0; i < uid.length; i++) {
            if (i == owner) continue;
            db.execSQL("INSERT INTO votes (plan_id, voter_id, vote, active) VALUES (?, ?, NULL, 1)", new Object[]{planId, uid[i]});
        }
    }

    private static void vote(SQLiteDatabase db, long planId, long voterId, int value) {
        db.execSQL("UPDATE votes SET vote = ? WHERE plan_id = ? AND voter_id = ?", new Object[]{value, planId, voterId});
    }

    private static void note(SQLiteDatabase db, long userId, String type, String title, String body, long planId) {
        ContentValues v = new ContentValues();
        v.put("user_id", userId);
        v.put("type", type);
        v.put("title", title);
        v.put("body", body);
        v.put("plan_id", planId);
        v.put("is_read", 0);
        v.put("created_at", LocalDateTime.now().withNano(0).toString().substring(0, 16));
        db.insertOrThrow("notifications", null, v);
    }

    /** 데모용 가짜 인증 사진 */
    private static String fakePhoto(File dir, String name, String label, int color) throws IOException {
        Bitmap bmp = Bitmap.createBitmap(900, 675, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.drawColor(color);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(60f);
        canvas.drawText(label, 450f, 330f, paint);
        paint.setTextSize(36f);
        canvas.drawText("(데모 인증 사진)", 450f, 400f, paint);
        File out = new File(dir, "demo_" + name + ".jpg");
        try (FileOutputStream fos = new FileOutputStream(out)) {
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, fos);
        }
        bmp.recycle();
        return out.getAbsolutePath();
    }
}
