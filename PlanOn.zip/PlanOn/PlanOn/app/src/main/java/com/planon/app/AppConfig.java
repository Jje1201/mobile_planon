package com.planon.app;

/**
 * 실행 모드 설정.
 *
 * USE_REMOTE_SERVER = false
 *   → 서버 없이 휴대폰 안의 SQLite만으로 모든 기능이 동작하는 "로컬 데모 모드".
 *     한 기기에서 여러 계정으로 로그인해 파티/인증/랭킹을 시험해 볼 수 있습니다.
 *
 * USE_REMOTE_SERVER = true (기본값)
 *   → Spring 서버(+MySQL)와 Retrofit으로 통신합니다 (docs/server-api.md, docs/connect-guide.md).
 */
public final class AppConfig {
    private AppConfig() {
    }

    public static final boolean USE_REMOTE_SERVER = true;

    /**
     * Spring 서버 주소 (마지막 / 필수)
     * - AWS 서버 : http://3.106.147.85:8080/s
     * - 실제 휴대폰 → 같은 Wi-Fi에 있는 PC의 IP : http://192.168.0.10:8080/
     * 앱을 다시 빌드하지 않아도 로그인 화면 아래 "서버 주소" 버튼에서 바꿀 수 있습니다.
     */
    public static final String BASE_URL = "http://3.106.147.85:8080/";
}
