package com.planon.app.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.util.Async;
import com.planon.app.util.DateUtil;
import com.planon.app.util.LevelRule;

import java.util.Locale;

/** 캘린더에서 날짜 선택 → 일정 추가 (바텀시트) */
public class AddPlanBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_DATE = "date";

    private final Repository repo = RepositoryProvider.get();
    private String time = null;

    public static AddPlanBottomSheet newInstance(String date) {
        AddPlanBottomSheet f = new AddPlanBottomSheet();
        Bundle b = new Bundle();
        b.putString(ARG_DATE, date);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_add_plan, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        String date = requireArguments().getString(ARG_DATE, DateUtil.todayStr());

        ((TextView) v.findViewById(R.id.text_date)).setText(DateUtil.korean(DateUtil.parse(date)));
        ((TextView) v.findViewById(R.id.text_point_plus)).setText(
                "당일 " + LevelRule.PHOTO_DEADLINE + "까지 사진 인증 → 자정에 인정되면 +" + LevelRule.PLAN_POINT + "P");
        ((TextView) v.findViewById(R.id.text_point_minus)).setText(
                "미인정이 인정보다 많으면 −" + LevelRule.FAIL_PENALTY + "P · 인증 안 하면 0P");

        TextInputEditText editTitle = v.findViewById(R.id.edit_title);
        TextInputEditText editMemo = v.findViewById(R.id.edit_memo);
        ChipGroup chips = v.findViewById(R.id.chip_category);
        MaterialButton btnTime = v.findViewById(R.id.btn_time);
        MaterialButton btnSave = v.findViewById(R.id.btn_save);

        btnTime.setOnClickListener(x -> {
            MaterialTimePicker picker = new MaterialTimePicker.Builder()
                    .setTimeFormat(TimeFormat.CLOCK_24H)
                    .setHour(9)
                    .setMinute(0)
                    .setTitleText("시작 시간")
                    .build();
            picker.addOnPositiveButtonClickListener(p -> {
                time = String.format(Locale.KOREA, "%02d:%02d", picker.getHour(), picker.getMinute());
                btnTime.setText("시작 시간 " + time);
                btnTime.setTextColor(ContextCompat.getColor(requireContext(), R.color.ink));
            });
            picker.show(getChildFragmentManager(), "time");
        });

        btnSave.setOnClickListener(x -> {
            String title = editTitle.getText() == null ? "" : editTitle.getText().toString().trim();
            if (title.isEmpty()) {
                editTitle.setError("일정 제목을 입력해 주세요");
                return;
            }
            Chip checked = v.findViewById(chips.getCheckedChipId());
            String category = checked == null ? null : checked.getText().toString();
            String memo = editMemo.getText() == null ? "" : editMemo.getText().toString().trim();

            btnSave.setEnabled(false);
            Async.run(() -> repo.addPlan(date, title, time, category, memo), plan -> {
                if (!isAdded()) return;
                Toast.makeText(requireContext(), "일정을 추가했어요", Toast.LENGTH_SHORT).show();
                getParentFragmentManager().setFragmentResult(HomeFragment.RESULT_PLAN_ADDED, new Bundle());
                dismiss();
            }, msg -> {
                if (!isAdded()) return;
                btnSave.setEnabled(true);
                Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
            });
        });
    }
}
