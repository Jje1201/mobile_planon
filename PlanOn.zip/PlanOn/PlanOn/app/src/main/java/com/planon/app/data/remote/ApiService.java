package com.planon.app.data.remote;

import com.planon.app.model.AchievementList;
import com.planon.app.model.AppNotification;
import com.planon.app.model.Party;
import com.planon.app.model.Plan;
import com.planon.app.model.RankingResult;
import com.planon.app.model.User;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Spring 서버 REST API 목록 (docs/server-api.md).
 * 로그인 후 모든 요청에는 "Authorization: Bearer {token}" 헤더가 붙습니다.
 */
public interface ApiService {

    @GET("api/health")
    Call<Void> health();

    @GET("api/auth/check-id")
    Call<Dtos.AvailableResponse> checkLoginId(@Query("loginId") String loginId);

    @POST("api/auth/signup")
    Call<User> signUp(@Body Dtos.SignUpRequest body);

    @POST("api/auth/login")
    Call<Dtos.LoginResponse> login(@Body Dtos.LoginRequest body);

    @POST("api/auth/quick-login")
    Call<Dtos.LoginResponse> quickLogin(@Body Dtos.QuickLoginRequest body);

    @POST("api/auth/forget")
    Call<Void> forget(@Body Dtos.QuickLoginRequest body);

    @GET("api/users/me")
    Call<User> me();

    @POST("api/parties")
    Call<Party> createParty(@Body Dtos.PartyCreateRequest body);

    @POST("api/parties/join")
    Call<Party> joinParty(@Body Dtos.JoinRequest body);

    /** 파티가 없으면 204 No Content */
    @GET("api/parties/my")
    Call<Party> myParty();

    @DELETE("api/parties/my/members/me")
    Call<Void> leaveParty();

    @PUT("api/parties/my/character")
    Call<Void> selectCharacter(@Body Dtos.CharacterRequest body);

    @GET("api/plans")
    Call<List<Plan>> plans(@Query("userId") long userId, @Query("date") String date);

    @GET("api/plans/dates")
    Call<List<String>> planDates(@Query("yearMonth") String yearMonth);

    @POST("api/plans")
    Call<Plan> addPlan(@Body Dtos.PlanRequest body);

    @DELETE("api/plans/{id}")
    Call<Void> deletePlan(@Path("id") long planId);

    /** images: 같은 이름("images")의 파트를 여러 개 */
    @Multipart
    @POST("api/plans/{id}/verification")
    Call<Plan> submitVerification(@Path("id") long planId,
                                  @Part List<MultipartBody.Part> images,
                                  @Part("comment") RequestBody comment);

    @Multipart
    @POST("api/plans/{id}/verification/photos")
    Call<Plan> addPhotos(@Path("id") long planId, @Part List<MultipartBody.Part> images);

    @DELETE("api/plans/{id}/verification/photos/{photoId}")
    Call<Plan> deletePhoto(@Path("id") long planId, @Path("photoId") long photoId);

    @Multipart
    @POST("api/plans/{id}/verification/photos/{photoId}/replace")
    Call<Plan> replacePhoto(@Path("id") long planId, @Path("photoId") long photoId, @Part MultipartBody.Part image);

    @GET("api/plans/{id}/verification")
    Call<Plan> verification(@Path("id") long planId);

    @POST("api/plans/{id}/votes")
    Call<Plan> vote(@Path("id") long planId, @Body Dtos.VoteRequest body);

    /** week = "current" | "last" */
    @GET("api/rankings/weekly")
    Call<RankingResult> weeklyRanking(@Query("week") String week);

    /** month = "current" | "last" */
    @GET("api/rankings/monthly")
    Call<RankingResult> monthlyRanking(@Query("month") String month);

    @GET("api/achievements")
    Call<AchievementList> achievements();

    @GET("api/notifications")
    Call<List<AppNotification>> notifications(@Query("limit") int limit);

    @GET("api/notifications/unread-count")
    Call<Dtos.CountResponse> unreadCount();

    @PATCH("api/notifications/{id}/read")
    Call<Void> markRead(@Path("id") long id);

    @PATCH("api/notifications/read-all")
    Call<Void> markAllRead();

    @PUT("api/device-tokens")
    Call<Void> saveDeviceToken(@Body Dtos.TokenRequest body);

    @DELETE("api/device-tokens")
    Call<Void> deleteDeviceToken(@Query("token") String token);
}
