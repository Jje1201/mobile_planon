package com.planon.app.util;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;

public final class DateUtil {
    private DateUtil() {
    }

    public static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE; // yyyy-MM-dd

    public static LocalDate today() {
        return LocalDate.now();
    }

    public static String todayStr() {
        return today().format(ISO);
    }

    public static String format(LocalDate d) {
        return d.format(ISO);
    }

    public static LocalDate parse(String s) {
        return LocalDate.parse(s, ISO);
    }

    /** 해당 날짜가 속한 주의 월요일 */
    public static LocalDate weekStart(LocalDate d) {
        return d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    }

    /** "10월 14일 (수)" */
    public static String korean(LocalDate d) {
        return d.getMonthValue() + "월 " + d.getDayOfMonth() + "일 (" + dayName(d) + ")";
    }

    /** "10/14(수)" */
    public static String shortKorean(LocalDate d) {
        return d.getMonthValue() + "/" + d.getDayOfMonth() + "(" + dayName(d) + ")";
    }

    public static String dayName(LocalDate d) {
        return d.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.KOREAN);
    }

    /** 다음 월요일까지 남은 일수 */
    public static long daysUntilNextMonday() {
        LocalDate next = weekStart(today()).plusWeeks(1);
        return ChronoUnit.DAYS.between(today(), next);
    }
}
