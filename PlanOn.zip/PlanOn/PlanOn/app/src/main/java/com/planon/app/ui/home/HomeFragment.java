package com.planon.app.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.Member;
import com.planon.app.model.Party;
import com.planon.app.model.Plan;
import com.planon.app.model.User;
import com.planon.app.ui.Router;
import com.planon.app.ui.notification.NotificationActivity;
import com.planon.app.ui.party.PartyJoinActivity;
import com.planon.app.ui.verify.VerifyReviewActivity;
import com.planon.app.ui.verify.VerifyUploadActivity;
import com.planon.app.util.Async;
import com.planon.app.util.Characters;
import com.planon.app.util.DateUtil;
import com.planon.app.util.LevelRule;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Set;

/**
 * 홈: 공유형 캘린더 + 팀원별 오늘 진행도 + 팀원별 오늘의 계획
 * - 다른 날짜를 고르면 그 날짜의 "내 일정"만 보여줍니다. (팀원 일정은 당일만 열람)
 */
public class HomeFragment extends Fragment implements PlanAdapter.Listener {

    public static final String RESULT_PLAN_ADDED = "plan_added";

    private final Repository repo = RepositoryProvider.get();

    private TextView textPartyMeta, textPartyName, textMonth, textPlansTitle, textPlansHint, textEmpty, textBadge;
    private LinearLayout containerProgress;
    private ChipGroup chipMembers;
    private View scrollMembers;
    private MaterialButton btnAddPlan;
    private CalendarAdapter calendarAdapter;
    private PlanAdapter planAdapter;

    private YearMonth shownMonth = YearMonth.now();
    private LocalDate selectedDate = DateUtil.today();
    /** 오늘 일정 목록에서 보고 있는 파티원 (0이면 나) */
    private long selectedMemberId = 0;

    private User me;
    private Party party;

    private static class HomeData {
        User me;
        Party party;
        Set<String> planDates;
        List<Plan> plans;
        long targetId;
        int unread;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        textPartyMeta = v.findViewById(R.id.text_party_meta);
        textPartyName = v.findViewById(R.id.text_party_name);
        textMonth = v.findViewById(R.id.text_month);
        textPlansTitle = v.findViewById(R.id.text_plans_title);
        textPlansHint = v.findViewById(R.id.text_plans_hint);
        textEmpty = v.findViewById(R.id.text_plans_empty);
        containerProgress = v.findViewById(R.id.container_progress);
        chipMembers = v.findViewById(R.id.chip_members);
        scrollMembers = v.findViewById(R.id.scroll_members);
        btnAddPlan = v.findViewById(R.id.btn_add_plan);
        textBadge = v.findViewById(R.id.text_badge);
        v.findViewById(R.id.btn_notifications).setOnClickListener(x ->
                startActivity(new Intent(requireContext(), NotificationActivity.class)));

        RecyclerView rvCalendar = v.findViewById(R.id.recycler_calendar);
        rvCalendar.setLayoutManager(new GridLayoutManager(requireContext(), 7));
        calendarAdapter = new CalendarAdapter(this::onDaySelected);
        rvCalendar.setAdapter(calendarAdapter);

        RecyclerView rvPlans = v.findViewById(R.id.recycler_plans);
        rvPlans.setLayoutManager(new LinearLayoutManager(requireContext()));
        planAdapter = new PlanAdapter(this);
        rvPlans.setAdapter(planAdapter);

        v.findViewById(R.id.btn_prev_month).setOnClickListener(x -> changeMonth(-1));
        v.findViewById(R.id.btn_next_month).setOnClickListener(x -> changeMonth(1));
        v.findViewById(R.id.btn_invite).setOnClickListener(x -> showInviteDialog());
        btnAddPlan.setOnClickListener(x ->
                AddPlanBottomSheet.newInstance(DateUtil.format(selectedDate))
                        .show(getChildFragmentManager(), "add_plan"));

        getChildFragmentManager().setFragmentResultListener(RESULT_PLAN_ADDED, getViewLifecycleOwner(),
                (key, bundle) -> load());

        updateCalendarHeader();
        calendarAdapter.setMonth(shownMonth, selectedDate);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isHidden()) load();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) load();
    }

    // ------------------------------------------------------------------
    // 데이터 불러오기
    // ------------------------------------------------------------------

    private void load() {
        final LocalDate date = selectedDate;
        final YearMonth month = shownMonth;
        final long wanted = selectedMemberId;
        Async.run(() -> {
            HomeData d = new HomeData();
            d.me = repo.getMe();
            d.party = repo.getMyParty();
            if (d.party == null) return d;
            d.unread = repo.getUnreadCount();
            d.planDates = repo.getMyPlanDates(month.toString());
            boolean today = date.equals(DateUtil.today());
            long target = (today && wanted > 0 && d.party.findMember(wanted) != null) ? wanted : d.me.id;
            d.plans = repo.getPlans(target, DateUtil.format(date));
            d.targetId = target;
            return d;
        }, this::bind, this::toast);
    }

    private void loadPlansOnly() {
        if (me == null) return;
        final LocalDate date = selectedDate;
        final long target = selectedMemberId > 0 ? selectedMemberId : me.id;
        Async.run(() -> repo.getPlans(target, DateUtil.format(date)), plans -> {
            if (!isAdded()) return;
            showPlans(plans);
        }, this::toast);
    }

    private void bind(HomeData d) {
        if (!isAdded()) return;
        if (d.party == null) {
            Router.go(requireActivity(), PartyJoinActivity.class);
            return;
        }
        me = d.me;
        party = d.party;
        selectedMemberId = d.targetId;

        textPartyMeta.setText("내 파티 · " + party.size() + "/" + Party.MAX_MEMBERS + "명");
        textPartyName.setText(party.name);
        calendarAdapter.setPlanDates(d.planDates);
        textBadge.setVisibility(d.unread > 0 ? View.VISIBLE : View.GONE);
        textBadge.setText(d.unread > 99 ? "99+" : String.valueOf(d.unread));

        bindProgress();
        bindPlanHeader();
        showPlans(d.plans);
    }

    private void bindProgress() {
        containerProgress.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        for (Member m : party.members) {
            View row = inflater.inflate(R.layout.item_member_progress, containerProgress, false);
            Characters.bindFace(row.findViewById(R.id.image_avatar), m.characterId, m.getStage());
            String name = m.nickname + (m.userId == me.id ? " (나)" : "") + (m.leader ? " · 파티장" : "");
            ((TextView) row.findViewById(R.id.text_name)).setText(name + "  " + m.todayDone + "/" + m.todayTotal);
            ((TextView) row.findViewById(R.id.text_percent)).setText(m.getTodayPercent() + "%");
            LinearProgressIndicator bar = row.findViewById(R.id.progress);
            bar.setIndicatorColor(androidx.core.content.ContextCompat.getColor(requireContext(), Characters.color(m.characterId)));
            bar.setTrackColor(androidx.core.content.ContextCompat.getColor(requireContext(), Characters.softColor(m.characterId)));
            bar.setProgressCompat(m.getTodayPercent(), false);
            containerProgress.addView(row);
        }
    }

    private void bindPlanHeader() {
        boolean today = selectedDate.equals(DateUtil.today());
        boolean past = selectedDate.isBefore(DateUtil.today());

        boolean afterDeadline = today && !java.time.LocalTime.now().isBefore(
                java.time.LocalTime.of(LevelRule.PHOTO_DEADLINE_HOUR, LevelRule.PHOTO_DEADLINE_MINUTE));
        boolean tooFar = selectedDate.isAfter(DateUtil.today().plusDays(30));
        btnAddPlan.setEnabled(!past && !afterDeadline && !tooFar);
        btnAddPlan.setText(past ? "지난 날짜에는 일정을 추가할 수 없어요"
                : afterDeadline ? "오늘 일정은 " + LevelRule.PHOTO_DEADLINE + "까지만 추가할 수 있어요"
                : tooFar ? "일정은 30일 뒤까지만 만들 수 있어요"
                : selectedDate.getMonthValue() + "월 " + selectedDate.getDayOfMonth() + "일에 내 일정 추가");

        if (today) {
            textPlansTitle.setText("오늘의 계획");
            textPlansHint.setText("팀원 일정은 당일만 열람");
            scrollMembers.setVisibility(View.VISIBLE);
            buildMemberChips();
        } else {
            textPlansTitle.setText("내 일정 · " + DateUtil.korean(selectedDate));
            textPlansHint.setText("");
            scrollMembers.setVisibility(View.GONE);
        }
    }

    private void buildMemberChips() {
        chipMembers.setOnCheckedStateChangeListener(null);
        chipMembers.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        for (Member m : party.members) {
            Chip chip = (Chip) inflater.inflate(R.layout.item_member_chip, chipMembers, false);
            chip.setId(View.generateViewId());
            chip.setTag(m.userId);
            chip.setText(m.userId == me.id ? "나" : m.nickname);
            chip.setChecked(m.userId == selectedMemberId);
            chipMembers.addView(chip);
        }
        chipMembers.setOnCheckedStateChangeListener((group, ids) -> {
            if (ids.isEmpty()) return;
            View chip = group.findViewById(ids.get(0));
            if (chip == null) return;
            selectedMemberId = (long) chip.getTag();
            loadPlansOnly();
        });
    }

    private void showPlans(List<Plan> plans) {
        planAdapter.submit(plans, me.id);
        textEmpty.setVisibility(plans == null || plans.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ------------------------------------------------------------------
    // 캘린더
    // ------------------------------------------------------------------

    private void onDaySelected(LocalDate date) {
        selectedDate = date;
        if (!date.equals(DateUtil.today())) selectedMemberId = 0;
        calendarAdapter.setSelected(date);
        load();
    }

    private void changeMonth(int delta) {
        shownMonth = shownMonth.plusMonths(delta);
        updateCalendarHeader();
        calendarAdapter.setMonth(shownMonth, selectedDate);
        load();
    }

    private void updateCalendarHeader() {
        textMonth.setText(shownMonth.getYear() + "년 " + shownMonth.getMonthValue() + "월");
    }

    // ------------------------------------------------------------------
    // 일정 항목 동작
    // ------------------------------------------------------------------

    @Override
    public void onVerify(Plan plan) {
        Intent i = new Intent(requireContext(), VerifyUploadActivity.class);
        i.putExtra(VerifyUploadActivity.EXTRA_PLAN_ID, plan.id);
        startActivity(i);
    }

    @Override
    public void onReview(Plan plan) {
        Intent i = new Intent(requireContext(), VerifyReviewActivity.class);
        i.putExtra(VerifyReviewActivity.EXTRA_PLAN_ID, plan.id);
        startActivity(i);
    }

    @Override
    public void onDelete(Plan plan) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("일정 삭제")
                .setMessage("'" + plan.title + "' 일정을 삭제할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제", (d, w) -> Async.run(() -> {
                    repo.deletePlan(plan.id);
                    return true;
                }, ok -> load(), this::toast))
                .show();
    }

    private void showInviteDialog() {
        if (party == null) return;
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("초대 코드")
                .setMessage(party.inviteCode + "\n\n현재 인원 " + party.size() + " / " + Party.MAX_MEMBERS
                        + (party.size() >= Party.MAX_MEMBERS ? "\n(인원이 가득 찼어요)" : ""))
                .setPositiveButton("공유하기", (d, w) -> PartyJoinActivity.shareCode(requireContext(), party))
                .setNegativeButton("닫기", null)
                .show();
    }

    private void toast(String msg) {
        if (isAdded()) Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
    }
}
