package com.planon.app.ui.verify;

import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.widget.FrameLayout;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.planon.app.model.PlanPhoto;
import com.planon.app.util.ImageUtil;

import java.io.File;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.Plan;
import com.planon.app.model.User;
import com.planon.app.model.VoteInfo;
import com.planon.app.util.Async;
import com.planon.app.util.Characters;
import com.planon.app.util.DateUtil;
import com.planon.app.util.LevelRule;

/**
 * 인증 사진을 보고 인정 / 미인정 투표 (자정까지 바꿀 수 있음).
 * - 본인: 투표 불가. 23:30 전이면 '사진 추가하기'로 사진을 보탤 수 있음
 * - 확정 전에는 남의 표 내용은 숨기고 투표 여부만 보여줌
 */
public class VerifyReviewActivity extends AppCompatActivity {

    public static final String EXTRA_PLAN_ID = "plan_id";

    private final Repository repo = RepositoryProvider.get();
    private long planId;
    private long myId;

    private MaterialButton btnApprove, btnReject, btnAddPhotos;
    private View groupButtons;
    private ChipGroup containerVotes;
    private LinearLayout containerPhotos;
    private TextView textResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_review);

        planId = getIntent().getLongExtra(EXTRA_PLAN_ID, 0);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        btnApprove = findViewById(R.id.btn_approve);
        btnReject = findViewById(R.id.btn_reject);
        btnAddPhotos = findViewById(R.id.btn_add_photos);
        groupButtons = findViewById(R.id.group_buttons);
        containerVotes = findViewById(R.id.container_votes);
        containerPhotos = findViewById(R.id.container_photos);
        textResult = findViewById(R.id.text_result);

        btnApprove.setOnClickListener(v -> vote(true));
        btnReject.setOnClickListener(v -> vote(false));
        btnAddPhotos.setOnClickListener(v -> startActivity(VerifyUploadActivity.addPhotos(this, planId)));
    }

    @Override
    protected void onDestroy() {
        containerPhotos.removeCallbacks(refreshAtExpiry);
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        Async.run(() -> {
            User me = repo.getMe();
            myId = me.id;
            return repo.getVerification(planId);
        }, p -> {
            if (!isDestroyed()) bind(p);
        }, msg -> {
            toast(msg);
            finish();
        });
    }

    private void bind(Plan p) {
        boolean mine = p.userId == myId;

        Characters.bindFace(findViewById(R.id.image_avatar), p.ownerCharacterId, p.ownerStage);
        ((TextView) findViewById(R.id.text_owner_title)).setText((mine ? "나" : p.ownerNickname) + " · " + p.title);

        StringBuilder meta = new StringBuilder(DateUtil.korean(DateUtil.parse(p.date)));
        if (p.submittedAt != null && p.submittedAt.length() >= 16) {
            meta.append(" ").append(p.submittedAt.substring(11, 16)).append(" 제출");
        }
        if (p.category != null) meta.append(" · ").append(p.category);
        ((TextView) findViewById(R.id.text_meta)).setText(meta);

        bindPhotos(p);

        TextView comment = findViewById(R.id.text_comment);
        if (p.comment != null && !p.comment.isEmpty()) {
            comment.setVisibility(View.VISIBLE);
            comment.setText("“" + p.comment + "”");
        } else {
            comment.setVisibility(View.GONE);
        }
        TextView memo = findViewById(R.id.text_memo);
        if (p.memo != null) {
            memo.setVisibility(View.VISIBLE);
            memo.setText("인증 방법 메모: " + p.memo);
        } else {
            memo.setVisibility(View.GONE);
        }

        TextView deadline = findViewById(R.id.text_deadline);
        if (p.isStatus(Plan.VOTING)) {
            deadline.setVisibility(View.VISIBLE);
            deadline.setText("사진 등록 " + time(p.photoDeadline) + " 까지 · 투표·변경 자정(24:00)까지\n"
                    + LevelRule.PHOTO_EDIT_NOTICE + "\n"
                    + "자정에 결과 확정: 미인정이 인정보다 많으면 미수행, 같으면 인정 (투표 안 한 사람은 세지 않음)");
        } else {
            deadline.setVisibility(View.GONE);
        }

        ((TextView) findViewById(R.id.text_status)).setText(p.finalized
                ? "인정 " + p.approveCount + " · 미인정 " + p.rejectCount + " (" + p.voterCount + "명 중)"
                : "투표 " + p.votedCount + " / " + p.voterCount + "명" + (mine && p.rejectCount > 0 ? " · 미인정 " + p.rejectCount : ""));

        // 파티원별 투표 현황
        containerVotes.removeAllViews();
        if (p.votes != null) {
            for (VoteInfo v : p.votes) {
                boolean isMe = v.userId == myId;
                String state;
                int bg, fg;
                if (v.vote > 0) {
                    state = "인정";
                    bg = R.color.primary_soft;
                    fg = R.color.primary;
                } else if (v.vote < 0) {
                    state = "미인정";
                    bg = R.color.danger_soft;
                    fg = R.color.danger;
                } else if (v.voted) {
                    state = "투표함";
                    bg = R.color.fill;
                    fg = R.color.ink;
                } else {
                    state = "대기";
                    bg = R.color.fill;
                    fg = R.color.muted;
                }
                containerVotes.addView(chip((isMe ? "나" : v.nickname) + " · " + state, bg, fg));
            }
        }
        if (p.voterCount == 0) containerVotes.addView(chip("투표할 파티원이 없어요 (자정에 인정 처리)", R.color.fill, R.color.muted));

        // 결과 / 버튼
        textResult.setVisibility(View.VISIBLE);
        groupButtons.setVisibility(View.GONE);
        btnAddPhotos.setVisibility(mine && p.canAddPhotos ? View.VISIBLE : View.GONE);
        if (p.isStatus(Plan.APPROVED)) {
            showResult("인정 · +" + LevelRule.PLAN_POINT + "P", R.color.success_soft, R.color.success);
        } else if (p.isStatus(Plan.REJECTED)) {
            showResult("미인정이 더 많아 미수행 처리 · −" + LevelRule.FAIL_PENALTY + "P", R.color.danger_soft, R.color.danger);
        } else if (p.isStatus(Plan.MISSED)) {
            showResult("인증하지 않은 일정 · 0P", R.color.fill, R.color.muted);
        } else if (mine) {
            showResult(p.rejectCount > 0
                    ? "미인정 표가 있어요. 23:30 전까지 사진을 더 올려 보세요"
                    : "파티원이 투표 중이에요. 결과는 자정에 확정돼요", R.color.warn_soft, R.color.warn);
        } else if (p.canVote) {
            textResult.setVisibility(p.myVote == 0 ? View.GONE : View.VISIBLE);
            if (p.myVote != 0) {
                showResult("내 투표: " + (p.myVote > 0 ? "인정" : "미인정") + " · 자정 전까지 바꿀 수 있어요",
                        R.color.fill, R.color.muted);
            }
            groupButtons.setVisibility(View.VISIBLE);
            styleButtons(p.myVote);
        } else {
            showResult(p.voterCount > 0 && p.myVote == 0 && p.votes != null && !containsMe(p)
                    ? "인증이 올라온 뒤에 파티에 들어와 투표권이 없어요"
                    : "투표가 마감됐어요. 결과를 기다려 주세요", R.color.fill, R.color.muted);
        }
    }

    private boolean containsMe(Plan p) {
        for (VoteInfo v : p.votes) if (v.userId == myId) return true;
        return false;
    }

    private void bindPhotos(Plan p) {
        containerPhotos.removeAllViews();
        containerPhotos.removeCallbacks(refreshAtExpiry);
        boolean mine = p.userId == myId;
        int count = p.photos != null && !p.photos.isEmpty() ? p.photos.size() : (p.imageUrls == null ? 0 : p.imageUrls.size());
        int width = getResources().getDisplayMetrics().widthPixels - dp(count > 1 ? 72 : 48);
        boolean anyEditable = false;
        for (int i = 0; i < count; i++) {
            PlanPhoto ph = p.photos != null && i < p.photos.size() ? p.photos.get(i) : null;
            String url = ph != null ? ph.url : p.imageUrls.get(i);

            FrameLayout cell = new FrameLayout(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, dp(300));
            if (i < count - 1) lp.setMarginEnd(dp(8));
            cell.setLayoutParams(lp);

            ImageView img = new ImageView(this);
            img.setLayoutParams(new FrameLayout.LayoutParams(width, dp(300)));
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackgroundResource(R.drawable.bg_rounded_12);
            img.setClipToOutline(true);
            img.setContentDescription("인증 사진 " + (i + 1));
            Glide.with(this).load(url).into(img);
            cell.addView(img);

            // 본인 + 올린 지 10분 안: 아래쪽에 바꾸기·지우기
            if (mine && ph != null && ph.editable) {
                anyEditable = true;
                LinearLayout bar = new LinearLayout(this);
                bar.setOrientation(LinearLayout.HORIZONTAL);
                bar.setGravity(Gravity.CENTER_VERTICAL);
                bar.setBackgroundResource(R.drawable.bg_photo_bar);
                bar.setPadding(dp(12), dp(6), dp(6), dp(6));
                FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
                bar.setLayoutParams(bp);

                TextView until = new TextView(this);
                until.setText(time(ph.editableUntil) + "까지 수정 가능");
                until.setTextColor(color(R.color.white));
                until.setTextSize(12);
                bar.addView(until, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

                final long photoId = ph.id;
                bar.addView(barButton("바꾸기", v -> chooseReplacement(photoId)));
                if (count > 1) bar.addView(barButton("지우기", v -> confirmDelete(photoId)));
                cell.addView(bar);
                scheduleRefresh(ph.editableUntil);
            }
            containerPhotos.addView(cell);
        }
        String countText = count == 0 ? "사진 없음" : "사진 " + count + "장" + (count > 1 ? " · 옆으로 넘겨 보세요" : "");
        if (mine && p.isStatus(Plan.VOTING)) {
            countText += "\n" + LevelRule.PHOTO_EDIT_NOTICE + (anyEditable ? "" : " 지금은 수정할 수 있는 사진이 없어요.");
        }
        ((TextView) findViewById(R.id.text_photo_count)).setText(countText);
    }

    private TextView barButton(String text, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(color(R.color.white));
        b.setTextSize(13);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setBackgroundResource(R.drawable.bg_photo_button);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMarginStart(dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    /** 수정 가능 시간이 끝나면 화면을 새로 그려 버튼을 숨김 */
    private final Runnable refreshAtExpiry = this::load;

    private void scheduleRefresh(String editableUntil) {
        try {
            long ms = java.time.Duration.between(java.time.LocalDateTime.now(),
                    java.time.LocalDateTime.parse(editableUntil).plusMinutes(1)).toMillis();
            if (ms > 0 && ms < 15 * 60 * 1000L) containerPhotos.postDelayed(refreshAtExpiry, ms);
        } catch (Exception ignored) {
            // 시각 형식이 다르면 다음에 화면을 열 때 반영
        }
    }

    private void confirmDelete(long photoId) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("사진 지우기")
                .setMessage("이 사진을 지울까요? 지운 사진은 되돌릴 수 없어요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("지우기", (d, w) -> Async.run(() -> repo.deleteVerificationPhoto(planId, photoId), p -> {
                    toast("사진을 지웠어요");
                    if (!isDestroyed()) bind(p);
                }, this::toast))
                .show();
    }

    private long replacingPhotoId;
    private Uri cameraUri;

    private final ActivityResultLauncher<PickVisualMediaRequest> pickOne = registerForActivityResult(
            new ActivityResultContracts.PickVisualMedia(), uri -> {
                if (uri != null) replaceWith(uri);
            });

    private final ActivityResultLauncher<Uri> takePicture = registerForActivityResult(
            new ActivityResultContracts.TakePicture(), ok -> {
                if (Boolean.TRUE.equals(ok) && cameraUri != null) replaceWith(cameraUri);
            });

    private void chooseReplacement(long photoId) {
        replacingPhotoId = photoId;
        new MaterialAlertDialogBuilder(this)
                .setTitle("사진 바꾸기")
                .setItems(new String[]{"카메라로 촬영", "갤러리에서 선택"}, (d, which) -> {
                    if (which == 0) {
                        try {
                            File f = ImageUtil.newCameraFile(this);
                            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
                            takePicture.launch(cameraUri);
                        } catch (Exception e) {
                            toast("카메라를 열 수 없어요");
                        }
                    } else {
                        pickOne.launch(new PickVisualMediaRequest.Builder()
                                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE).build());
                    }
                })
                .show();
    }

    private void replaceWith(Uri uri) {
        final long photoId = replacingPhotoId;
        toast("사진을 바꾸는 중이에요…");
        Async.run(() -> {
            File f = ImageUtil.prepareForUpload(this, uri);
            return repo.replaceVerificationPhoto(planId, photoId, f);
        }, p -> {
            toast("사진을 바꿨어요");
            if (!isDestroyed()) bind(p);
        }, this::toast);
    }

    private void styleButtons(int myVote) {
        int primary = color(R.color.primary);
        int danger = color(R.color.danger);
        int white = color(R.color.white);
        // 내가 고른 쪽을 채워서 표시
        btnApprove.setBackgroundTintList(ColorStateList.valueOf(myVote < 0 ? white : primary));
        btnApprove.setTextColor(myVote < 0 ? primary : white);
        btnApprove.setStrokeColor(ColorStateList.valueOf(primary));
        btnApprove.setStrokeWidth(myVote < 0 ? dp(1) : 0);

        btnReject.setBackgroundTintList(ColorStateList.valueOf(myVote < 0 ? danger : white));
        btnReject.setTextColor(myVote < 0 ? white : danger);
        btnApprove.setText(myVote > 0 ? "인정 (선택됨)" : "인정");
        btnReject.setText(myVote < 0 ? "미인정 (선택됨)" : "미인정");
    }

    private void vote(boolean approve) {
        btnApprove.setEnabled(false);
        btnReject.setEnabled(false);
        Async.run(() -> repo.vote(planId, approve), p -> {
            btnApprove.setEnabled(true);
            btnReject.setEnabled(true);
            if (isDestroyed()) return;
            toast(approve ? "인정으로 투표했어요" : "미인정으로 투표했어요. 인증한 파티원에게 알림이 가요");
            bind(p);
        }, msg -> {
            btnApprove.setEnabled(true);
            btnReject.setEnabled(true);
            toast(msg);
        });
    }

    private void showResult(String text, int bg, int fg) {
        textResult.setVisibility(View.VISIBLE);
        textResult.setText(text);
        textResult.setTextColor(color(fg));
        textResult.setBackgroundTintList(ColorStateList.valueOf(color(bg)));
    }

    private Chip chip(String text, int bg, int fg) {
        Chip c = new Chip(this);
        c.setText(text);
        c.setClickable(false);
        c.setCheckable(false);
        c.setTextColor(color(fg));
        c.setChipBackgroundColor(ColorStateList.valueOf(color(bg)));
        return c;
    }

    private static String time(String dateTime) {
        return dateTime != null && dateTime.length() >= 16 ? dateTime.substring(11, 16) : LevelRule.PHOTO_DEADLINE;
    }

    private int color(int res) {
        return ContextCompat.getColor(this, res);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    /** 알림에서 바로 열 때 */
    public static Intent open(android.content.Context context, long planId) {
        Intent i = new Intent(context, VerifyReviewActivity.class);
        i.putExtra(EXTRA_PLAN_ID, planId);
        return i;
    }
}
