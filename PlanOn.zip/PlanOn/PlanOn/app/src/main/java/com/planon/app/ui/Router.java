package com.planon.app.ui;

import android.app.Activity;
import android.content.Intent;

import com.planon.app.model.User;
import com.planon.app.ui.auth.LoginActivity;
import com.planon.app.ui.main.MainActivity;
import com.planon.app.ui.party.CharacterSelectActivity;
import com.planon.app.ui.party.PartyJoinActivity;

/** 로그인 상태에 따라 알맞은 화면으로 보내는 도우미 */
public final class Router {
    private Router() {
    }

    /** 파티 없음 → 파티 참여, 캐릭터 없음 → 캐릭터 선택, 모두 있음 → 메인 */
    public static void afterLogin(Activity from, User user) {
        Class<?> target;
        if (!user.hasParty()) target = PartyJoinActivity.class;
        else if (user.characterId == 0) target = CharacterSelectActivity.class;
        else target = MainActivity.class;
        go(from, target);
    }

    public static void go(Activity from, Class<?> target) {
        Intent i = new Intent(from, target);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        from.startActivity(i);
        from.finish();
    }

    public static void toLogin(Activity from) {
        go(from, LoginActivity.class);
    }
}
