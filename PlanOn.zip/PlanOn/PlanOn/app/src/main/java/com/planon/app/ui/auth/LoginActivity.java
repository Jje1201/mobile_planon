package com.planon.app.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.text.InputType;
import android.widget.EditText;
import android.widget.FrameLayout;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.data.local.DbHelper;
import com.planon.app.data.local.LocalRepository;
import com.planon.app.data.remote.RemoteRepository;
import com.planon.app.model.SavedAccount;
import com.planon.app.model.User;
import com.planon.app.util.Characters;
import com.google.android.material.checkbox.MaterialCheckBox;

import java.util.List;
import com.planon.app.ui.Router;
import com.planon.app.util.Async;

public class LoginActivity extends AppCompatActivity {

    private final Repository repo = RepositoryProvider.get();

    private TextInputEditText editId;
    private TextInputEditText editPw;
    private MaterialButton btnLogin;
    private LinearProgressIndicator progress;
    private View groupSaved, groupForm, rowOther;
    private LinearLayout containerSaved;
    private MaterialCheckBox checkRemember;
    /** 저장된 계정이 있어도 '다른 계정으로 로그인'을 눌러 입력창을 연 상태 */
    private boolean formOpened;

    private final ActivityResultLauncher<Intent> signUpLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    editId.setText(result.getData().getStringExtra(SignUpActivity.EXTRA_LOGIN_ID));
                    editPw.requestFocus();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editId = findViewById(R.id.edit_login_id);
        editPw = findViewById(R.id.edit_password);
        btnLogin = findViewById(R.id.btn_login);
        progress = findViewById(R.id.progress);
        groupSaved = findViewById(R.id.group_saved);
        groupForm = findViewById(R.id.group_form);
        rowOther = findViewById(R.id.row_other_account);
        containerSaved = findViewById(R.id.container_saved);
        checkRemember = findViewById(R.id.check_remember);
        rowOther.setOnClickListener(v -> {
            formOpened = true;
            showForm(true);
            editId.requestFocus();
        });

        btnLogin.setOnClickListener(v -> login());
        editPw.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                login();
                return true;
            }
            return false;
        });
        findViewById(R.id.btn_go_signup).setOnClickListener(v ->
                signUpLauncher.launch(new Intent(this, SignUpActivity.class)));

        LocalRepository local = RepositoryProvider.local();
        View demoGroup = findViewById(R.id.group_demo);
        if (local == null) {
            demoGroup.setVisibility(View.GONE);
        } else {
            findViewById(R.id.btn_demo).setOnClickListener(v -> {
                setLoading(true);
                Async.run(local::seedDemo, msg -> {
                    setLoading(false);
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    editId.setText("demo1");
                    editPw.setText("demo1234");
                }, this::showError);
            });
        }

        RemoteRepository remote = RepositoryProvider.remote();
        MaterialButton btnServer = findViewById(R.id.btn_server);
        if (remote == null) {
            btnServer.setVisibility(View.GONE);
        } else {
            btnServer.setText("서버: " + remote.getBaseUrl() + "  (변경 · 연결 확인)");
            btnServer.setOnClickListener(v -> showServerDialog(remote));
        }

        tryAutoLogin();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadSavedAccounts();
    }

    /** 카카오 "계정 선택"처럼: 이 기기에서 로그인했던 계정 목록 */
    private void loadSavedAccounts() {
        List<SavedAccount> accounts = repo.getSavedAccounts();
        containerSaved.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        for (SavedAccount a : accounts) {
            View row = inflater.inflate(R.layout.item_saved_account, containerSaved, false);
            Characters.bindFace(row.findViewById(R.id.image_avatar), a.characterId, a.stage);
            ((TextView) row.findViewById(R.id.text_nickname)).setText(a.nickname == null ? a.loginId : a.nickname);
            ((TextView) row.findViewById(R.id.text_login_id)).setText(a.loginId);
            row.setOnClickListener(v -> quickLogin(a));
            row.findViewById(R.id.btn_remove).setOnClickListener(v -> confirmForget(a));
            containerSaved.addView(row);
        }
        groupSaved.setVisibility(accounts.isEmpty() ? View.GONE : View.VISIBLE);
        showForm(accounts.isEmpty() || formOpened);
    }

    private void showForm(boolean show) {
        groupForm.setVisibility(show ? View.VISIBLE : View.GONE);
        rowOther.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    private void quickLogin(SavedAccount a) {
        setLoading(true);
        Async.run(() -> repo.quickLogin(a), (User user) -> {
            setLoading(false);
            Router.afterLogin(this, user);
        }, msg -> {
            setLoading(false);
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            // 만료돼서 목록에서 빠졌으면 아이디를 채워 비밀번호 입력으로
            if (!containsAccount(a)) {
                formOpened = true;
                editId.setText(a.loginId);
                editPw.setText("");
                loadSavedAccounts();
                editPw.requestFocus();
            }
        });
    }

    private boolean containsAccount(SavedAccount a) {
        for (SavedAccount s : repo.getSavedAccounts()) if (s.userId == a.userId) return true;
        return false;
    }

    private void confirmForget(SavedAccount a) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("계정 지우기")
                .setMessage((a.nickname == null ? a.loginId : a.nickname) + "(" + a.loginId + ") 계정을 이 기기의 목록에서 지울까요?\n"
                        + "다음에는 아이디와 비밀번호를 입력해야 해요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("지우기", (d, w) -> {
                    repo.forgetAccount(a);
                    loadSavedAccounts();
                })
                .show();
    }

    /** 에뮬레이터: http://10.0.2.2:8080/ · 실제 휴대폰: 같은 Wi-Fi 의 PC IP (예: http://192.168.0.10:8080/) */
    private void showServerDialog(RemoteRepository remote) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(remote.getBaseUrl());
        input.setSelection(input.getText().length());
        FrameLayout box = new FrameLayout(this);
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);
        new MaterialAlertDialogBuilder(this)
                .setTitle("서버 주소")
                .setMessage("에뮬레이터는 http://10.0.2.2:8080/\n실제 휴대폰은 PC와 같은 Wi-Fi에서 http://PC의IP:8080/")
                .setView(box)
                .setNegativeButton("취소", null)
                .setNeutralButton("연결 확인", (d, w) -> {
                    String url = RepositoryProvider.normalize(input.getText().toString());
                    RemoteRepository probe = new RemoteRepository(DbHelper.get(this), url);
                    setLoading(true);
                    Async.run(() -> {
                        probe.checkServer();
                        return true;
                    }, ok -> {
                        setLoading(false);
                        Toast.makeText(this, url + " 연결 성공! '저장'을 눌러 이 주소를 쓰세요", Toast.LENGTH_LONG).show();
                    }, this::showError);
                })
                .setPositiveButton("저장", (d, w) -> {
                    String url = input.getText().toString().trim();
                    if (url.isEmpty()) return;
                    RepositoryProvider.changeServerUrl(url);
                    Toast.makeText(this, "서버 주소를 바꿨어요. 다시 로그인해 주세요", Toast.LENGTH_SHORT).show();
                    recreate();
                })
                .show();
    }

    /** 저장된 로그인 정보(SQLite session)가 있으면 바로 다음 화면으로 */
    private void tryAutoLogin() {
        setLoading(true);
        Async.run(() -> repo.isLoggedIn() ? repo.getMe() : null, user -> {
            setLoading(false);
            if (user != null) Router.afterLogin(this, user);
        }, msg -> setLoading(false));
    }

    private void login() {
        String id = text(editId);
        String pw = text(editPw);
        if (id.isEmpty() || pw.isEmpty()) {
            Toast.makeText(this, "아이디와 비밀번호를 입력해 주세요", Toast.LENGTH_SHORT).show();
            return;
        }
        setLoading(true);
        boolean remember = checkRemember.isChecked();
        Async.run(() -> repo.login(id, pw, remember), (User user) -> {
            setLoading(false);
            Router.afterLogin(this, user);
        }, this::showError);
    }

    private void showError(String msg) {
        setLoading(false);
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private void setLoading(boolean loading) {
        progress.setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
        btnLogin.setEnabled(!loading);
    }

    private static String text(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }
}
