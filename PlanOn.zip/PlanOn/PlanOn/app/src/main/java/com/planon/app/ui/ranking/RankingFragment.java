package com.planon.app.ui.ranking;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButtonToggleGroup;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.RankEntry;
import com.planon.app.model.RankingResult;
import com.planon.app.model.User;
import com.planon.app.util.Async;
import com.planon.app.util.Characters;
import com.planon.app.util.DateUtil;
import com.planon.app.util.LevelRule;

import java.time.LocalDate;

/** 랭킹: 이번 주 실시간 / 지난주 결산 / 이번 달 / 지난달 (월간은 포인트 합계로 실시간 계산) */
public class RankingFragment extends Fragment {

    private final Repository repo = RepositoryProvider.get();
    private String period = RankingResult.WEEK_CURRENT;

    private TextView bannerSub, bannerMain, bannerRight, textEmpty;
    private View cardPodium, podiumFirst, podiumSecond, podiumThird;
    private LinearLayout containerRanks;

    private static class Data {
        User me;
        RankingResult result;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ranking, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        bannerSub = v.findViewById(R.id.text_banner_sub);
        bannerMain = v.findViewById(R.id.text_banner_main);
        bannerRight = v.findViewById(R.id.text_banner_right);
        textEmpty = v.findViewById(R.id.text_empty);
        cardPodium = v.findViewById(R.id.card_podium);
        podiumFirst = v.findViewById(R.id.podium_first);
        podiumSecond = v.findViewById(R.id.podium_second);
        podiumThird = v.findViewById(R.id.podium_third);
        containerRanks = v.findViewById(R.id.container_ranks);

        MaterialButtonToggleGroup toggle = v.findViewById(R.id.toggle_week);
        toggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            if (checkedId == R.id.btn_last_week) period = RankingResult.WEEK_LAST;
            else if (checkedId == R.id.btn_this_month) period = RankingResult.MONTH_CURRENT;
            else if (checkedId == R.id.btn_last_month) period = RankingResult.MONTH_LAST;
            else period = RankingResult.WEEK_CURRENT;
            load();
        });

        buildRewards(v.findViewById(R.id.container_rewards));
        ((TextView) v.findViewById(R.id.text_reward_more)).setText(
                "+ 달성률 100% " + LevelRule.COMPLETION_FULL_EXP + " · 80% " + LevelRule.COMPLETION_HIGH_EXP
                        + " · 50% " + LevelRule.COMPLETION_HALF_EXP + " EXP\n"
                        + "+ 받은 투표 요청에 모두 투표 " + LevelRule.REVIEW_EXP + " EXP\n"
                        + "+ 파티 전체 인정률 70% 이상 " + LevelRule.PARTY_GOAL_EXP + " EXP\n"
                        + "혼자인 파티는 순위 경험치 " + LevelRule.SOLO_RANK_EXP + " · 주간 포인트가 0 이하이면 경험치 없음");
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isHidden()) load();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) load();
    }

    private void load() {
        final String wanted = period;
        Async.run(() -> {
            Data d = new Data();
            d.me = repo.getMe();
            d.result = repo.getRanking(wanted);
            return d;
        }, d -> {
            if (!isAdded() || !wanted.equals(period)) return;
            bind(d);
        }, msg -> {
            if (isAdded()) Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
        });
    }

    private void bind(Data d) {
        RankingResult r = d.result;
        String range = (r.weekStart == null) ? "" :
                DateUtil.shortKorean(DateUtil.parse(r.weekStart)) + " ~ " + DateUtil.shortKorean(DateUtil.parse(r.weekEnd));

        RankEntry mine = null;
        for (RankEntry e : r.entries) if (e.userId == d.me.id) mine = e;

        boolean monthly = r.isMonthly();
        boolean lastWeek = RankingResult.WEEK_LAST.equals(period);
        if (monthly) {
            bannerSub.setText(range + (r.settled ? " 마감" : " 집계 중"));
            bannerMain.setText(mine != null ? "이달 내 순위 " + mine.rank + "위 · " + mine.points + "P · 결산 경험치 +" + mine.exp
                    : "이달 포인트 순위");
            bannerRight.setText(mine != null ? mine.rank + "위" : "-");
        } else if (!lastWeek) {
            LocalDate nextMon = DateUtil.weekStart(DateUtil.today()).plusWeeks(1);
            bannerSub.setText(range + " 집계 중 · 포인트는 자정에 확정");
            bannerMain.setText("다음 결산: " + nextMon.getMonthValue() + "월 " + nextMon.getDayOfMonth() + "일(월) 00:00");
            bannerRight.setText("D-" + DateUtil.daysUntilNextMonday());
        } else if (r.settled) {
            bannerSub.setText(range + " 결산 완료");
            bannerMain.setText(mine != null ? "내 순위 " + mine.rank + "위 · +" + mine.exp + " EXP 지급" : "결산 결과");
            bannerRight.setText(mine != null ? mine.rank + "위" : "-");
        } else {
            bannerSub.setText(range);
            bannerMain.setText("아직 결산 전이에요 (예상치)");
            bannerRight.setText("-");
        }

        // 시상대
        boolean hasPodium = r.entries.size() >= 2;
        cardPodium.setVisibility(hasPodium ? View.VISIBLE : View.GONE);
        if (hasPodium) {
            bindPodium(podiumFirst, r.entries.get(0), 96, true);
            bindPodium(podiumSecond, r.entries.get(1), 72, false);
            if (r.entries.size() >= 3) {
                podiumThird.setVisibility(View.VISIBLE);
                bindPodium(podiumThird, r.entries.get(2), 56, false);
            } else {
                podiumThird.setVisibility(View.INVISIBLE);
            }
        }

        // 전체 순위
        containerRanks.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        for (RankEntry e : r.entries) {
            View row = inflater.inflate(R.layout.item_rank, containerRanks, false);
            boolean isMe = e.userId == d.me.id;
            ((TextView) row.findViewById(R.id.text_rank)).setText(String.valueOf(e.rank));
            Characters.bindFace(row.findViewById(R.id.image_avatar), e.characterId, LevelRule.stageFor(e.getLevel()));
            ((TextView) row.findViewById(R.id.text_name)).setText(e.nickname + (isMe ? " (나)" : ""));
            ((TextView) row.findViewById(R.id.text_sub)).setText("Lv." + e.getLevel() + " · 인증 " + e.doneCount + "건");
            ((TextView) row.findViewById(R.id.text_points)).setText(e.points + "P");
            ((TextView) row.findViewById(R.id.text_exp)).setText(
                    (monthly ? "받은 +" : r.settled ? "+" : "예상 +") + e.exp + " EXP");
            if (isMe) row.setBackgroundColor(color(R.color.primary_soft));
            containerRanks.addView(row);
        }
        textEmpty.setVisibility(r.entries.isEmpty() ? View.VISIBLE : View.GONE);
        textEmpty.setText(lastWeek ? "지난주 결산 결과가 없어요.\n(파티를 만든 다음 주 월요일부터 결산돼요)" : "아직 순위가 없어요");
        if (monthly && r.entries.size() < 2) cardPodium.setVisibility(View.GONE);
    }

    private void bindPodium(View root, RankEntry e, int blockHeightDp, boolean first) {
        Characters.bindFace(root.findViewById(R.id.image_avatar), e.characterId, LevelRule.stageFor(e.getLevel()));
        ((TextView) root.findViewById(R.id.text_name)).setText(e.nickname);
        ((TextView) root.findViewById(R.id.text_points)).setText(e.points + "P");
        TextView block = root.findViewById(R.id.text_block);
        block.setText(e.rank + "위");
        ViewGroup.LayoutParams lp = block.getLayoutParams();
        lp.height = dp(blockHeightDp);
        block.setLayoutParams(lp);
        block.setBackgroundTintList(ColorStateList.valueOf(color(first ? R.color.primary : R.color.line_soft)));
        block.setTextColor(color(first ? R.color.white : R.color.ink));
    }

    private void buildRewards(LinearLayout container) {
        for (int i = 0; i < LevelRule.RANK_EXP.length; i++) {
            TextView t = new TextView(requireContext());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.setMarginStart(dp(6));
            t.setLayoutParams(lp);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(8), 0, dp(8));
            t.setBackgroundResource(R.drawable.bg_rounded_8);
            t.setBackgroundTintList(ColorStateList.valueOf(color(R.color.bg)));
            t.setTextColor(color(R.color.ink));
            t.setTextSize(12);
            t.setText((i + 1) + "위\n+" + LevelRule.RANK_EXP[i] + " EXP");
            container.addView(t);
        }
    }

    private int color(int res) {
        return ContextCompat.getColor(requireContext(), res);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
