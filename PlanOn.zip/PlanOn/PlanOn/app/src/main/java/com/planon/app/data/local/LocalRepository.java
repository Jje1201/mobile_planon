package com.planon.app.data.local;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import com.planon.app.data.ApiException;
import com.planon.app.data.Repository;
import com.planon.app.model.AppNotification;
import com.planon.app.model.Member;
import com.planon.app.model.Party;
import com.planon.app.model.Plan;
import com.planon.app.model.RankEntry;
import com.planon.app.model.RankingResult;
import com.planon.app.model.User;
import com.planon.app.model.VoteInfo;
import com.planon.app.util.DateUtil;
import com.planon.app.util.LevelRule;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * 서버 없이 SQLite만으로 동작하는 Repository.
 * Spring 서버와 같은 규칙을 씁니다:
 * - 사진 등록·추가는 일정 당일 23:30 까지, 투표·변경은 자정까지, 본인은 투표 불가
 * - 투표권은 제출 순간의 파티원으로 고정
 * - 결과는 자정에 합산 (미인정 > 인정 → 미수행, 같으면 인정), 포인트는 일정당 한 번
 * - 경험치는 월요일 주간 결산에서만 (순위 + 달성률 + 검토 참여 + 파티 목표)
 * 서버의 스케줄러 대신, 앱이 데이터를 읽을 때마다 runDueJobs() 로 밀린 일을 처리합니다.
 */
public class LocalRepository implements Repository {

    private static final String CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final int CATCH_UP_WEEKS = 8;

    private final Context context;
    private final DbHelper helper;
    private final SecureRandom random = new SecureRandom();

    public LocalRepository(Context context, DbHelper helper) {
        this.context = context;
        this.helper = helper;
    }

    private SQLiteDatabase db() {
        return helper.getWritableDatabase();
    }

    // ======================================================================
    // 회원
    // ======================================================================

    @Override
    public synchronized boolean isLoginIdAvailable(String loginId) {
        String id = loginId == null ? "" : loginId.trim();
        if (!id.matches("[A-Za-z0-9]{4,16}")) return false;
        return count("SELECT COUNT(*) FROM users WHERE login_id = ?", id) == 0;
    }

    @Override
    public synchronized User signUp(String loginId, String password, String nickname) throws Exception {
        loginId = loginId == null ? "" : loginId.trim();
        nickname = nickname == null ? "" : nickname.trim();
        if (!loginId.matches("[A-Za-z0-9]{4,16}")) throw new ApiException("아이디는 영문·숫자 4~16자로 입력해 주세요");
        if (password == null || !password.matches("^(?=.*[A-Za-z])(?=.*\\d).{8,64}$"))
            throw new ApiException("비밀번호는 영문과 숫자를 섞어 8자 이상으로 입력해 주세요");
        if (nickname.isEmpty() || nickname.length() > 10) throw new ApiException("닉네임은 1~10자로 입력해 주세요");
        if (count("SELECT COUNT(*) FROM users WHERE login_id = ?", loginId) > 0) throw new ApiException("이미 사용 중인 아이디예요");

        ContentValues v = new ContentValues();
        v.put("login_id", loginId);
        v.put("password_hash", hash(loginId, password));
        v.put("nickname", nickname);
        v.put("total_exp", 0);
        v.put("created_date", DateUtil.todayStr());
        long id = db().insertOrThrow("users", null, v);
        return loadUserBasic(id);
    }

    @Override
    public synchronized User login(String loginId, String password, boolean remember) throws Exception {
        loginId = loginId.trim();
        try (Cursor c = db().rawQuery("SELECT id, password_hash FROM users WHERE login_id = ?",
                new String[]{loginId})) {
            if (!c.moveToFirst() || !c.getString(1).equals(hash(loginId, password))) {
                throw new ApiException("아이디 또는 비밀번호가 맞지 않아요");
            }
            helper.saveSession(c.getLong(0), "local-" + UUID.randomUUID());
        }
        User me = getMe();
        if (remember) {
            // 로컬 모드의 "서버 쪽 토큰"은 settings 에 보관
            String token = UUID.randomUUID().toString();
            helper.putSetting(REMEMBER_PREFIX + token, String.valueOf(me.id));
            helper.saveAccount(SCOPE, me, token);
        }
        return me;
    }

    private static final String SCOPE = "local";
    private static final String REMEMBER_PREFIX = "remember:";

    @Override
    public List<com.planon.app.model.SavedAccount> getSavedAccounts() {
        return helper.getSavedAccounts(SCOPE);
    }

    @Override
    public synchronized User quickLogin(com.planon.app.model.SavedAccount account) throws Exception {
        String saved = helper.getSetting(REMEMBER_PREFIX + account.rememberToken);
        if (saved == null || !saved.equals(String.valueOf(account.userId))
                || count("SELECT COUNT(*) FROM users WHERE id = ?", account.userId) == 0) {
            helper.deleteSavedAccount(SCOPE, account.userId);
            throw new com.planon.app.data.SavedLoginExpiredException("저장된 로그인 정보가 없어요. 비밀번호로 다시 로그인해 주세요");
        }
        helper.saveSession(account.userId, "local-" + UUID.randomUUID());
        helper.touchSavedAccount(SCOPE, account.userId);
        return getMe();
    }

    @Override
    public void forgetAccount(com.planon.app.model.SavedAccount account) {
        helper.deleteSavedAccount(SCOPE, account.userId);
        helper.putSetting(REMEMBER_PREFIX + account.rememberToken, null);
    }

    @Override
    public void logout() {
        helper.clearSession();
    }

    @Override
    public synchronized boolean isLoggedIn() {
        long id = helper.getSessionUserId();
        return id > 0 && count("SELECT COUNT(*) FROM users WHERE id = ?", id) > 0;
    }

    @Override
    public synchronized User getMe() throws Exception {
        long me = requireMe();
        runDueJobs();
        User u = loadUserBasic(me);
        if (u == null) {
            helper.clearSession();
            throw new ApiException("로그인이 필요해요");
        }
        long partyId = partyOf(me);
        LocalDate mon = DateUtil.weekStart(DateUtil.today());
        if (partyId > 0) {
            u.partyId = partyId;
            u.partyName = DatabaseUtils.stringForQuery(db(), "SELECT name FROM parties WHERE id = ?", new String[]{s(partyId)});
            u.characterId = (int) count("SELECT character_id FROM party_members WHERE user_id = ?", me);
            for (Score sc : weekScores(partyId, mon)) if (sc.e.userId == me) u.weeklyRank = sc.e.rank;
        } else {
            u.weeklyRank = 1;
        }
        u.weeklyPoints = sumPoints(me, mon, mon.plusDays(6));
        u.totalPoints = (int) count("SELECT COALESCE(SUM(points), 0) FROM point_events WHERE user_id = ?", me);
        helper.updateSavedProfile(SCOPE, u);
        return u;
    }

    // ======================================================================
    // 파티
    // ======================================================================

    @Override
    public synchronized Party createParty(String name) throws Exception {
        long me = requireMe();
        if (partyOf(me) > 0) throw new ApiException("이미 파티에 속해 있어요. 한 사람은 파티 하나만 가입할 수 있어요");
        name = name == null ? "" : name.trim();
        if (name.isEmpty() || name.length() > 20) throw new ApiException("파티 이름은 1~20자로 입력해 주세요");

        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            ContentValues p = new ContentValues();
            p.put("name", name);
            p.put("invite_code", newInviteCode());
            p.put("leader_id", me);
            p.put("created_date", DateUtil.todayStr());
            long partyId = db.insertOrThrow("parties", null, p);
            addMember(db, partyId, me);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return getMyParty();
    }

    @Override
    public synchronized Party joinParty(String inviteCode) throws Exception {
        long me = requireMe();
        if (partyOf(me) > 0) throw new ApiException("이미 다른 파티에 속해 있어요. 나간 뒤에 가입할 수 있어요");
        String code = inviteCode == null ? "" : inviteCode.trim().toUpperCase();
        if (code.length() != 6) throw new ApiException("초대 코드 6자리를 입력해 주세요");

        long partyId;
        String partyName;
        try (Cursor c = db().rawQuery("SELECT id, name FROM parties WHERE invite_code = ?", new String[]{code})) {
            if (!c.moveToFirst()) throw new ApiException("초대 코드에 맞는 파티가 없어요");
            partyId = c.getLong(0);
            partyName = c.getString(1);
        }
        long size = count("SELECT COUNT(*) FROM party_members WHERE party_id = ?", partyId);
        if (size >= Party.MAX_MEMBERS) throw new ApiException("파티 정원(4명)이 다 찼어요");

        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            addMember(db, partyId, me);
            if (size == 0) db.execSQL("UPDATE parties SET leader_id = ? WHERE id = ?", new Object[]{me, partyId});
            String nick = nickname(me);
            for (long other : memberIds(partyId)) {
                if (other != me) notify(other, AppNotification.PARTY_JOINED, "새 파티원",
                        nick + "님이 " + partyName + "에 들어왔어요", null);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return getMyParty();
    }

    @Override
    public synchronized Party getMyParty() throws Exception {
        long me = requireMe();
        long partyId = partyOf(me);
        if (partyId == 0) return null;

        Party party = new Party();
        try (Cursor c = db().rawQuery("SELECT id, name, invite_code, leader_id FROM parties WHERE id = ?",
                new String[]{s(partyId)})) {
            if (!c.moveToFirst()) return null;
            party.id = c.getLong(0);
            party.name = c.getString(1);
            party.inviteCode = c.getString(2);
            party.leaderId = c.getLong(3);
        }
        party.members = loadMembers(partyId, party.leaderId);
        return party;
    }

    /** 파티는 기록이 남아 있으므로 지우지 않음. 확정 전 인증의 내 투표권은 회수 */
    @Override
    public synchronized void leaveParty() throws Exception {
        long me = requireMe();
        long partyId = requireParty(me);
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            db.execSQL("UPDATE votes SET active = 0 WHERE voter_id = ? AND plan_id IN "
                    + "(SELECT id FROM plans WHERE status = 'VOTING')", new Object[]{me});
            db.delete("party_members", "user_id = ?", new String[]{s(me)});
            List<Long> rest = memberIds(partyId);
            long leader = count("SELECT leader_id FROM parties WHERE id = ?", partyId);
            if (leader == me && !rest.isEmpty()) {
                db.execSQL("UPDATE parties SET leader_id = ? WHERE id = ?", new Object[]{rest.get(0), partyId});
            }
            String nick = nickname(me);
            for (long other : rest) {
                notify(other, AppNotification.PARTY_LEFT, "파티원이 나갔어요", nick + "님이 파티를 떠났어요", null);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    @Override
    public synchronized void selectCharacter(int characterId) throws Exception {
        if (characterId < 1 || characterId > 4) throw new ApiException("캐릭터는 1~4번 중에서 골라 주세요");
        long me = requireMe();
        long partyId = requireParty(me);
        long takenBy = count("SELECT COUNT(*) FROM party_members WHERE party_id = ? AND character_id = ? AND user_id <> ?",
                partyId, characterId, me);
        if (takenBy > 0) throw new ApiException("다른 파티원이 이미 고른 캐릭터예요");
        db().execSQL("UPDATE party_members SET character_id = ? WHERE user_id = ?", new Object[]{characterId, me});
    }

    // ======================================================================
    // 일정
    // ======================================================================

    @Override
    public synchronized List<Plan> getPlans(long userId, String date) throws Exception {
        long me = requireMe();
        runDueJobs();
        if (userId != me) {
            long myParty = partyOf(me);
            if (myParty == 0 || partyOf(userId) != myParty) throw new ApiException("같은 파티원의 일정만 볼 수 있어요");
            if (!DateUtil.todayStr().equals(date)) throw new ApiException("다른 파티원의 일정은 오늘 것만 볼 수 있어요");
        }
        List<Plan> list = new ArrayList<>();
        try (Cursor c = db().rawQuery("SELECT * FROM plans WHERE user_id = ? AND plan_date = ? "
                + "ORDER BY start_time IS NULL, start_time, id", new String[]{s(userId), date})) {
            while (c.moveToNext()) list.add(readPlan(c));
        }
        for (Plan p : list) fill(p, me, false);
        return list;
    }

    @Override
    public synchronized Set<String> getMyPlanDates(String yearMonth) throws Exception {
        long me = requireMe();
        Set<String> dates = new LinkedHashSet<>();
        try (Cursor c = db().rawQuery("SELECT DISTINCT plan_date FROM plans WHERE user_id = ? AND plan_date LIKE ? ORDER BY 1",
                new String[]{s(me), yearMonth + "-%"})) {
            while (c.moveToNext()) dates.add(c.getString(0));
        }
        return dates;
    }

    @Override
    public synchronized Plan addPlan(String date, String title, String time, String category, String memo) throws Exception {
        long me = requireMe();
        if (title == null || title.trim().isEmpty() || title.trim().length() > 50)
            throw new ApiException("일정 제목은 1~50자로 입력해 주세요");
        LocalDate d = DateUtil.parse(date);
        LocalDate today = DateUtil.today();
        if (d.isBefore(today)) throw new ApiException("지난 날짜에는 일정을 만들 수 없어요");
        if (d.isAfter(today.plusDays(30))) throw new ApiException("일정은 30일 뒤까지만 만들 수 있어요");
        if (d.equals(today) && !now().isBefore(photoDeadline(d)))
            throw new ApiException("오늘 일정은 23:30 까지만 추가할 수 있어요 (인증 마감)");
        if (count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date = ?", me, date) >= 10)
            throw new ApiException("하루 일정은 10개까지 만들 수 있어요");

        ContentValues v = new ContentValues();
        v.put("user_id", me);
        v.put("party_id", partyOf(me));
        v.put("plan_date", date);
        v.put("title", title.trim());
        v.put("start_time", emptyToNull(time));
        v.put("category", emptyToNull(category));
        v.put("memo", emptyToNull(memo));
        v.put("status", Plan.TODO);
        long id = db().insertOrThrow("plans", null, v);
        Plan p = loadPlan(id);
        fill(p, me, false);
        return p;
    }

    @Override
    public synchronized void deletePlan(long planId) throws Exception {
        long me = requireMe();
        Plan p = loadPlan(planId);
        if (p == null || p.userId != me) throw new ApiException("일정을 찾을 수 없어요");
        if (!p.isStatus(Plan.TODO)) throw new ApiException("인증을 제출한 일정은 지울 수 없어요");
        db().delete("notifications", "plan_id = ?", new String[]{s(planId)});
        db().delete("plans", "id = ?", new String[]{s(planId)});
    }

    // ======================================================================
    // 인증
    // ======================================================================

    @Override
    public synchronized Plan submitVerification(long planId, List<File> images, String comment) throws Exception {
        long me = requireMe();
        runDueJobs();
        Plan p = loadPlan(planId);
        if (p == null) throw new ApiException("일정을 찾을 수 없어요");
        if (p.userId != me) throw new ApiException("내 일정만 인증할 수 있어요");
        if (!p.isStatus(Plan.TODO)) throw new ApiException("이미 인증을 제출한 일정이에요. 사진은 '사진 추가'로 보탤 수 있어요");
        LocalDate date = DateUtil.parse(p.date);
        if (!date.equals(DateUtil.today())) throw new ApiException("인증은 일정 당일에만 제출할 수 있어요");
        if (!now().isBefore(photoDeadline(date))) throw new ApiException("인증 사진은 23:30 까지만 올릴 수 있어요");
        List<File> photos = existing(images);
        if (photos.isEmpty()) throw new ApiException("인증 사진을 한 장 이상 올려 주세요");
        if (photos.size() > LevelRule.MAX_FIRST_PHOTOS) throw new ApiException("처음에는 사진을 5장까지 올릴 수 있어요");

        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            savePhotos(planId, photos);
            ContentValues v = new ContentValues();
            v.put("status", Plan.VOTING);
            v.put("comment", emptyToNull(comment));
            v.put("submitted_at", nowText());
            db.update("plans", v, "id = ?", new String[]{s(planId)});

            long partyId = partyOf(me);
            String nick = nickname(me);
            for (long voter : memberIds(partyId)) {
                if (voter == me) continue;
                db.execSQL("INSERT INTO votes (plan_id, voter_id, vote, active) VALUES (?, ?, NULL, 1)", new Object[]{planId, voter});
                notify(voter, AppNotification.VOTE_REQUEST, "인증 검토 요청",
                        nick + "님이 '" + p.title + "' 인증을 올렸어요. 자정 전까지 투표해 주세요", planId);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return getVerification(planId);
    }

    @Override
    public synchronized Plan addVerificationPhotos(long planId, List<File> images) throws Exception {
        long me = requireMe();
        runDueJobs();
        Plan p = loadPlan(planId);
        if (p == null || p.userId != me) throw new ApiException("내 일정만 인증할 수 있어요");
        if (!p.isStatus(Plan.VOTING)) throw new ApiException("검토 중인 인증에만 사진을 추가할 수 있어요");
        if (!now().isBefore(photoDeadline(DateUtil.parse(p.date)))) throw new ApiException("사진 추가는 23:30 까지만 할 수 있어요");
        List<File> photos = existing(images);
        if (photos.isEmpty()) throw new ApiException("추가할 사진을 골라 주세요");
        long have = count("SELECT COUNT(*) FROM plan_photos WHERE plan_id = ?", planId);
        if (have + photos.size() > LevelRule.MAX_PHOTOS)
            throw new ApiException("사진은 모두 " + LevelRule.MAX_PHOTOS + "장까지예요 (지금 " + have + "장)");

        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            savePhotos(planId, photos);
            String nick = nickname(me);
            for (long voter : activeVoters(planId)) {
                notify(voter, AppNotification.PHOTO_ADDED, "인증 사진 추가",
                        nick + "님이 '" + p.title + "' 인증에 사진 " + photos.size() + "장을 더 올렸어요", planId);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return getVerification(planId);
    }

    @Override
    public synchronized Plan getVerification(long planId) throws Exception {
        long me = requireMe();
        runDueJobs();
        Plan p = loadPlan(planId);
        if (p == null) throw new ApiException("일정을 찾을 수 없어요");
        boolean voter = count("SELECT COUNT(*) FROM votes WHERE plan_id = ? AND voter_id = ?", planId, me) > 0;
        if (p.userId != me && !voter && (partyOf(me) == 0 || partyOf(p.userId) != partyOf(me))) {
            throw new ApiException("같은 파티원의 인증만 볼 수 있어요");
        }
        fill(p, me, true);
        return p;
    }

    @Override
    public synchronized Plan vote(long planId, boolean approve) throws Exception {
        long me = requireMe();
        runDueJobs();
        Plan p = loadPlan(planId);
        if (p == null) throw new ApiException("일정을 찾을 수 없어요");
        if (p.userId == me) throw new ApiException("내 인증에는 투표할 수 없어요");
        if (!p.isStatus(Plan.VOTING)) throw new ApiException("이미 결과가 확정돼서 투표를 바꿀 수 없어요");
        if (!now().isBefore(voteDeadline(DateUtil.parse(p.date)))) throw new ApiException("투표는 자정까지만 할 수 있어요");

        Integer before;
        try (Cursor c = db().rawQuery("SELECT vote, active FROM votes WHERE plan_id = ? AND voter_id = ?",
                new String[]{s(planId), s(me)})) {
            if (!c.moveToFirst()) throw new ApiException("이 인증에 투표할 수 있는 파티원이 아니에요 (인증 뒤에 들어온 경우 포함)");
            if (c.getInt(1) == 0) throw new ApiException("파티를 나가서 투표권이 없어요");
            before = c.isNull(0) ? null : c.getInt(0);
        }
        int after = approve ? 1 : -1;
        if (before == null || before != after) {
            SQLiteDatabase db = db();
            db.beginTransaction();
            try {
                db.execSQL("UPDATE votes SET vote = ?, change_count = change_count + ? WHERE plan_id = ? AND voter_id = ?",
                        new Object[]{after, before == null ? 0 : 1, planId, me});
                if (!approve) {
                    notify(p.userId, AppNotification.VOTE_RECEIVED, "미인정 표를 받았어요",
                            "'" + p.title + "' 인증에 미인정 표가 있어요. 23:30 전까지 사진을 더 올릴 수 있어요", planId);
                }
                db.setTransactionSuccessful();
            } finally {
                db.endTransaction();
            }
        }
        return getVerification(planId);
    }

    // ======================================================================
    // 밀린 일 처리 (서버의 매시 정각 작업에 해당)
    // ======================================================================

    private void runDueJobs() {
        finalizeDue();
        markMissed();
        settleDueWeeks();
        remindVoters();
    }

    /** 날짜가 지난(=자정이 지난) 투표 중 인증을 확정 */
    private void finalizeDue() {
        List<Long> due = ids("SELECT id FROM plans WHERE status = 'VOTING' AND plan_date < ?", DateUtil.todayStr());
        for (long planId : due) {
            SQLiteDatabase db = db();
            db.beginTransaction();
            try {
                Plan p = loadPlan(planId);
                int approves = (int) count("SELECT COUNT(*) FROM votes WHERE plan_id = ? AND active = 1 AND vote = 1", planId);
                int rejects = (int) count("SELECT COUNT(*) FROM votes WHERE plan_id = ? AND active = 1 AND vote = -1", planId);
                boolean ok = LevelRule.approved(approves, rejects);
                String result = ok ? Plan.APPROVED : Plan.REJECTED;
                ContentValues v = new ContentValues();
                v.put("status", result);
                v.put("finalized_at", p.date + "T23:59:59");
                v.put("approve_count", approves);
                v.put("reject_count", rejects);
                db.update("plans", v, "id = ?", new String[]{s(planId)});

                ContentValues e = new ContentValues();
                e.put("user_id", p.userId);
                e.put("plan_id", planId);
                e.put("points", ok ? LevelRule.PLAN_POINT : -LevelRule.FAIL_PENALTY);
                e.put("event_date", p.date);
                db.insertWithOnConflict("point_events", null, e, SQLiteDatabase.CONFLICT_IGNORE);

                String counts = " (인정 " + approves + " · 미인정 " + rejects + ")";
                notify(p.userId, AppNotification.VERIFY_RESULT, ok ? "인증 인정" : "인증 미인정",
                        ok ? "'" + p.title + "' 인정! +" + LevelRule.PLAN_POINT + "pt" + counts
                                : "'" + p.title + "' 미수행 처리 −" + LevelRule.FAIL_PENALTY + "pt" + counts, planId);
                db.setTransactionSuccessful();
            } finally {
                db.endTransaction();
            }
        }
    }

    private void markMissed() {
        List<Long> due = ids("SELECT id FROM plans WHERE status = 'TODO' AND plan_date < ?", DateUtil.todayStr());
        for (long planId : due) {
            Plan p = loadPlan(planId);
            db().execSQL("UPDATE plans SET status = 'MISSED' WHERE id = ?", new Object[]{planId});
            notify(p.userId, AppNotification.PLAN_MISSED, "미수행 일정",
                    "'" + p.title + "' 일정을 인증하지 않아 미수행으로 기록됐어요", planId);
        }
    }

    /** 23:00 이후, 오늘 인증 중 투표 안 한 사람에게 한 번 알림 */
    private void remindVoters() {
        if (now().getHour() < 23) return;
        List<Long> due = ids("SELECT id FROM plans WHERE status = 'VOTING' AND plan_date = ? AND reminded = 0",
                DateUtil.todayStr());
        for (long planId : due) {
            Plan p = loadPlan(planId);
            for (long voter : ids("SELECT voter_id FROM votes WHERE plan_id = ? AND active = 1 AND vote IS NULL", planId)) {
                notify(voter, AppNotification.VOTE_REMINDER, "투표 마감 1시간 전",
                        "'" + p.title + "' 인증 투표가 자정에 마감돼요", planId);
            }
            db().execSQL("UPDATE plans SET reminded = 1 WHERE id = ?", new Object[]{planId});
        }
    }

    private void settleDueWeeks() {
        LocalDate lastMon = DateUtil.weekStart(DateUtil.today()).minusWeeks(1);
        LocalDate oldest = lastMon.minusWeeks(CATCH_UP_WEEKS - 1);
        for (long partyId : ids("SELECT id FROM parties")) {
            LocalDate created = DateUtil.weekStart(DateUtil.parse(
                    DatabaseUtils.stringForQuery(db(), "SELECT created_date FROM parties WHERE id = ?", new String[]{s(partyId)})));
            LocalDate from = created.isAfter(oldest) ? created : oldest;
            for (LocalDate w = from; !w.isAfter(lastMon); w = w.plusWeeks(1)) settle(partyId, w);
        }
    }

    private void settle(long partyId, LocalDate weekStart) {
        String key = DateUtil.format(weekStart);
        if (count("SELECT COUNT(*) FROM weekly_settlements WHERE party_id = ? AND week_start = ?", partyId, key) > 0) return;
        List<Score> scores = weekScores(partyId, weekStart);
        if (scores.isEmpty()) return;
        SQLiteDatabase db = db();
        db.beginTransaction();
        try {
            db.execSQL("INSERT INTO weekly_settlements (party_id, week_start) VALUES (?, ?)", new Object[]{partyId, key});
            for (Score sc : scores) {
                RankEntry e = sc.e;
                db.execSQL("INSERT OR IGNORE INTO weekly_results (party_id, week_start, user_id, rank, points, done_count, exp) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)", new Object[]{partyId, key, e.userId, e.rank, e.points, e.doneCount, e.exp});
                int levelBefore = LevelRule.levelFor(e.totalExp);
                grant(e.userId, key, "WEEKLY_RANK", sc.rankExp);
                grant(e.userId, key, "WEEKLY_COMPLETION", sc.completionExp);
                grant(e.userId, key, "WEEKLY_REVIEW", sc.reviewExp);
                grant(e.userId, key, "PARTY_GOAL", sc.goalExp);
                int levelAfter = LevelRule.levelFor((int) count("SELECT total_exp FROM users WHERE id = ?", e.userId));

                notify(e.userId, AppNotification.WEEKLY_SETTLED, "주간 결산", e.exp > 0
                        ? "지난주 " + e.rank + "위 · " + e.points + "pt → 경험치 +" + e.exp
                        : "지난주 " + e.rank + "위 · " + e.points + "pt (포인트가 0 이하라 경험치는 없어요)", null);
                if (levelAfter > levelBefore) {
                    notify(e.userId, AppNotification.LEVEL_UP, "레벨 업!", "Lv." + levelBefore + " → Lv." + levelAfter, null);
                    if (LevelRule.stageFor(levelAfter) > LevelRule.stageFor(levelBefore)) {
                        notify(e.userId, AppNotification.CHARACTER_GROWN, "캐릭터가 자랐어요",
                                "캐릭터가 " + LevelRule.stageFor(levelAfter) + "단계로 성장했어요", null);
                    }
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    /** 장부 한 줄 + users 합계를 같은 트랜잭션에서. 같은 주·같은 경로는 한 번만 */
    private void grant(long userId, String weekStart, String source, int amount) {
        if (amount <= 0) return;
        ContentValues v = new ContentValues();
        v.put("user_id", userId);
        v.put("week_start", weekStart);
        v.put("source", source);
        v.put("amount", amount);
        long row = db().insertWithOnConflict("exp_events", null, v, SQLiteDatabase.CONFLICT_IGNORE);
        if (row != -1) db().execSQL("UPDATE users SET total_exp = total_exp + ? WHERE id = ?", new Object[]{amount, userId});
    }

    // ======================================================================
    // 랭킹
    // ======================================================================

    /** 한 사람의 한 주 성적 */
    private static class Score {
        RankEntry e;
        int finished;
        boolean reviewOk;
        int rankExp, completionExp, reviewExp, goalExp;
    }

    private List<Score> weekScores(long partyId, LocalDate weekStart) {
        LocalDate end = weekStart.plusDays(6);
        String from = DateUtil.format(weekStart);
        String to = DateUtil.format(end);
        List<RankEntry> members = memberEntries(partyId);
        List<Score> scores = new ArrayList<>();
        int partyDone = 0, partyFinished = 0;
        for (RankEntry e : members) {
            Score sc = new Score();
            sc.e = e;
            e.points = sumPoints(e.userId, weekStart, end);
            e.doneCount = (int) count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date BETWEEN ? AND ? "
                    + "AND status = 'APPROVED'", e.userId, from, to);
            sc.finished = (int) count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date BETWEEN ? AND ? "
                    + "AND status IN ('APPROVED', 'REJECTED', 'MISSED')", e.userId, from, to);
            long missedVotes = count("SELECT COUNT(*) FROM votes v JOIN plans p ON p.id = v.plan_id WHERE v.voter_id = ? "
                    + "AND v.active = 1 AND v.vote IS NULL AND p.finalized_at IS NOT NULL AND p.plan_date BETWEEN ? AND ?",
                    e.userId, from, to);
            sc.reviewOk = members.size() > 1 && missedVotes == 0;
            partyDone += e.doneCount;
            partyFinished += sc.finished;
            scores.add(sc);
        }
        scores.sort((a, b) -> {
            if (a.e.points != b.e.points) return Integer.compare(b.e.points, a.e.points);
            if (a.e.doneCount != b.e.doneCount) return Integer.compare(b.e.doneCount, a.e.doneCount);
            return Long.compare(a.e.userId, b.e.userId);
        });
        boolean goal = members.size() > 1 && partyFinished > 0
                && partyDone >= Math.ceil(partyFinished * LevelRule.PARTY_GOAL_RATE);
        for (int i = 0; i < scores.size(); i++) {
            Score sc = scores.get(i);
            Score prev = i > 0 ? scores.get(i - 1) : null;
            sc.e.rank = prev != null && prev.e.points == sc.e.points && prev.e.doneCount == sc.e.doneCount ? prev.e.rank : i + 1;
            boolean active = sc.e.points > 0; // 포인트가 0 이하이면 경험치 없음
            sc.rankExp = active ? LevelRule.rankExp(sc.e.rank, members.size()) : 0;
            sc.completionExp = active ? LevelRule.completionExp(sc.e.doneCount, sc.finished) : 0;
            sc.reviewExp = active && sc.reviewOk ? LevelRule.REVIEW_EXP : 0;
            sc.goalExp = active && goal ? LevelRule.PARTY_GOAL_EXP : 0;
            sc.e.exp = sc.rankExp + sc.completionExp + sc.reviewExp + sc.goalExp;
        }
        return scores;
    }

    @Override
    public synchronized RankingResult getRanking(String period) throws Exception {
        long me = requireMe();
        runDueJobs();
        long partyId = partyOf(me);
        RankingResult r = new RankingResult();
        r.period = period;
        LocalDate today = DateUtil.today();

        if (RankingResult.MONTH_CURRENT.equals(period) || RankingResult.MONTH_LAST.equals(period)) {
            YearMonth ym = YearMonth.from(today);
            if (RankingResult.MONTH_LAST.equals(period)) ym = ym.minusMonths(1);
            LocalDate from = ym.atDay(1);
            LocalDate to = ym.atEndOfMonth();
            r.weekStart = DateUtil.format(from);
            r.weekEnd = DateUtil.format(to);
            r.settled = to.isBefore(today);
            List<RankEntry> list = new ArrayList<>(partyId > 0 ? memberEntries(partyId) : List.of(selfEntry(me)));
            for (RankEntry e : list) {
                e.points = sumPoints(e.userId, from, to);
                e.doneCount = (int) count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date BETWEEN ? AND ? "
                        + "AND status = 'APPROVED'", e.userId, r.weekStart, r.weekEnd);
                e.exp = (int) count("SELECT COALESCE(SUM(amount), 0) FROM exp_events WHERE user_id = ? "
                        + "AND week_start BETWEEN ? AND ?", e.userId, r.weekStart, r.weekEnd);
            }
            list.sort((a, b) -> a.points != b.points ? Integer.compare(b.points, a.points) : Integer.compare(b.doneCount, a.doneCount));
            for (int i = 0; i < list.size(); i++) {
                RankEntry e = list.get(i), prev = i > 0 ? list.get(i - 1) : null;
                e.rank = prev != null && prev.points == e.points && prev.doneCount == e.doneCount ? prev.rank : i + 1;
            }
            r.entries = list;
            return r;
        }

        LocalDate mon = DateUtil.weekStart(today);
        boolean last = RankingResult.WEEK_LAST.equals(period);
        if (last) mon = mon.minusWeeks(1);
        r.weekStart = DateUtil.format(mon);
        r.weekEnd = DateUtil.format(mon.plusDays(6));
        if (partyId == 0) {
            r.entries.add(selfEntry(me));
            return r;
        }
        if (last && count("SELECT COUNT(*) FROM weekly_settlements WHERE party_id = ? AND week_start = ?", partyId, r.weekStart) > 0) {
            try (Cursor c = db().rawQuery("SELECT w.user_id, w.rank, w.points, w.done_count, w.exp, "
                    + "u.nickname, u.total_exp, COALESCE(m.character_id, 0) FROM weekly_results w JOIN users u ON u.id = w.user_id "
                    + "LEFT JOIN party_members m ON m.user_id = w.user_id WHERE w.party_id = ? AND w.week_start = ? "
                    + "ORDER BY w.rank, w.user_id", new String[]{s(partyId), r.weekStart})) {
                while (c.moveToNext()) {
                    RankEntry e = new RankEntry();
                    e.userId = c.getLong(0);
                    e.rank = c.getInt(1);
                    e.points = c.getInt(2);
                    e.doneCount = c.getInt(3);
                    e.exp = c.getInt(4);
                    e.nickname = c.getString(5);
                    e.totalExp = c.getInt(6);
                    e.characterId = c.getInt(7);
                    r.entries.add(e);
                }
            }
            r.settled = true;
            return r;
        }
        for (Score sc : weekScores(partyId, mon)) r.entries.add(sc.e);
        return r;
    }

    // ======================================================================
    // 업적 (로컬 데모: 목록 + 연속 올클 업적만 판정. 전체 판정은 서버에서)
    // ======================================================================

    private static final String[][] ACHIEVEMENTS = {
            // code, 이름, 설명, 분류, 보상P, 숨김(1)
            {"STREAK_3", "삼일천하", "3일 연속 계획 올클", "STREAK", "15", "0"},
            {"STREAK_7", "칠일무패", "7일 연속 계획 올클", "STREAK", "40", "0"},
            {"STREAK_30", "철의 의지", "30일 연속 계획 올클", "STREAK", "150", "0"},
            {"PARTY_CLEAR_1", "환상의 팀워크", "파티원 전원이 같은 날 계획 올클 (2명 이상)", "PARTY", "20", "0"},
            {"PARTY_STREAK_7", "전설의 파티", "파티원 전원 올클 7일 연속", "PARTY", "60", "0"},
            {"WEEKEND_CLEAR", "휴일 반납", "같은 주말 토요일·일요일 모두 올클", "FUN", "0", "0"},
            {"STREAK_BROKEN", "작심삼일", "3일 이상 이어진 올클이 끊김", "FUN", "0", "1"},
            {"IDLE_7", "잠수 전문가", "7일 연속 계획을 하나도 등록하지 않음", "FUN", "0", "1"},
            {"FAIL_7", "내일부터는 진짜", "7일 연속 계획 올클 실패", "FUN", "0", "1"},
            {"LAST_MINUTE", "벼락치기의 미학", "사진 마감 10분 전(23:20~23:29)에 제출하고 인정받음", "FUN", "0", "1"},
            {"MONTH_END_SPURT", "막판 스퍼트", "한 달의 마지막 3일 동안 150P 이상", "MONTHLY", "0", "0"},
            {"THRONE_FIRST", "왕좌의 주인", "파티 월간 랭킹 1위를 처음 차지", "MONTHLY", "0", "0"},
            {"THRONE_USURPER", "왕좌 찬탈자", "두 달 연속 1위였던 파티원을 끌어내리고 1위", "MONTHLY", "0", "0"},
    };

    @Override
    public synchronized com.planon.app.model.AchievementList getAchievements() throws Exception {
        long me = requireMe();
        runDueJobs();
        // 어제부터 거꾸로 60일: 올클 = 일정 3개 이상 전부 인정
        LocalDate today = DateUtil.today();
        int current, run = 0, best = 0;
        for (int back = 60; back >= 1; back--) {
            String d = DateUtil.format(today.minusDays(back));
            long total = count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date = ?", me, d);
            long ok = count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date = ? AND status = 'APPROVED'", me, d);
            boolean clear = total >= 3 && ok == total;
            run = clear ? run + 1 : 0;
            best = Math.max(best, run);
        }
        current = run;
        com.planon.app.model.AchievementList list = new com.planon.app.model.AchievementList();
        list.clearStreak = current;
        list.bestClearStreak = best;
        for (String[] a : ACHIEVEMENTS) {
            com.planon.app.model.Achievement x = new com.planon.app.model.Achievement();
            x.code = a[0];
            x.category = a[3];
            x.rewardPoints = Integer.parseInt(a[4]);
            x.hidden = "1".equals(a[5]);
            int need = "STREAK_3".equals(x.code) ? 3 : "STREAK_7".equals(x.code) ? 7 : "STREAK_30".equals(x.code) ? 30 : 0;
            x.earned = need > 0 && best >= need;
            x.count = x.earned ? 1 : 0;
            x.name = x.hidden && !x.earned ? "???" : a[1];
            x.description = x.hidden && !x.earned ? "숨겨진 업적이에요. 조건을 채우면 공개돼요" : a[2];
            if (x.earned) list.earnedCount++;
            list.items.add(x);
        }
        list.totalCount = list.items.size();
        return list;
    }

    // ======================================================================
    // 알림
    // ======================================================================

    @Override
    public synchronized List<AppNotification> getNotifications() throws Exception {
        long me = requireMe();
        runDueJobs();
        List<AppNotification> list = new ArrayList<>();
        try (Cursor c = db().rawQuery("SELECT id, type, title, body, plan_id, is_read, created_at FROM notifications "
                + "WHERE user_id = ? ORDER BY id DESC LIMIT 50", new String[]{s(me)})) {
            while (c.moveToNext()) {
                AppNotification n = new AppNotification();
                n.id = c.getLong(0);
                n.type = c.getString(1);
                n.title = c.getString(2);
                n.body = c.getString(3);
                n.planId = c.isNull(4) ? null : c.getLong(4);
                n.read = c.getInt(5) == 1;
                n.createdAt = c.getString(6);
                list.add(n);
            }
        }
        return list;
    }

    @Override
    public synchronized int getUnreadCount() throws Exception {
        long me = requireMe();
        runDueJobs();
        return (int) count("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", me);
    }

    @Override
    public synchronized void markNotificationRead(long id) throws Exception {
        long me = requireMe();
        db().execSQL("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", new Object[]{id, me});
    }

    @Override
    public synchronized void markAllNotificationsRead() throws Exception {
        long me = requireMe();
        db().execSQL("UPDATE notifications SET is_read = 1 WHERE user_id = ?", new Object[]{me});
    }

    /** 로컬 모드에는 푸시 서버가 없으므로 저장만 함 */
    @Override
    public void registerPushToken(String token) {
        helper.putSetting(DbHelper.KEY_PUSH_TOKEN, token);
    }

    private void notify(long userId, String type, String title, String body, Long planId) {
        ContentValues v = new ContentValues();
        v.put("user_id", userId);
        v.put("type", type);
        v.put("title", title);
        v.put("body", body);
        if (planId != null) v.put("plan_id", planId);
        v.put("is_read", 0);
        v.put("created_at", nowText().substring(0, 16));
        db().insert("notifications", null, v);
    }

    // ======================================================================
    // 내부 도우미
    // ======================================================================

    private long requireMe() throws ApiException {
        long id = helper.getSessionUserId();
        if (id <= 0) throw new ApiException("로그인이 필요해요");
        return id;
    }

    private long partyOf(long userId) {
        try (Cursor c = db().rawQuery("SELECT party_id FROM party_members WHERE user_id = ?", new String[]{s(userId)})) {
            return c.moveToFirst() ? c.getLong(0) : 0;
        }
    }

    private long requireParty(long userId) throws ApiException {
        long id = partyOf(userId);
        if (id == 0) throw new ApiException("먼저 파티에 가입해 주세요");
        return id;
    }

    private void addMember(SQLiteDatabase db, long partyId, long userId) {
        ContentValues m = new ContentValues();
        m.put("user_id", userId);
        m.put("party_id", partyId);
        m.put("character_id", 0);
        m.put("joined_at", System.currentTimeMillis());
        db.insertOrThrow("party_members", null, m);
    }

    private List<Long> memberIds(long partyId) {
        return ids("SELECT user_id FROM party_members WHERE party_id = ? ORDER BY joined_at", partyId);
    }

    private List<Long> activeVoters(long planId) {
        return ids("SELECT voter_id FROM votes WHERE plan_id = ? AND active = 1", planId);
    }

    private List<RankEntry> memberEntries(long partyId) {
        List<RankEntry> list = new ArrayList<>();
        try (Cursor c = db().rawQuery("SELECT u.id, u.nickname, u.total_exp, m.character_id FROM party_members m "
                + "JOIN users u ON u.id = m.user_id WHERE m.party_id = ? ORDER BY m.joined_at", new String[]{s(partyId)})) {
            while (c.moveToNext()) {
                RankEntry e = new RankEntry();
                e.userId = c.getLong(0);
                e.nickname = c.getString(1);
                e.totalExp = c.getInt(2);
                e.characterId = c.getInt(3);
                list.add(e);
            }
        }
        return list;
    }

    private RankEntry selfEntry(long me) {
        User u = loadUserBasic(me);
        RankEntry e = new RankEntry();
        e.rank = 1;
        e.userId = me;
        e.nickname = u == null ? "나" : u.nickname;
        e.totalExp = u == null ? 0 : u.totalExp;
        return e;
    }

    private List<Member> loadMembers(long partyId, long leaderId) {
        List<Member> members = new ArrayList<>();
        String today = DateUtil.todayStr();
        for (RankEntry e : memberEntries(partyId)) {
            Member m = new Member();
            m.userId = e.userId;
            m.nickname = e.nickname;
            m.totalExp = e.totalExp;
            m.characterId = e.characterId;
            m.leader = m.userId == leaderId;
            m.todayTotal = (int) count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date = ?", m.userId, today);
            // 홈 진행도는 "인증 제출" 기준 (결과는 자정에 확정)
            m.todayDone = (int) count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date = ? "
                    + "AND status IN ('VOTING', 'APPROVED')", m.userId, today);
            members.add(m);
        }
        return members;
    }

    /** 사진·투표·마감·버튼 상태를 채움. 확정 전에는 남의 표 내용은 숨김 */
    private void fill(Plan p, long me, boolean withList) {
        try (Cursor c = db().rawQuery("SELECT u.nickname, COALESCE(m.character_id, 0) FROM users u "
                + "LEFT JOIN party_members m ON m.user_id = u.id WHERE u.id = ?", new String[]{s(p.userId)})) {
            if (c.moveToFirst()) {
                p.ownerNickname = c.getString(0);
                p.ownerCharacterId = c.getInt(1);
            }
        }
        p.imageUrls = new ArrayList<>();
        p.photos = new ArrayList<>();
        boolean editableNow = p.userId == me && p.isStatus(Plan.VOTING);
        try (Cursor c = db().rawQuery("SELECT id, path, uploaded_at FROM plan_photos WHERE plan_id = ? ORDER BY id",
                new String[]{s(p.id)})) {
            while (c.moveToNext()) {
                com.planon.app.model.PlanPhoto ph = new com.planon.app.model.PlanPhoto();
                ph.id = c.getLong(0);
                ph.url = c.getString(1);
                LocalDateTime uploaded = parseTime(c.getString(2));
                LocalDateTime until = uploaded.plusMinutes(LevelRule.PHOTO_EDIT_MINUTES);
                ph.uploadedAt = uploaded.toString().substring(0, 16);
                ph.editableUntil = until.toString().substring(0, 16);
                ph.editable = editableNow && now().isBefore(until);
                p.imageUrls.add(ph.url);
                p.photos.add(ph);
            }
        }
        LocalDate date = DateUtil.parse(p.date);
        p.photoDeadline = p.date + "T" + LevelRule.PHOTO_DEADLINE;
        p.voteDeadline = DateUtil.format(date.plusDays(1)) + "T00:00";
        boolean mine = p.userId == me;
        p.finalized = p.isStatus(Plan.APPROVED) || p.isStatus(Plan.REJECTED);

        int approves = 0, rejects = 0, voted = 0, voters = 0;
        boolean amVoter = false;
        p.myVote = 0;
        if (withList) p.votes = new ArrayList<>();
        try (Cursor c = db().rawQuery("SELECT v.voter_id, v.vote, u.nickname FROM votes v JOIN users u ON u.id = v.voter_id "
                + "WHERE v.plan_id = ? AND v.active = 1 ORDER BY v.voter_id", new String[]{s(p.id)})) {
            while (c.moveToNext()) {
                long voterId = c.getLong(0);
                int value = c.isNull(1) ? 0 : c.getInt(1);
                voters++;
                if (value != 0) voted++;
                if (value > 0) approves++;
                if (value < 0) rejects++;
                if (voterId == me) {
                    p.myVote = value;
                    amVoter = true;
                }
                if (withList) {
                    int shown = p.finalized || voterId == me ? value : 0;
                    p.votes.add(new VoteInfo(voterId, c.getString(2), value != 0, shown));
                }
            }
        }
        p.voterCount = voters;
        p.votedCount = voted;
        if (!p.finalized) {
            p.approveCount = 0;
            p.rejectCount = mine ? rejects : 0;
        }
        LocalDateTime now = now();
        p.canSubmit = mine && p.isStatus(Plan.TODO) && date.equals(DateUtil.today()) && now.isBefore(photoDeadline(date));
        p.canAddPhotos = mine && p.isStatus(Plan.VOTING) && now.isBefore(photoDeadline(date))
                && p.imageUrls.size() < LevelRule.MAX_PHOTOS;
        p.canVote = !mine && amVoter && p.isStatus(Plan.VOTING) && now.isBefore(voteDeadline(date));
    }

    private static LocalDateTime parseTime(String text) {
        try {
            return LocalDateTime.parse(text);
        } catch (Exception e) {
            return LocalDateTime.of(2000, 1, 1, 0, 0); // 알 수 없으면 수정 불가로
        }
    }

    /** 내 사진이고, 투표 중이고, 올린 지 10분 안인지 확인 → [path, uploaded_at] */
    private String[] editablePhoto(long me, long planId, long photoId) throws ApiException {
        Plan p = loadPlan(planId);
        if (p == null || p.userId != me) throw new ApiException("내 인증 사진만 바꿀 수 있어요");
        if (!p.isStatus(Plan.VOTING)) throw new ApiException("결과가 확정된 인증의 사진은 바꿀 수 없어요");
        try (Cursor c = db().rawQuery("SELECT path, uploaded_at FROM plan_photos WHERE id = ? AND plan_id = ?",
                new String[]{s(photoId), s(planId)})) {
            if (!c.moveToFirst()) throw new ApiException("사진을 찾을 수 없어요");
            if (!now().isBefore(parseTime(c.getString(1)).plusMinutes(LevelRule.PHOTO_EDIT_MINUTES))) {
                throw new ApiException("사진은 올린 뒤 " + LevelRule.PHOTO_EDIT_MINUTES + "분 안에만 바꾸거나 지울 수 있어요");
            }
            return new String[]{c.getString(0), c.getString(1)};
        }
    }

    @Override
    public synchronized Plan deleteVerificationPhoto(long planId, long photoId) throws Exception {
        long me = requireMe();
        runDueJobs();
        String[] ph = editablePhoto(me, planId, photoId);
        if (count("SELECT COUNT(*) FROM plan_photos WHERE plan_id = ?", planId) <= 1) {
            throw new ApiException("인증 사진은 최소 1장 있어야 해요. 지우는 대신 '바꾸기'를 써 주세요");
        }
        db().delete("plan_photos", "id = ?", new String[]{s(photoId)});
        deleteFile(ph[0]);
        return getVerification(planId);
    }

    @Override
    public synchronized Plan replaceVerificationPhoto(long planId, long photoId, File image) throws Exception {
        long me = requireMe();
        runDueJobs();
        String[] ph = editablePhoto(me, planId, photoId);
        if (image == null || !image.exists()) throw new ApiException("바꿀 사진을 골라 주세요");
        File dir = new File(context.getFilesDir(), "proofs");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("사진을 저장할 수 없어요");
        File dest = new File(dir, "plan_" + planId + "_" + UUID.randomUUID() + ".jpg");
        copy(image, dest);
        ContentValues v = new ContentValues();
        v.put("path", dest.getAbsolutePath()); // uploaded_at 은 그대로 → 바꿔도 수정 시간이 늘어나지 않음
        db().update("plan_photos", v, "id = ?", new String[]{s(photoId)});
        deleteFile(ph[0]);
        Plan p = loadPlan(planId);
        String nick = nickname(me);
        for (long voter : activeVoters(planId)) {
            notify(voter, AppNotification.PHOTO_ADDED, "인증 사진 변경", nick + "님이 '" + p.title + "' 인증 사진을 바꿨어요", planId);
        }
        return getVerification(planId);
    }

    private void deleteFile(String path) {
        if (path == null || path.contains("demo_")) return; // 데모 사진은 다른 곳에서도 쓰므로 남김
        File f = new File(path);
        if (f.exists() && !f.delete()) f.deleteOnExit();
    }

    private void savePhotos(long planId, List<File> photos) throws IOException {
        File dir = new File(context.getFilesDir(), "proofs");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("사진을 저장할 수 없어요");
        for (File f : photos) {
            File dest = new File(dir, "plan_" + planId + "_" + UUID.randomUUID() + ".jpg");
            copy(f, dest);
            ContentValues v = new ContentValues();
            v.put("plan_id", planId);
            v.put("path", dest.getAbsolutePath());
            v.put("uploaded_at", nowText());
            db().insertOrThrow("plan_photos", null, v);
        }
    }

    private static List<File> existing(List<File> images) {
        List<File> out = new ArrayList<>();
        if (images != null) for (File f : images) if (f != null && f.exists()) out.add(f);
        return out;
    }

    private Plan loadPlan(long id) {
        try (Cursor c = db().rawQuery("SELECT * FROM plans WHERE id = ?", new String[]{s(id)})) {
            return c.moveToFirst() ? readPlan(c) : null;
        }
    }

    private Plan readPlan(Cursor c) {
        Plan p = new Plan();
        p.id = c.getLong(c.getColumnIndexOrThrow("id"));
        p.userId = c.getLong(c.getColumnIndexOrThrow("user_id"));
        p.date = c.getString(c.getColumnIndexOrThrow("plan_date"));
        p.title = c.getString(c.getColumnIndexOrThrow("title"));
        p.time = c.getString(c.getColumnIndexOrThrow("start_time"));
        p.category = c.getString(c.getColumnIndexOrThrow("category"));
        p.memo = c.getString(c.getColumnIndexOrThrow("memo"));
        p.status = c.getString(c.getColumnIndexOrThrow("status"));
        p.comment = c.getString(c.getColumnIndexOrThrow("comment"));
        p.submittedAt = c.getString(c.getColumnIndexOrThrow("submitted_at"));
        p.approveCount = c.getInt(c.getColumnIndexOrThrow("approve_count"));
        p.rejectCount = c.getInt(c.getColumnIndexOrThrow("reject_count"));
        return p;
    }

    private User loadUserBasic(long id) {
        try (Cursor c = db().rawQuery("SELECT id, login_id, nickname, total_exp FROM users WHERE id = ?", new String[]{s(id)})) {
            if (!c.moveToFirst()) return null;
            User u = new User();
            u.id = c.getLong(0);
            u.loginId = c.getString(1);
            u.nickname = c.getString(2);
            u.totalExp = c.getInt(3);
            return u;
        }
    }

    private String nickname(long userId) {
        return DatabaseUtils.stringForQuery(db(), "SELECT nickname FROM users WHERE id = ?", new String[]{s(userId)});
    }

    /** 포인트는 일정 날짜 기준 */
    private int sumPoints(long userId, LocalDate from, LocalDate to) {
        return (int) count("SELECT COALESCE(SUM(points), 0) FROM point_events WHERE user_id = ? AND event_date BETWEEN ? AND ?",
                userId, DateUtil.format(from), DateUtil.format(to));
    }

    private long count(String sql, Object... args) {
        return DatabaseUtils.longForQuery(db(), sql, strings(args));
    }

    private List<Long> ids(String sql, Object... args) {
        List<Long> out = new ArrayList<>();
        try (Cursor c = db().rawQuery(sql, strings(args))) {
            while (c.moveToNext()) out.add(c.getLong(0));
        }
        return out;
    }

    private static String[] strings(Object... args) {
        String[] out = new String[args.length];
        for (int i = 0; i < args.length; i++) out[i] = String.valueOf(args[i]);
        return out;
    }

    private static String s(long v) {
        return String.valueOf(v);
    }

    private static LocalDateTime now() {
        return LocalDateTime.now().withNano(0);
    }

    private static String nowText() {
        return now().toString();
    }

    private static LocalDateTime photoDeadline(LocalDate date) {
        return date.atTime(LevelRule.PHOTO_DEADLINE_HOUR, LevelRule.PHOTO_DEADLINE_MINUTE);
    }

    private static LocalDateTime voteDeadline(LocalDate date) {
        return date.plusDays(1).atStartOfDay();
    }

    private String newInviteCode() {
        while (true) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 6; i++) sb.append(CODE_CHARS.charAt(random.nextInt(CODE_CHARS.length())));
            String code = sb.toString();
            if (count("SELECT COUNT(*) FROM parties WHERE invite_code = ?", code) == 0) return code;
        }
    }

    static String hash(String loginId, String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest((loginId + ":" + password).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : out) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static String emptyToNull(String s) {
        return s == null || s.trim().isEmpty() ? null : s.trim();
    }

    private static void copy(File src, File dest) throws IOException {
        try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    // ======================================================================
    // 데모 데이터
    // ======================================================================

    /** 데모 계정 4개 + 파티 + 일정을 만듭니다. 이미 있으면 아무것도 하지 않습니다. */
    public synchronized String seedDemo() throws Exception {
        return DemoSeeder.seed(context, db());
    }
}
