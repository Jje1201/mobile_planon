package com.planon.app.model;

/** 인증 사진 한 장 (서버 PhotoDto 와 같은 필드) */
public class PlanPhoto {
    public long id;
    /** 로컬 모드: 파일 경로, 서버 모드: 이미지 URL */
    public String url;
    /** yyyy-MM-ddTHH:mm */
    public String uploadedAt;
    /** 이 시각까지 바꾸거나 지울 수 있음 (올린 뒤 10분) */
    public String editableUntil;
    /** 지금 바꾸거나 지울 수 있는지 (본인 · 투표 중 · 10분 이내) */
    public boolean editable;
}
