package com.planon.app.data;

import android.content.Context;

import com.planon.app.AppConfig;
import com.planon.app.data.local.DbHelper;
import com.planon.app.data.local.LocalRepository;
import com.planon.app.data.remote.RemoteRepository;

public final class RepositoryProvider {
    private RepositoryProvider() {
    }

    public static final String KEY_SERVER_URL = "server_url";

    private static Repository instance;
    private static Context appContext;

    public static synchronized void init(Context context) {
        if (instance != null) return;
        appContext = context.getApplicationContext();
        DbHelper db = DbHelper.get(appContext);
        if (AppConfig.USE_REMOTE_SERVER) {
            instance = new RemoteRepository(db, serverUrl(appContext));
        } else {
            instance = new LocalRepository(appContext, db);
        }
    }

    public static Repository get() {
        if (instance == null) throw new IllegalStateException("RepositoryProvider.init() 이 먼저 호출되어야 합니다");
        return instance;
    }

    /** 로컬 데모 모드일 때만 값이 있음 */
    public static LocalRepository local() {
        return instance instanceof LocalRepository ? (LocalRepository) instance : null;
    }

    public static RemoteRepository remote() {
        return instance instanceof RemoteRepository ? (RemoteRepository) instance : null;
    }

    /** 로그인 화면에서 바꾼 서버 주소 (없으면 AppConfig.BASE_URL) */
    public static String serverUrl(Context context) {
        String saved = DbHelper.get(context).getSetting(KEY_SERVER_URL);
        return saved == null || saved.isEmpty() ? AppConfig.BASE_URL : saved;
    }

    /** "192.168.0.10:8080" → "http://192.168.0.10:8080/" */
    public static String normalize(String url) {
        String u = url.trim();
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "http://" + u;
        if (!u.endsWith("/")) u = u + "/";
        return u;
    }

    /** 서버 주소를 바꾸고 연결 객체를 새로 만듦 (로그인 정보는 지움) */
    public static synchronized void changeServerUrl(String url) {
        String u = normalize(url);
        DbHelper db = DbHelper.get(appContext);
        db.putSetting(KEY_SERVER_URL, u);
        db.clearSession();
        if (AppConfig.USE_REMOTE_SERVER) instance = new RemoteRepository(db, u);
    }
}
