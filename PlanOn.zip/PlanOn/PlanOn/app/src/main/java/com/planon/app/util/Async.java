package com.planon.app.util;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.planon.app.data.ApiException;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DB/네트워크 작업은 메인 스레드에서 하면 안 되므로
 * 백그라운드에서 실행하고 결과만 메인 스레드로 돌려주는 도우미.
 */
public final class Async {
    private Async() {
    }

    private static final String TAG = "Async";
    private static final ExecutorService IO = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Work<T> {
        T run() throws Exception;
    }

    public interface Done<T> {
        void onResult(T result);
    }

    public interface Fail {
        void onError(String message);
    }

    public static <T> void run(Work<T> work, Done<T> done, Fail fail) {
        IO.execute(() -> {
            try {
                T result = work.run();
                MAIN.post(() -> {
                    if (done != null) done.onResult(result);
                });
            } catch (Exception e) {
                Log.w(TAG, "작업 실패", e);
                String msg = messageOf(e);
                MAIN.post(() -> {
                    if (fail != null) fail.onError(msg);
                });
            }
        });
    }

    public static String messageOf(Exception e) {
        if (e instanceof ApiException) return e.getMessage();
        if (e instanceof IOException) return "서버에 연결할 수 없어요. 네트워크(Wi-Fi)를 확인해 주세요.";
        return "문제가 발생했어요: " + e.getClass().getSimpleName();
    }
}
