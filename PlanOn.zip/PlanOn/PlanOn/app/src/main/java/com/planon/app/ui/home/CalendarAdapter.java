package com.planon.app.ui.home;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.planon.app.R;
import com.planon.app.util.DateUtil;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 한 달 달력 (일요일 시작, 7열 그리드) */
public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.VH> {

    public interface OnDayClick {
        void onDay(LocalDate date);
    }

    private final List<LocalDate> cells = new ArrayList<>(); // 빈 칸은 null
    private final Set<String> planDates = new HashSet<>();
    private LocalDate selected;
    private final OnDayClick listener;

    public CalendarAdapter(OnDayClick listener) {
        this.listener = listener;
    }

    public void setMonth(YearMonth month, LocalDate selected) {
        this.selected = selected;
        cells.clear();
        LocalDate first = month.atDay(1);
        int offset = first.getDayOfWeek().getValue() % 7; // 일요일 = 0
        for (int i = 0; i < offset; i++) cells.add(null);
        for (int d = 1; d <= month.lengthOfMonth(); d++) cells.add(month.atDay(d));
        while (cells.size() % 7 != 0) cells.add(null);
        notifyDataSetChanged();
    }

    public void setSelected(LocalDate date) {
        selected = date;
        notifyDataSetChanged();
    }

    public void setPlanDates(Set<String> dates) {
        planDates.clear();
        if (dates != null) planDates.addAll(dates);
        notifyDataSetChanged();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView day;
        final View dot;

        VH(View v) {
            super(v);
            day = v.findViewById(R.id.text_day);
            dot = v.findViewById(R.id.dot);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_calendar_day, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        LocalDate date = cells.get(position);
        if (date == null) {
            h.day.setText("");
            h.day.setBackground(null);
            h.dot.setVisibility(View.INVISIBLE);
            h.itemView.setOnClickListener(null);
            h.itemView.setClickable(false);
            return;
        }
        boolean isSelected = date.equals(selected);
        boolean isToday = date.equals(DateUtil.today());

        h.day.setText(String.valueOf(date.getDayOfMonth()));
        h.day.setTypeface(null, (isSelected || isToday) ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);

        int colorRes;
        if (isSelected) colorRes = R.color.white;
        else if (date.getDayOfWeek() == DayOfWeek.SUNDAY) colorRes = R.color.sunday;
        else if (date.getDayOfWeek() == DayOfWeek.SATURDAY) colorRes = R.color.primary;
        else colorRes = R.color.ink;
        h.day.setTextColor(ContextCompat.getColor(h.itemView.getContext(), colorRes));

        if (isSelected) h.day.setBackgroundResource(R.drawable.bg_day_selected);
        else if (isToday) h.day.setBackgroundResource(R.drawable.bg_day_today);
        else h.day.setBackground(null);

        h.dot.setVisibility(planDates.contains(DateUtil.format(date)) ? View.VISIBLE : View.INVISIBLE);
        h.itemView.setContentDescription(DateUtil.korean(date));
        h.itemView.setOnClickListener(v -> listener.onDay(date));
    }

    @Override
    public int getItemCount() {
        return cells.size();
    }
}
