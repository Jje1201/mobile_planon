package com.planon.app.data;

/** 저장된 로그인 정보가 만료·폐기됨 → 목록에서 지우고 비밀번호 입력으로 */
public class SavedLoginExpiredException extends ApiException {
    public SavedLoginExpiredException(String message) {
        super(message);
    }
}
