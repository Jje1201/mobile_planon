package com.planon.app;

import android.app.Application;

import com.planon.app.data.RepositoryProvider;
import com.planon.app.push.PushSetup;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        RepositoryProvider.init(this);
        PushSetup.init(this);
    }
}
