package com.planon.app.util;

/**
 * 포인트 · 경험치 · 레벨 규칙을 한 곳에 모아둔 클래스.
 * Spring 서버 common/LevelRule.java 와 같은 값이어야 합니다.
 *
 * 포인트(pt): 일정 하나의 결과 → 인정 +10, 미수행(미인정) −10, 미인증 0. 일정당 한 번만.
 * 경험치(EXP): 매주 월요일 결산에서만 지급 → 순위 + 달성률 + 검토 참여 + 파티 목표
 */
public final class LevelRule {
    private LevelRule() {
    }

    // ---------- 포인트 ----------
    public static final int PLAN_POINT = 10;
    public static final int FAIL_PENALTY = 10;

    // ---------- 레벨: L → L+1 필요 경험치 = 15 + 2 × (L−1) ----------
    public static final int BASE_NEED = 15;
    public static final int NEED_STEP = 2;
    public static final int MAX_LEVEL = 50;
    public static final int LEVELS_PER_STAGE = 10;
    public static final int MAX_STAGE = MAX_LEVEL / LEVELS_PER_STAGE; // 5

    // ---------- 주간 경험치 ----------
    /** 주간 순위별 경험치 (1위, 2위, 3위, 4위) */
    public static final int[] RANK_EXP = {60, 45, 35, 25};
    /** 혼자인 파티의 순위 경험치 */
    public static final int SOLO_RANK_EXP = 35;
    public static final int COMPLETION_FULL_EXP = 25;   // 달성률 100%
    public static final int COMPLETION_HIGH_EXP = 15;   // 80% 이상
    public static final int COMPLETION_HALF_EXP = 5;    // 50% 이상
    public static final int REVIEW_EXP = 15;            // 투표권 받은 인증에 모두 투표
    public static final int PARTY_GOAL_EXP = 10;        // 파티 전체 인정률 70% 이상
    public static final double PARTY_GOAL_RATE = 0.7;

    // ---------- 시간 ----------
    /** 인증 사진 등록·추가 마감 (일정 날짜) */
    public static final String PHOTO_DEADLINE = "23:30";
    public static final int PHOTO_DEADLINE_HOUR = 23;
    public static final int PHOTO_DEADLINE_MINUTE = 30;
    public static final int MAX_FIRST_PHOTOS = 5;
    public static final int MAX_PHOTOS = 10;
    /** 사진은 올린 뒤 이 시간(분) 동안만 바꾸거나 지울 수 있음 */
    public static final int PHOTO_EDIT_MINUTES = 10;
    public static final String PHOTO_EDIT_NOTICE = "사진은 올린 뒤 " + PHOTO_EDIT_MINUTES + "분 이내에만 바꾸거나 지울 수 있어요.";

    public static int needForNext(int level) {
        return BASE_NEED + NEED_STEP * (level - 1);
    }

    /** 레벨 L 에 도달하는 데 필요한 누적 경험치 = (L−1)(L+13) */
    public static int totalForLevel(int level) {
        return (level - 1) * (level + 13);
    }

    public static int levelFor(int totalExp) {
        int level = 1;
        while (level < MAX_LEVEL && totalExp >= totalForLevel(level + 1)) level++;
        return level;
    }

    /** 현재 레벨에서 쌓은 경험치 */
    public static int expInLevel(int totalExp) {
        int level = levelFor(totalExp);
        return totalExp - totalForLevel(level);
    }

    /** Lv1~10 → 1단계, Lv11~20 → 2단계 ... Lv41~50 → 5단계 */
    public static int stageFor(int level) {
        int stage = (level - 1) / LEVELS_PER_STAGE + 1;
        return Math.max(1, Math.min(MAX_STAGE, stage));
    }

    public static int rankExp(int rank, int memberCount) {
        if (memberCount <= 1) return SOLO_RANK_EXP;
        if (rank < 1 || rank > RANK_EXP.length) return 0;
        return RANK_EXP[rank - 1];
    }

    public static int completionExp(int done, int total) {
        if (total == 0) return 0;
        double rate = done / (double) total;
        if (rate >= 1.0) return COMPLETION_FULL_EXP;
        if (rate >= 0.8) return COMPLETION_HIGH_EXP;
        if (rate >= 0.5) return COMPLETION_HALF_EXP;
        return 0;
    }

    /** 자정 판정: 미인정 > 인정 이면 미수행, 같으면 인정. 투표 안 한 사람은 세지 않음 */
    public static boolean approved(int approves, int rejects) {
        return rejects <= approves;
    }
}
