package com.planon.app.push;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.planon.app.R;
import com.planon.app.ui.notification.NotificationActivity;
import com.planon.app.ui.verify.VerifyReviewActivity;

/** 휴대폰 상단 알림 표시 (FCM 수신, 알림함 확인 작업 공통) */
public final class NotificationHelper {
    private NotificationHelper() {
    }

    /** 서버 PushService 의 channel_id 와 같아야 함 */
    public static final String CHANNEL_ID = "planon_default";

    public static void createChannel(Context context) {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "인증·투표 알림",
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("투표 요청, 미인정 표, 자정 결과, 주간 결산 알림");
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    public static boolean canNotify(Context context) {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return NotificationManagerCompat.from(context).areNotificationsEnabled();
    }

    /** id 가 같으면 같은 알림을 갱신 */
    public static void show(Context context, int id, String title, String body, Long planId) {
        if (!canNotify(context)) return;
        Intent open = planId != null && planId > 0
                ? VerifyReviewActivity.open(context, planId)
                : new Intent(context, NotificationActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);
        try {
            NotificationManagerCompat.from(context).notify(id, b.build());
        } catch (SecurityException ignored) {
            // 알림 권한이 없으면 표시하지 않음 (알림함에서는 볼 수 있음)
        }
    }
}
