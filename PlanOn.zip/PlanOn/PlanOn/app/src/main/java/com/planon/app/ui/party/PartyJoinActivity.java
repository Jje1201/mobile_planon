package com.planon.app.ui.party;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.planon.app.R;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.model.Party;
import com.planon.app.ui.Router;
import com.planon.app.util.Async;

public class PartyJoinActivity extends AppCompatActivity {

    private final Repository repo = RepositoryProvider.get();

    private View groupCreate, groupJoin, cardCode;
    private TextView textCode, textCodeParty, textMemberCount;
    private TextInputEditText editPartyName, editCode;
    private MaterialButton btnCreate, btnJoin, btnNext;
    private MaterialButtonToggleGroup toggle;

    private Party party;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_party_join);

        groupCreate = findViewById(R.id.group_create);
        groupJoin = findViewById(R.id.group_join);
        cardCode = findViewById(R.id.card_code);
        textCode = findViewById(R.id.text_code);
        textCodeParty = findViewById(R.id.text_code_party);
        textMemberCount = findViewById(R.id.text_member_count);
        editPartyName = findViewById(R.id.edit_party_name);
        editCode = findViewById(R.id.edit_invite_code);
        btnCreate = findViewById(R.id.btn_create_party);
        btnJoin = findViewById(R.id.btn_join);
        btnNext = findViewById(R.id.btn_next);
        toggle = findViewById(R.id.toggle_mode);

        toggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            boolean create = checkedId == R.id.btn_tab_create;
            groupCreate.setVisibility(create ? View.VISIBLE : View.GONE);
            groupJoin.setVisibility(create ? View.GONE : View.VISIBLE);
        });

        btnCreate.setOnClickListener(v -> createParty());
        btnJoin.setOnClickListener(v -> joinParty());
        btnNext.setOnClickListener(v -> Router.go(this, CharacterSelectActivity.class));
        findViewById(R.id.btn_copy).setOnClickListener(v -> copyCode());
        findViewById(R.id.btn_share).setOnClickListener(v -> shareCode(this, party));
        findViewById(R.id.btn_logout).setOnClickListener(v -> {
            repo.logout();
            Router.toLogin(this);
        });

        // 이미 파티를 만든 뒤 앱을 다시 켠 경우
        Async.run(repo::getMyParty, p -> {
            if (p != null) showCreated(p);
        }, msg -> { });
    }

    private void createParty() {
        String name = editPartyName.getText() == null ? "" : editPartyName.getText().toString().trim();
        if (name.isEmpty()) {
            toast("파티 이름을 입력해 주세요");
            return;
        }
        btnCreate.setEnabled(false);
        Async.run(() -> repo.createParty(name), this::showCreated, msg -> {
            btnCreate.setEnabled(true);
            toast(msg);
        });
    }

    private void joinParty() {
        String code = editCode.getText() == null ? "" : editCode.getText().toString().trim();
        if (code.length() != 6) {
            toast("초대 코드 6자리를 입력해 주세요");
            return;
        }
        btnJoin.setEnabled(false);
        Async.run(() -> repo.joinParty(code), p -> {
            toast("'" + p.name + "' 파티에 참여했어요!");
            Router.go(this, CharacterSelectActivity.class);
        }, msg -> {
            btnJoin.setEnabled(true);
            toast(msg);
        });
    }

    private void showCreated(Party p) {
        party = p;
        toggle.check(R.id.btn_tab_create);
        findViewById(R.id.btn_tab_join).setEnabled(false);
        editPartyName.setText(p.name);
        editPartyName.setEnabled(false);
        btnCreate.setVisibility(View.GONE);
        cardCode.setVisibility(View.VISIBLE);
        textCodeParty.setText("'" + p.name + "' 초대 코드");
        textCode.setText(p.inviteCode);
        textMemberCount.setText("현재 인원 " + p.size() + " / " + Party.MAX_MEMBERS + " · 코드를 파티원에게 보내 주세요");
        btnNext.setEnabled(true);
    }

    private void copyCode() {
        if (party == null) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("초대 코드", party.inviteCode));
        toast("초대 코드를 복사했어요");
    }

    /** 공유 시트로 초대 코드 보내기 (홈/마이페이지에서도 사용) */
    public static void shareCode(Context context, Party party) {
        if (party == null) return;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, "[PLAN:ON] '" + party.name + "' 파티에 초대합니다!\n초대 코드: " + party.inviteCode);
        context.startActivity(Intent.createChooser(send, "초대 코드 보내기"));
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
