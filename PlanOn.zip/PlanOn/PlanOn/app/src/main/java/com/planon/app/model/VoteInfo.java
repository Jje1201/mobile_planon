package com.planon.app.model;

/** 인증 검토 화면에 표시할 파티원 한 명의 투표 상태 */
public class VoteInfo {
    public long userId;
    public String nickname;
    /** 투표했는지 (결과 확정 전에는 남의 표 내용은 숨기고 이것만 보여줌) */
    public boolean voted;
    /** 1 인정, -1 미인정, 0 아직 안 함 또는 비공개 */
    public int vote;

    public VoteInfo() {
    }

    public VoteInfo(long userId, String nickname, boolean voted, int vote) {
        this.userId = userId;
        this.nickname = nickname;
        this.voted = voted;
        this.vote = vote;
    }
}
