package com.planon.app.data;

/** 사용자에게 그대로 보여줄 수 있는 오류 메시지를 담는 예외 */
public class ApiException extends Exception {
    public ApiException(String message) {
        super(message);
    }
}
