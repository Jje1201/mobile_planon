package com.planon.app.data;

import com.planon.app.model.AchievementList;
import com.planon.app.model.AppNotification;
import com.planon.app.model.Party;
import com.planon.app.model.Plan;
import com.planon.app.model.RankingResult;
import com.planon.app.model.SavedAccount;
import com.planon.app.model.User;

import java.io.File;
import java.util.List;
import java.util.Set;

/**
 * 화면(UI)이 사용하는 데이터 창구.
 * - LocalRepository : SQLite (서버 없이 실행)
 * - RemoteRepository: Spring 서버 (Retrofit)
 *
 * 모든 메서드는 오래 걸릴 수 있으므로 반드시 백그라운드 스레드(Async)에서 호출합니다.
 */
public interface Repository {

    // ---------- 회원 ----------
    boolean isLoginIdAvailable(String loginId) throws Exception;

    User signUp(String loginId, String password, String nickname) throws Exception;

    /** remember = true 면 이 기기의 "최근 로그인 계정" 목록에 저장 */
    User login(String loginId, String password, boolean remember) throws Exception;

    /** 이 기기에서 저장한 계정 (최근 로그인 순, 최대 5개) */
    List<SavedAccount> getSavedAccounts();

    /** 저장한 계정으로 비밀번호 없이 로그인. 만료됐으면 목록에서 지우고 SavedLoginExpiredException */
    User quickLogin(SavedAccount account) throws Exception;

    /** 목록에서 계정 지우기 (서버에 저장된 로그인 정보도 폐기) */
    void forgetAccount(SavedAccount account);

    void logout();

    boolean isLoggedIn();

    /** 내 정보 (레벨, 포인트, 파티, 캐릭터 포함) */
    User getMe() throws Exception;

    // ---------- 파티 (한 사람은 파티 하나만) ----------
    Party createParty(String name) throws Exception;

    Party joinParty(String inviteCode) throws Exception;

    /** 내 파티 + 파티원별 오늘 진행도. 파티가 없으면 null */
    Party getMyParty() throws Exception;

    void leaveParty() throws Exception;

    /** 캐릭터 선택 (같은 파티에서 다른 사람이 고른 캐릭터는 불가) */
    void selectCharacter(int characterId) throws Exception;

    // ---------- 일정 ----------
    /** userId의 date 일정. 다른 파티원 일정은 오늘 것만 볼 수 있습니다. */
    List<Plan> getPlans(long userId, String date) throws Exception;

    /** 내 일정이 있는 날짜 목록 (yearMonth = "2026-10") → 캘린더 점 표시용 */
    Set<String> getMyPlanDates(String yearMonth) throws Exception;

    Plan addPlan(String date, String title, String time, String category, String memo) throws Exception;

    void deletePlan(long planId) throws Exception;

    // ---------- 인증 ----------
    /** 처음 제출: 사진 1~5장 + 코멘트. 일정 당일 23:30 까지 */
    Plan submitVerification(long planId, List<File> images, String comment) throws Exception;

    /** 미인정을 받았을 때 등 23:30 전까지 사진을 보탬 (합계 10장, 이미 받은 표는 유지) */
    Plan addVerificationPhotos(long planId, List<File> images) throws Exception;

    /** 올린 지 10분 안의 사진 지우기 (마지막 1장은 불가 → 바꾸기) */
    Plan deleteVerificationPhoto(long planId, long photoId) throws Exception;

    /** 올린 지 10분 안의 사진을 다른 사진으로 바꾸기 (수정 가능 시간은 처음 올린 시각 기준) */
    Plan replaceVerificationPhoto(long planId, long photoId, File image) throws Exception;

    /** 일정 + 사진 + 파티원 투표 현황 */
    Plan getVerification(long planId) throws Exception;

    /** 인정/미인정 투표 또는 변경 (자정까지). 본인 인증에는 불가 */
    Plan vote(long planId, boolean approve) throws Exception;

    // ---------- 랭킹 ----------
    /** period = RankingResult.WEEK_CURRENT / WEEK_LAST / MONTH_CURRENT / MONTH_LAST */
    RankingResult getRanking(String period) throws Exception;

    // ---------- 업적 ----------
    /** 업적 13개 + 연속 올클 기록 */
    AchievementList getAchievements() throws Exception;

    // ---------- 알림 ----------
    List<AppNotification> getNotifications() throws Exception;

    int getUnreadCount() throws Exception;

    void markNotificationRead(long id) throws Exception;

    void markAllNotificationsRead() throws Exception;

    /** FCM 토큰 등록 (서버 모드에서만 의미 있음) */
    void registerPushToken(String token) throws Exception;
}
