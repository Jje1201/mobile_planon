package com.planon.app.model;

import java.util.ArrayList;
import java.util.List;

/** 마이페이지 업적 영역 */
public class AchievementList {
    /** 지금 이어지고 있는 연속 올클 일수 (어제까지 확정된 날 기준) */
    public int clearStreak;
    public int bestClearStreak;
    public int earnedCount;
    public int totalCount;
    public List<Achievement> items = new ArrayList<>();
}
