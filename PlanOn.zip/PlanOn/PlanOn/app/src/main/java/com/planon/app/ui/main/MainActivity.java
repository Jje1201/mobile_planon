package com.planon.app.ui.main;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.planon.app.R;
import com.planon.app.push.PushSetup;
import com.planon.app.ui.home.HomeFragment;
import com.planon.app.ui.mypage.MyPageFragment;
import com.planon.app.ui.ranking.RankingFragment;

/** 하단 메뉴(홈 · 랭킹 · 마이페이지)를 담는 화면 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG_HOME = "home";
    private static final String TAG_RANKING = "ranking";
    private static final String TAG_MYPAGE = "mypage";

    /** 안드로이드 13+ 알림 권한 (거절해도 앱 안 알림함은 그대로 동작) */
    private final ActivityResultLauncher<String> askNotification = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) show(TAG_HOME);
            else if (id == R.id.nav_ranking) show(TAG_RANKING);
            else if (id == R.id.nav_mypage) show(TAG_MYPAGE);
            return true;
        });
        nav.setOnItemReselectedListener(item -> { });

        if (savedInstanceState == null) {
            show(TAG_HOME);
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                    Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                askNotification.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
        // 로그인한 계정으로 푸시 토큰 등록 (FCM 설정이 있을 때만)
        PushSetup.refreshToken();
    }

    /** 탭 전환: 한 번 만든 화면은 숨겼다 보여줘서 상태(선택한 날짜 등)를 유지 */
    private void show(String tag) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction tx = fm.beginTransaction();
        for (Fragment f : fm.getFragments()) {
            if (!tag.equals(f.getTag())) tx.hide(f);
        }
        Fragment target = fm.findFragmentByTag(tag);
        if (target == null) {
            tx.add(R.id.fragment_container, create(tag), tag);
        } else {
            tx.show(target);
        }
        tx.commit();
    }

    private Fragment create(String tag) {
        switch (tag) {
            case TAG_RANKING:
                return new RankingFragment();
            case TAG_MYPAGE:
                return new MyPageFragment();
            default:
                return new HomeFragment();
        }
    }
}
