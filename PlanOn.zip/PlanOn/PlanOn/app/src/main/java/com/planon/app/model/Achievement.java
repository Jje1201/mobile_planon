package com.planon.app.model;

/** 업적 하나 (서버 AchievementDto 와 같은 필드). 받기 전 숨김 업적은 name 이 "???" */
public class Achievement {
    public static final String STREAK = "STREAK";
    public static final String PARTY = "PARTY";
    public static final String FUN = "FUN";
    public static final String MONTHLY = "MONTHLY";

    public String code;
    public String name;
    public String description;
    /** STREAK · PARTY · FUN · MONTHLY */
    public String category;
    /** 처음 받을 때 한 번 주는 포인트 (없으면 0) */
    public int rewardPoints;
    public boolean hidden;
    public boolean earned;
    /** 받은 횟수 */
    public int count;
    /** 처음 받은 날 yyyy-MM-ddTHH:mm */
    public String firstAchievedAt;
}
