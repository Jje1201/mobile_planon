package com.planon.app.util;

import android.widget.ImageView;

import androidx.core.content.ContextCompat;

import com.planon.app.R;

/**
 * 캐릭터 이미지 매핑. 1 블루 · 2 그린 · 3 레드 · 4 옐로, 레벨에 따라 5단계로 성장합니다.
 * - image(): 원본 그대로 (마이페이지 등 크게 보여줄 때)
 * - face(): 얼굴 쪽으로 확대한 이미지 (랭킹·진행도처럼 작은 동그라미에 넣을 때)
 * 이미지 파일: res/drawable-nodpi/char_{캐릭터}_s{단계}.png, char_{캐릭터}_s{단계}_face.png
 */
public final class Characters {
    private Characters() {
    }

    public static final int COUNT = 4;

    public static final String[] NAMES = {"블루", "그린", "레드", "옐로"};

    /** [캐릭터 1~4][성장 단계 1~5] → 원본 이미지 */
    private static final int[][] IMAGES = {
            {R.drawable.char_1_s1, R.drawable.char_1_s2, R.drawable.char_1_s3, R.drawable.char_1_s4, R.drawable.char_1_s5},
            {R.drawable.char_2_s1, R.drawable.char_2_s2, R.drawable.char_2_s3, R.drawable.char_2_s4, R.drawable.char_2_s5},
            {R.drawable.char_3_s1, R.drawable.char_3_s2, R.drawable.char_3_s3, R.drawable.char_3_s4, R.drawable.char_3_s5},
            {R.drawable.char_4_s1, R.drawable.char_4_s2, R.drawable.char_4_s3, R.drawable.char_4_s4, R.drawable.char_4_s5},
    };

    /** 얼굴 쪽으로 확대한 이미지 */
    private static final int[][] FACES = {
            {R.drawable.char_1_s1_face, R.drawable.char_1_s2_face, R.drawable.char_1_s3_face, R.drawable.char_1_s4_face, R.drawable.char_1_s5_face},
            {R.drawable.char_2_s1_face, R.drawable.char_2_s2_face, R.drawable.char_2_s3_face, R.drawable.char_2_s4_face, R.drawable.char_2_s5_face},
            {R.drawable.char_3_s1_face, R.drawable.char_3_s2_face, R.drawable.char_3_s3_face, R.drawable.char_3_s4_face, R.drawable.char_3_s5_face},
            {R.drawable.char_4_s1_face, R.drawable.char_4_s2_face, R.drawable.char_4_s3_face, R.drawable.char_4_s4_face, R.drawable.char_4_s5_face},
    };

    private static final int[] DARK = {R.color.char_1, R.color.char_2, R.color.char_3, R.color.char_4};
    private static final int[] SOFT = {R.color.char_1_soft, R.color.char_2_soft, R.color.char_3_soft, R.color.char_4_soft};

    private static int clampStage(int stage) {
        return Math.max(1, Math.min(LevelRule.MAX_STAGE, stage));
    }

    private static boolean valid(int characterId) {
        return characterId >= 1 && characterId <= COUNT;
    }

    public static int image(int characterId, int stage) {
        if (!valid(characterId)) return R.drawable.char_none;
        return IMAGES[characterId - 1][clampStage(stage) - 1];
    }

    public static int image(int characterId) {
        return image(characterId, 1);
    }

    public static int face(int characterId, int stage) {
        if (!valid(characterId)) return R.drawable.char_none;
        return FACES[characterId - 1][clampStage(stage) - 1];
    }

    /** 캐릭터의 짙은 포인트 색 */
    public static int color(int characterId) {
        return valid(characterId) ? DARK[characterId - 1] : R.color.primary;
    }

    /** 캐릭터의 옅은 파스텔 색 */
    public static int softColor(int characterId) {
        return valid(characterId) ? SOFT[characterId - 1] : R.color.fill;
    }

    /** 작은 동그라미 아바타: 얼굴 확대 이미지 + 흰 배경 */
    public static void bindFace(ImageView view, int characterId, int stage) {
        view.setImageResource(face(characterId, stage));
        view.setScaleType(ImageView.ScaleType.CENTER_CROP);
        view.setBackgroundColor(ContextCompat.getColor(view.getContext(), R.color.white));
    }

    public static String name(int characterId) {
        if (!valid(characterId)) return "미선택";
        return NAMES[characterId - 1];
    }
}
