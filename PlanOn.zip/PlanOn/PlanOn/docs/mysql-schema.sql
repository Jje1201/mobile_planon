-- 참고용 사본: 실제로는 서버가 시작할 때 Flyway 가 server/src/main/resources/db/migration 의 V1~V4 를 자동 적용합니다.


-- PLAN:ON 초기 데이터베이스 구조
-- MySQL 8.x / Flyway V1

-- 1. 회원
CREATE TABLE users (
                       id BIGINT PRIMARY KEY AUTO_INCREMENT,
                       login_id VARCHAR(50) NOT NULL UNIQUE,
                       password_hash VARCHAR(255) NOT NULL,
                       nickname VARCHAR(30) NOT NULL,
                       total_exp INT NOT NULL DEFAULT 0,
                       level INT NOT NULL DEFAULT 1,
                       created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                       deleted_at TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 파티
CREATE TABLE parties (
                         id BIGINT PRIMARY KEY AUTO_INCREMENT,
                         name VARCHAR(50) NOT NULL,
                         invite_code VARCHAR(20) NOT NULL UNIQUE,
                         leader_id BIGINT NOT NULL,
                         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                         CONSTRAINT fk_parties_leader
                             FOREIGN KEY (leader_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 파티원
-- user_id가 PK이므로 회원 한 명은 파티 하나에만 소속
CREATE TABLE party_members (
                               user_id BIGINT PRIMARY KEY,
                               party_id BIGINT NOT NULL,
                               character_id VARCHAR(50) NULL,
                               joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               CONSTRAINT fk_party_members_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               CONSTRAINT fk_party_members_party
                                   FOREIGN KEY (party_id) REFERENCES parties(id),
                               UNIQUE KEY uq_party_character (party_id, character_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. 일정
CREATE TABLE plans (
                       id BIGINT PRIMARY KEY AUTO_INCREMENT,
                       user_id BIGINT NOT NULL,
                       party_id BIGINT NULL,
                       plan_date DATE NOT NULL,
                       title VARCHAR(100) NOT NULL,
                       start_time TIME NULL,
                       category VARCHAR(30) NULL,
                       memo TEXT NULL,
                       status ENUM(
        'TODO', 'VOTING', 'APPROVED', 'REJECTED', 'MISSED'
    ) NOT NULL DEFAULT 'TODO',
                       created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                       updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                           ON UPDATE CURRENT_TIMESTAMP,
                       CONSTRAINT fk_plans_user
                           FOREIGN KEY (user_id) REFERENCES users(id),
                       CONSTRAINT fk_plans_party
                           FOREIGN KEY (party_id) REFERENCES parties(id),
                       INDEX idx_plans_user_date (user_id, plan_date),
                       INDEX idx_plans_party_date (party_id, plan_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. 인증 회차
-- 일정 하나에 인증 회차를 여러 개 등록할 수 있음
CREATE TABLE verifications (
                               id BIGINT PRIMARY KEY AUTO_INCREMENT,
                               plan_id BIGINT NOT NULL,
                               comment TEXT NULL,
                               submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               vote_deadline TIMESTAMP NULL,
                               all_voted_at TIMESTAMP NULL,
                               confirm_at TIMESTAMP NULL,
                               reminded_at TIMESTAMP NULL,
                               finalized_at TIMESTAMP NULL,
                               result ENUM('APPROVED', 'REJECTED') NULL,
                               finalize_reason VARCHAR(100) NULL,
                               voter_count INT NOT NULL DEFAULT 0,
                               approve_count INT NOT NULL DEFAULT 0,
                               reject_count INT NOT NULL DEFAULT 0,
                               CONSTRAINT fk_verifications_plan
                                   FOREIGN KEY (plan_id) REFERENCES plans(id),
                               INDEX idx_verifications_plan (plan_id, submitted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. 인증사진
-- 인증 회차마다 여러 장의 사진을 등록할 수 있음
-- 추가 사진은 기존 인증 회차에 연결하므로 투표가 초기화되지 않음
CREATE TABLE verification_photos (
                                     id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                     verification_id BIGINT NOT NULL,
                                     image_path VARCHAR(500) NOT NULL,
                                     uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                     CONSTRAINT fk_verification_photos_verification
                                         FOREIGN KEY (verification_id) REFERENCES verifications(id),
                                     INDEX idx_verification_photos (verification_id, uploaded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. 인증 투표
-- 한 회원은 인증 회차당 투표 기록 하나를 가짐
-- APPROVE / REJECT 중 선택하고, 변경 시 기존 행을 갱신
CREATE TABLE verification_votes (
                                    verification_id BIGINT NOT NULL,
                                    voter_id BIGINT NOT NULL,
                                    vote ENUM('APPROVE', 'REJECT') NULL,
                                    voted_at TIMESTAMP NULL,
                                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                                        ON UPDATE CURRENT_TIMESTAMP,
                                    change_count INT NOT NULL DEFAULT 0,
                                    is_active BOOLEAN NOT NULL DEFAULT TRUE,
                                    PRIMARY KEY (verification_id, voter_id),
                                    CONSTRAINT fk_votes_verification
                                        FOREIGN KEY (verification_id) REFERENCES verifications(id),
                                    CONSTRAINT fk_votes_voter
                                        FOREIGN KEY (voter_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. 투표 변경 기록
CREATE TABLE vote_logs (
                           id BIGINT PRIMARY KEY AUTO_INCREMENT,
                           verification_id BIGINT NOT NULL,
                           voter_id BIGINT NOT NULL,
                           action ENUM('CAST', 'CHANGE', 'REMOVED') NOT NULL,
                           from_vote ENUM('APPROVE', 'REJECT') NULL,
                           to_vote ENUM('APPROVE', 'REJECT') NULL,
                           created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                           CONSTRAINT fk_vote_logs_verification
                               FOREIGN KEY (verification_id) REFERENCES verifications(id),
                           CONSTRAINT fk_vote_logs_voter
                               FOREIGN KEY (voter_id) REFERENCES users(id),
                           INDEX idx_vote_logs_verification (verification_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. 포인트 지급 기록
-- 일정당 포인트 이벤트는 한 번만 허용
CREATE TABLE point_events (
                              id BIGINT PRIMARY KEY AUTO_INCREMENT,
                              user_id BIGINT NOT NULL,
                              plan_id BIGINT NULL UNIQUE,
                              event_type ENUM(
        'PLAN_APPROVED', 'PLAN_REJECTED', 'ACHIEVEMENT', 'ADJUST'
    ) NOT NULL,
                              points INT NOT NULL,
                              description VARCHAR(255) NULL,
                              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                              CONSTRAINT fk_point_events_user
                                  FOREIGN KEY (user_id) REFERENCES users(id),
                              CONSTRAINT fk_point_events_plan
                                  FOREIGN KEY (plan_id) REFERENCES plans(id),
                              INDEX idx_point_events_user_date (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. 알림
CREATE TABLE notifications (
                               id BIGINT PRIMARY KEY AUTO_INCREMENT,
                               user_id BIGINT NOT NULL,
                               type ENUM(
        'VOTE_REQUEST',
        'VOTE_REMINDER',
        'VOTE_RECEIVED',
        'VERIFY_RESULT',
        'PLAN_MISSED',
        'VERIFICATION_PHOTO_ADDED',
        'WEEKLY_SETTLED',
        'LEVEL_UP',
        'CHARACTER_GROWN',
        'MONTHLY_RANKING',
        'PARTY_JOINED',
        'PARTY_LEFT',
        'ACHIEVEMENT_UNLOCKED'
    ) NOT NULL,
                               title VARCHAR(100) NOT NULL,
                               body VARCHAR(500) NOT NULL,
                               plan_id BIGINT NULL,
                               party_id BIGINT NULL,
                               achievement_code VARCHAR(50) NULL,
                               is_read BOOLEAN NOT NULL DEFAULT FALSE,
                               created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               read_at TIMESTAMP NULL,
                               CONSTRAINT fk_notifications_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               CONSTRAINT fk_notifications_plan
                                   FOREIGN KEY (plan_id) REFERENCES plans(id),
                               CONSTRAINT fk_notifications_party
                                   FOREIGN KEY (party_id) REFERENCES parties(id),
                               INDEX idx_notifications_user_read (user_id, is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. 푸시 알림용 기기 토큰
CREATE TABLE device_tokens (
                               id BIGINT PRIMARY KEY AUTO_INCREMENT,
                               user_id BIGINT NOT NULL,
                               fcm_token VARCHAR(500) NOT NULL UNIQUE,
                               created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                                   ON UPDATE CURRENT_TIMESTAMP,
                               CONSTRAINT fk_device_tokens_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               INDEX idx_device_tokens_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- PLAN:ON V2: 주간 결산과 경험치 장부
-- V1 은 이미 적용된 DB가 있으므로 수정하지 않고, 필요한 테이블만 추가합니다.

-- 12. 주간 결산 실행 기록 (파티·주마다 한 번)
CREATE TABLE weekly_settlements (
                                    id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                    party_id BIGINT NOT NULL,
                                    week_start DATE NOT NULL,
                                    settled_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                    CONSTRAINT fk_weekly_settlements_party
                                        FOREIGN KEY (party_id) REFERENCES parties(id),
                                    UNIQUE KEY uq_weekly_settlement (party_id, week_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. 주간 순위와 경험치 근거
CREATE TABLE weekly_results (
                                settlement_id BIGINT NOT NULL,
                                user_id BIGINT NOT NULL,
                                `rank` INT NOT NULL,
                                points INT NOT NULL,
                                done_count INT NOT NULL,
                                plan_count INT NOT NULL,
                                review_ok BOOLEAN NOT NULL,
                                party_goal_ok BOOLEAN NOT NULL,
                                exp_total INT NOT NULL,
                                PRIMARY KEY (settlement_id, user_id),
                                CONSTRAINT fk_weekly_results_settlement
                                    FOREIGN KEY (settlement_id) REFERENCES weekly_settlements(id),
                                CONSTRAINT fk_weekly_results_user
                                    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. 경험치 장부
-- users.total_exp / users.level 은 이 표의 합계로 계산한 캐시입니다.
-- 경험치는 반드시 이 표에 한 줄을 쓰는 같은 트랜잭션 안에서만 users 를 갱신합니다.
CREATE TABLE exp_events (
                            id BIGINT PRIMARY KEY AUTO_INCREMENT,
                            user_id BIGINT NOT NULL,
                            settlement_id BIGINT NULL,
                            source ENUM(
        'WEEKLY_RANK', 'WEEKLY_COMPLETION', 'WEEKLY_REVIEW', 'PARTY_GOAL', 'ADJUST'
    ) NOT NULL,
                            amount INT NOT NULL,
                            level_before INT NOT NULL,
                            level_after INT NOT NULL,
                            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                            CONSTRAINT fk_exp_events_user
                                FOREIGN KEY (user_id) REFERENCES users(id),
                            CONSTRAINT fk_exp_events_settlement
                                FOREIGN KEY (settlement_id) REFERENCES weekly_settlements(id),
                            UNIQUE KEY uq_exp_settlement_source (user_id, settlement_id, source),
                            INDEX idx_exp_events_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 자정 확정 스케줄러가 "아직 확정 안 됐고 마감이 지난 인증"을 빨리 찾도록
CREATE INDEX idx_verifications_due ON verifications (finalized_at, vote_deadline);
CREATE INDEX idx_plans_status_date ON plans (status, plan_date);


-- PLAN:ON V3: 업적 · 하루 기록 · 연속 기록 · 월간 랭킹 확정본
-- V1, V2 는 그대로 두고 필요한 테이블만 추가합니다. 서버를 켜면 Flyway 가 자동으로 적용합니다.

-- 15. 사람별 하루 결과
-- result: NONE(일정 없음) · PENDING(확정 안 된 일정 있음) · CLEAR(3개 이상 전부 인정)
--         · SHORT(1~2개 전부 인정) · FAIL(미인정·미인증이 하나라도 있음)
CREATE TABLE daily_records (
                               user_id BIGINT NOT NULL,
                               record_date DATE NOT NULL,
                               party_id BIGINT NULL,
                               plan_count TINYINT NOT NULL DEFAULT 0,
                               approved_count TINYINT NOT NULL DEFAULT 0,
                               rejected_count TINYINT NOT NULL DEFAULT 0,
                               missed_count TINYINT NOT NULL DEFAULT 0,
                               pending_count TINYINT NOT NULL DEFAULT 0,
                               result ENUM('NONE', 'PENDING', 'CLEAR', 'SHORT', 'FAIL') NOT NULL,
                               resolved_at TIMESTAMP NULL,
                               PRIMARY KEY (user_id, record_date),
                               CONSTRAINT fk_daily_records_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               INDEX idx_daily_records_party (party_id, record_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 16. 연속 기록 캐시 (daily_records 를 날짜 순서대로 반영한 결과)
CREATE TABLE user_streaks (
                              user_id BIGINT PRIMARY KEY,
                              clear_streak SMALLINT NOT NULL DEFAULT 0,
                              best_clear_streak SMALLINT NOT NULL DEFAULT 0,
                              fail_streak SMALLINT NOT NULL DEFAULT 0,
                              none_streak SMALLINT NOT NULL DEFAULT 0,
                              last_record_date DATE NULL,
                              CONSTRAINT fk_user_streaks_user
                                  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 17. 파티별 하루 결과 (그날 그 파티 소속이었던 사람 기준)
CREATE TABLE party_daily_records (
                                     party_id BIGINT NOT NULL,
                                     record_date DATE NOT NULL,
                                     member_count TINYINT NOT NULL,
                                     clear_count TINYINT NOT NULL,
                                     all_clear BOOLEAN NOT NULL,
                                     party_clear_streak SMALLINT NOT NULL DEFAULT 0,
                                     resolved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                     PRIMARY KEY (party_id, record_date),
                                     CONSTRAINT fk_party_daily_records_party
                                         FOREIGN KEY (party_id) REFERENCES parties(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 18. 업적 목록
CREATE TABLE achievements (
                              code VARCHAR(30) PRIMARY KEY,
                              name VARCHAR(20) NOT NULL,
                              description VARCHAR(100) NOT NULL,
                              category ENUM('STREAK', 'PARTY', 'FUN', 'MONTHLY') NOT NULL,
                              threshold INT NULL,
                              reward_points INT NOT NULL DEFAULT 0,
                              is_hidden BOOLEAN NOT NULL DEFAULT FALSE,
                              sort_order TINYINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 19. 받은 업적 (받을 때마다 한 줄. 보상 포인트는 처음 한 번만)
CREATE TABLE user_achievements (
                                   id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                   user_id BIGINT NOT NULL,
                                   achievement_code VARCHAR(30) NOT NULL,
                                   party_id BIGINT NULL,
                                   period_key VARCHAR(10) NOT NULL,
                                   achieved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                   point_event_id BIGINT NULL,
                                   CONSTRAINT fk_user_achievements_user
                                       FOREIGN KEY (user_id) REFERENCES users(id),
                                   CONSTRAINT fk_user_achievements_code
                                       FOREIGN KEY (achievement_code) REFERENCES achievements(code),
                                   UNIQUE KEY uq_user_achievement_period (user_id, achievement_code, period_key),
                                   INDEX idx_user_achievements_user (user_id, achieved_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 20. 월간 랭킹 확정본 (매월 1일에 지난달을 고정)
CREATE TABLE monthly_rankings (
                                  party_id BIGINT NOT NULL,
                                  month_start DATE NOT NULL,
                                  user_id BIGINT NOT NULL,
                                  `rank` TINYINT NOT NULL,
                                  points INT NOT NULL,
                                  done_count SMALLINT NOT NULL,
                                  exp_earned INT NOT NULL DEFAULT 0,
                                  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                  PRIMARY KEY (party_id, month_start, user_id),
                                  CONSTRAINT fk_monthly_rankings_party
                                      FOREIGN KEY (party_id) REFERENCES parties(id),
                                  CONSTRAINT fk_monthly_rankings_user
                                      FOREIGN KEY (user_id) REFERENCES users(id),
                                  INDEX idx_monthly_rankings_first (user_id, `rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 업적 보상 포인트를 어떤 업적에서 받았는지 연결 (업적당 한 번만)
ALTER TABLE point_events
    ADD COLUMN user_achievement_id BIGINT NULL,
    ADD CONSTRAINT uq_point_events_achievement UNIQUE (user_achievement_id),
    ADD CONSTRAINT fk_point_events_achievement
        FOREIGN KEY (user_achievement_id) REFERENCES user_achievements(id);

ALTER TABLE user_achievements
    ADD CONSTRAINT fk_user_achievements_point
        FOREIGN KEY (point_event_id) REFERENCES point_events(id);

-- 업적 13개 (보상 포인트·기준값은 여기서 바꾸면 코드 수정 없이 반영)
INSERT INTO achievements (code, name, description, category, threshold, reward_points, is_hidden, sort_order) VALUES
    ('STREAK_3',        '삼일천하',       '3일 연속 계획 올클',                                 'STREAK',  3,   15,  FALSE, 1),
    ('STREAK_7',        '칠일무패',       '7일 연속 계획 올클',                                 'STREAK',  7,   40,  FALSE, 2),
    ('STREAK_30',       '철의 의지',      '30일 연속 계획 올클',                                'STREAK',  30,  150, FALSE, 3),
    ('PARTY_CLEAR_1',   '환상의 팀워크',  '파티원 전원이 같은 날 계획 올클 (2명 이상)',           'PARTY',   1,   20,  FALSE, 4),
    ('PARTY_STREAK_7',  '전설의 파티',    '파티원 전원 올클 7일 연속',                          'PARTY',   7,   60,  FALSE, 5),
    ('WEEKEND_CLEAR',   '휴일 반납',      '같은 주말 토요일·일요일 모두 올클',                    'FUN',     NULL, 0,  FALSE, 6),
    ('STREAK_BROKEN',   '작심삼일',       '3일 이상 이어진 올클이 끊김',                         'FUN',     3,   0,   TRUE,  7),
    ('IDLE_7',          '잠수 전문가',    '7일 연속 계획을 하나도 등록하지 않음',                  'FUN',     7,   0,   TRUE,  8),
    ('FAIL_7',          '내일부터는 진짜', '7일 연속 계획 올클 실패',                            'FUN',     7,   0,   TRUE,  9),
    ('LAST_MINUTE',     '벼락치기의 미학', '사진 마감 10분 전(23:20~23:29)에 제출하고 인정받음',    'FUN',     NULL, 0,  TRUE,  10),
    ('MONTH_END_SPURT', '막판 스퍼트',    '한 달의 마지막 3일 동안 150P 이상',                   'MONTHLY', 150, 0,   FALSE, 11),
    ('THRONE_FIRST',    '왕좌의 주인',    '파티 월간 랭킹 1위를 처음 차지',                       'MONTHLY', NULL, 0,  FALSE, 12),
    ('THRONE_USURPER',  '왕좌 찬탈자',    '두 달 연속 1위였던 파티원을 끌어내리고 1위',             'MONTHLY', 2,   0,   FALSE, 13);


-- PLAN:ON V4: 기기에 저장한 계정으로 바로 로그인 (카카오 "간편로그인 계정 선택" 방식)
-- 토큰 원문은 휴대폰에만 있고, 서버에는 SHA-256 해시만 저장합니다.

CREATE TABLE remember_tokens (
                                 id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                 user_id BIGINT NOT NULL,
                                 token_hash CHAR(64) NOT NULL,
                                 device_name VARCHAR(100) NULL,
                                 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                 last_used_at TIMESTAMP NULL,
                                 expires_at TIMESTAMP NOT NULL,
                                 revoked_at TIMESTAMP NULL,
                                 CONSTRAINT fk_remember_tokens_user
                                     FOREIGN KEY (user_id) REFERENCES users(id),
                                 UNIQUE KEY uq_remember_tokens_hash (token_hash),
                                 INDEX idx_remember_tokens_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
