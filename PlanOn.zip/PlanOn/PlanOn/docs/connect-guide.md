# 앱 ↔ 서버 연결 가이드

## 1. 서버 켜기 (PC)

1. MySQL 에 DB와 계정 준비 (이미 했다면 건너뛰기)
   ```sql
   CREATE DATABASE planon_db DEFAULT CHARACTER SET utf8mb4;
   CREATE USER 'planon'@'localhost' IDENTIFIED BY 'wldms';
   GRANT ALL PRIVILEGES ON planon_db.* TO 'planon'@'localhost';
   ```
2. IntelliJ 에서 `server` 프로젝트 열기 → `ServerApplication` 실행
   - 처음 실행 때 Flyway 가 V2(주간 결산·경험치 장부 테이블)를 자동으로 추가합니다. V1 은 건드리지 않습니다.
   - 로그에 `Tomcat started on port 8080` 이 보이면 성공
3. PC 브라우저에서 `http://localhost:8080/api/health` → `{"status":"ok"}`

## 2. 앱에서 연결

| 실행 환경 | 서버 주소 |
|---|---|
| Android Studio 에뮬레이터 | `http://10.0.2.2:8080/` (기본값, 그대로 두면 됨) |
| 실제 휴대폰 | `http://<PC의 IP>:8080/` — PC와 **같은 Wi-Fi** 필수 |

- PC IP 확인: Windows `cmd` → `ipconfig` → "무선 LAN 어댑터 Wi-Fi" 의 **IPv4 주소** (예: 192.168.0.10)
- 앱 로그인 화면 맨 아래 **서버: … (변경 · 연결 확인)** 버튼 → 주소 입력 → **연결 확인** → 성공하면 **저장**
  (앱을 다시 빌드할 필요 없음. 기본값을 바꾸려면 `AppConfig.BASE_URL`)

## 3. 연결이 안 될 때

| 증상 | 원인과 해결 |
|---|---|
| "서버(…)에 연결할 수 없어요" (실제 휴대폰) | **Windows 방화벽**이 8080을 막는 경우가 대부분. 관리자 PowerShell 에서<br>`New-NetFirewallRule -DisplayName "PLANON 8080" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow`<br>또는 제어판 › Windows Defender 방화벽 › 고급 설정 › 인바운드 규칙 › 새 규칙 › 포트 TCP 8080 허용. 네트워크 프로필이 "공용"이면 "개인"으로 바꾸기 |
| 휴대폰 브라우저에서 `http://PC-IP:8080/api/health` 도 안 열림 | 같은 Wi-Fi 인지 확인 (학교·카페 Wi-Fi 는 기기끼리 통신을 막기도 함 → 휴대폰 핫스팟에 PC 를 연결해서 시험) |
| 에뮬레이터만 안 됨 | 주소가 `10.0.2.2` 인지 확인 (`localhost` 는 에뮬레이터 자신을 가리킴) |
| 로그인하면 바로 "로그인이 만료되었어요" | 서버의 `planon.token.secret` 을 바꿨거나 서버 DB 를 새로 만든 경우 → 다시 로그인 |
| 아이디/비밀번호가 맞는데 로그인 실패 | 예전 서버로 만든 계정도 그대로 됩니다(BCrypt). 비밀번호 규칙은 회원가입에만 적용 |
| 사진이 안 보임 | 서버 실행 폴더의 `uploads/` 에 파일이 있는지, 앱의 서버 주소가 맞는지 확인 |
| 서버 시작 때 Flyway 오류 "checksum mismatch" | V1__init.sql 을 수정한 경우. 원래대로 되돌리고, 바꿀 내용은 V3 파일로 추가 |
| 서버 시작 때 "Found non-empty schema … without schema history" | `application.properties` 의 `spring.flyway.baseline-on-migrate=true` 가 있는지 확인 (V1 을 손으로 만든 DB 용) |

이전 서버가 막혔던 이유: 앱은 `/api/auth/login` 에서 `{token, user}` 를 기대하는데 서버에는 `/api/users/login` 만 있었고 응답 형식도 달랐으며,
비밀번호 오류를 401 로 돌려줘 앱이 "로그인 만료"로 처리했습니다. 또 파티·일정·인증·랭킹 API 가 없었습니다. 지금은 모두 맞춰져 있습니다.

## 4. 푸시 알림 (선택)

설정하지 않아도 **알림함은 항상 동작**하고, 앱이 15분마다 새 알림을 확인해 휴대폰 알림으로 띄웁니다.
바로바로 푸시를 받으려면 Firebase 를 연결하세요.

1. https://console.firebase.google.com → 프로젝트 만들기 → Android 앱 추가 (패키지 이름 `com.planon.app`)
2. **앱**: 받은 `google-services.json` 의 값을 `app/src/main/res/values/firebase.xml` 에 옮겨 적기
   (`firebase_app_id`, `firebase_api_key`, `firebase_project_id`, `firebase_sender_id` — 파일 안에 위치 설명 있음)
3. **서버**: Firebase 콘솔 › 프로젝트 설정 › 서비스 계정 › **새 비공개 키 생성** → JSON 파일을 서버 폴더에 두고
   ```properties
   planon.fcm.credentials-file=firebase-service-account.json
   planon.fcm.project-id=<프로젝트 ID>
   ```
   (이 파일은 비밀 키라 `.gitignore` 에 넣어 두었습니다. Git 에 올리지 마세요)
4. 앱을 다시 설치 → 로그인 → 알림 권한 허용. 다른 계정으로 미인정을 눌러 푸시가 오는지 확인

## 5. 흐름 빠르게 시험하기 (IntelliJ `test-api.http`)

`server/test-api.http` 에 회원가입 → 로그인 → 파티 → 일정 → 인증(사진) → 투표 → 순위 순서의 요청이 있습니다.
로그인 응답의 `token` 을 파일 맨 위 `@token` 에 붙여 넣고 차례로 실행하세요.
자정 확정을 바로 보고 싶으면 DB 에서 그 인증의 `vote_deadline` 을 과거로 바꾼 뒤 서버를 재시작하면 시작 시점에 확정됩니다.
