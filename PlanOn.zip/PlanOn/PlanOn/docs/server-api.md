# PLAN:ON 서버 API

- 주소: `http://<PC-IP>:8080/` (에뮬레이터는 `http://10.0.2.2:8080/`)
- 로그인 후 모든 요청에 `Authorization: Bearer {token}` 헤더 (토큰 유효기간 14일)
- 오류는 항상 `{"message": "화면에 보여줄 문구"}`
  - `400` 입력·규칙 위반 (아이디/비밀번호 틀림 포함) · `401` 토큰 없음/만료 (앱이 로그인 화면으로) · `403` 권한 없음 · `404` 없음 · `409` 중복·상태 충돌 · `413` 사진 용량 초과
- 시간은 모두 한국 시간, `yyyy-MM-dd'T'HH:mm` 형식

## 회원 (로그인 불필요)

| 메서드 | 경로 | 요청 | 응답 |
|---|---|---|---|
| GET | `/api/health` | | `{"status":"ok"}` |
| GET | `/api/auth/check-id?loginId=` | | `{"available": true}` |
| POST | `/api/auth/signup` (예전 주소 `/api/users/signup` 도 가능) | `{loginId, password, nickname}` | `201` User |
| POST | `/api/auth/login` (예전 주소 `/api/users/login` 도 가능) | `{loginId, password, remember, deviceName}` | `{token, user, rememberToken}` |
| POST | `/api/auth/quick-login` | `{rememberToken}` | `{token, user, rememberToken}` · 만료·폐기면 `401` |
| POST | `/api/auth/forget` | `{rememberToken}` | `200` (서버의 저장 로그인 폐기) |

- **최근 로그인 계정**: `remember: true` 로 로그인하면 `rememberToken`(32바이트 난수)을 줌. 앱은 계정 목록과 함께 기기에 저장하고,
  목록에서 계정을 누르면 `quick-login` 으로 비밀번호 없이 로그인. 서버에는 SHA-256 해시만 저장(`remember_tokens`),
  마지막 사용일부터 60일 유효, 한 사람당 최근 10개까지. 로그아웃해도 목록은 남고, 목록에서 지우면 `forget` 으로 폐기
- 아이디: 영문·숫자 4~16자 · 비밀번호: 영문+숫자 8자 이상 · 닉네임: 1~10자

## 내 정보

| GET | `/api/users/me` | | User |
|---|---|---|---|

User: `id, loginId, nickname, partyId(없으면 0), partyName, characterId(0=미선택), totalExp, level, expInLevel, expForNext, stage, weeklyPoints, totalPoints, weeklyRank`

## 파티 (한 사람은 파티 하나만, 최대 4명)

| 메서드 | 경로 | 요청 | 응답 |
|---|---|---|---|
| POST | `/api/parties` | `{name}` | `201` Party |
| POST | `/api/parties/join` | `{inviteCode}` | Party |
| GET | `/api/parties/my` | | Party, 없으면 `204` |
| DELETE | `/api/parties/my/members/me` | | `200` (확정 전 인증의 내 투표권 회수, 파티장은 다음 사람에게) |
| PUT | `/api/parties/my/character` | `{characterId: 1~4}` | `200`, 이미 고른 캐릭터면 `409` |

Party: `id, name, inviteCode, leaderId, members[ {userId, nickname, characterId, totalExp, leader, todayTotal, todayDone} ]`
(`todayDone` = 오늘 인증을 제출한 일정 수)

## 일정

| 메서드 | 경로 | 요청 | 응답 |
|---|---|---|---|
| GET | `/api/plans?userId=&date=yyyy-MM-dd` | | Plan[] (다른 파티원은 오늘 것만, 아니면 `403`) |
| GET | `/api/plans/dates?yearMonth=2026-10` | | `["2026-10-01", …]` 내 일정이 있는 날 |
| POST | `/api/plans` | `{date, title, time("09:30"·선택), category, memo}` | `201` Plan |
| DELETE | `/api/plans/{id}` | | 인증 전(TODO)만 |

- 날짜: 오늘 ~ 30일 뒤, 하루 10개, 오늘 일정은 23:30 전까지만 추가

## 인증 · 투표

| 메서드 | 경로 | 요청 | 응답 |
|---|---|---|---|
| POST | `/api/plans/{id}/verification` | multipart: `images` 1~5개 + `comment` | Plan |
| POST | `/api/plans/{id}/verification/photos` | multipart: `images` (합계 10장까지) | Plan |
| DELETE | `/api/plans/{id}/verification/photos/{photoId}` | | Plan |
| POST | `/api/plans/{id}/verification/photos/{photoId}/replace` | multipart: `image` 한 장 | Plan |
| GET | `/api/plans/{id}/verification` | | Plan (`votes` 포함) |
| POST | `/api/plans/{id}/votes` | `{approve: true/false}` | Plan |

규칙
- 제출·사진 추가: 일정 **당일 23:30 까지**. 사진을 추가해도 이미 받은 표는 유지, 투표권자에게 `VERIFICATION_PHOTO_ADDED` 알림
- 사진 바꾸기·지우기: **사진마다 올린 뒤 10분 안**에만, 본인만, 투표 중일 때만. 마지막 1장은 지울 수 없고 바꾸기만 가능.
  바꿔도 수정 가능 시간은 처음 올린 시각 기준 그대로(연장 없음). 이미 받은 표는 유지, 바꾸면 투표권자에게 알림
- 투표권: **제출하는 순간의 파티원(본인 제외)**. 그 뒤 들어온 사람은 투표 불가, 나간 사람의 표는 빠짐
- 투표·변경: **자정(다음 날 00:00) 까지**, 본인 투표 불가, 마감 뒤 변경 불가. 미인정을 누를 때마다 본인에게 `VOTE_RECEIVED` 푸시
- 자정 00:00:05 에 확정: **미인정 > 인정 → REJECTED(−10P)**, 같거나 적으면 APPROVED(+10P), 투표 안 한 사람은 세지 않음
- 인증 안 한 지난 일정 → MISSED(0P). 포인트는 일정당 한 번 (`point_events.plan_id` UNIQUE)

Plan:
```
id, userId, ownerNickname, ownerCharacterId, ownerStage(1~5), date, title, time, category, memo,
status: TODO | VOTING | APPROVED | REJECTED | MISSED,
imageUrls["/uploads/2026/10/…jpg"], photos[ {id, url, uploadedAt, editableUntil, editable} ], comment, submittedAt, photoDeadline, voteDeadline, finalized,
approveCount, rejectCount,      ← 확정 뒤 공개 (본인에게는 투표 중에도 rejectCount 를 보여줌)
votedCount, voterCount, myVote(1/-1/0),
canSubmit, canAddPhotos, canVote,
votes[ {userId, nickname, voted, vote} ]   ← 확정 전에는 남의 vote 는 0 (투표 여부만)
```

## 랭킹

| GET | `/api/rankings/weekly?week=current\|last` | RankingResult |
|---|---|---|
| GET | `/api/rankings/monthly?month=current\|last` | RankingResult |

RankingResult: `period(WEEK_CURRENT…), weekStart, weekEnd, settled, entries[ {rank, userId, nickname, characterId, totalExp, points, doneCount, exp} ]`
- 이번 주: 실시간, `exp` = 지금 끝나면 받을 예상 경험치 · 지난주: 결산 기록(결산 전이면 실시간)
- 월간: 그 달 일정 날짜 기준 포인트 합계, `exp` = 그 달 결산으로 받은 경험치
- 같은 포인트·같은 인정 수는 같은 순위 (1, 1, 3 …)

## 주간 결산 (월요일 00:00:05, 파티·주마다 한 번)

| 경로 | 경험치 |
|---|---|
| 순위 | 1위 60 · 2위 45 · 3위 35 · 4위 25 (혼자인 파티 35) |
| 달성률 (인정 ÷ 확정된 일정) | 100% 25 · 80% 15 · 50% 5 |
| 검토 참여 (받은 투표 요청에 모두 투표) | 15 |
| 파티 목표 (파티 전체 인정률 70% 이상) | 10 |

주간 포인트가 0 이하이면 모두 0. 지급은 `exp_events` 에 한 줄씩 쓰고 같은 트랜잭션에서 `users.total_exp/level` 갱신.

## 업적

| GET | `/api/achievements` | AchievementsResponse |
|---|---|---|

AchievementsResponse: `clearStreak, bestClearStreak, earnedCount, totalCount, items[ {code, name, description, category(STREAK·PARTY·FUN·MONTHLY), rewardPoints, hidden, earned, count, firstAchievedAt} ]`
- 받기 전 숨김 업적은 `name = "???"`
- 판정은 매시 0분 5초 작업에서: 어제까지의 하루 결과(daily_records) → 연속 기록(user_streaks) → 파티 하루 결과 → 업적
- 올클 = 그날 일정 **3개 이상 전부 인정**. 1~2개 전부 인정은 SHORT(연속 기록 모두 0)
- 보상 포인트는 그 업적을 **처음** 받을 때만 (`point_events.event_type = ACHIEVEMENT`), 배지·횟수는 계속 쌓임
- 월간 업적(막판 스퍼트·왕좌 2종)은 매월 1일 지난달 순위를 `monthly_rankings` 에 고정할 때 판정. 지난달 랭킹은 이 확정본을 보여줌

| 업적 | 조건 | 보상 |
|---|---|---|
| 삼일천하 / 칠일무패 / 철의 의지 | 연속 올클 3 / 7 / 30일 | 15 / 40 / 150P |
| 환상의 팀워크 | 파티원 2명 이상, 전원 같은 날 올클 | 20P (각자) |
| 전설의 파티 | 전원 올클 7일 연속 | 60P (각자) |
| 휴일 반납 | 같은 주말 토·일 모두 올클 | — |
| 작심삼일 (숨김) | 3일 이상 올클 뒤 FAIL | — |
| 잠수 전문가 (숨김) | 7일 연속 일정 없음 | — |
| 내일부터는 진짜 (숨김) | 7일 연속 FAIL | — |
| 벼락치기의 미학 (숨김) | 23:20~23:29 에 제출하고 인정 | — |
| 막판 스퍼트 | 그 달 마지막 3일 150P 이상 | — |
| 왕좌의 주인 | 파티 월간 1위를 처음 차지 (포인트 0보다 클 때) | — |
| 왕좌 찬탈자 | 앞 두 달 같은 사람이 단독 1위였는데 이번 달 다른 사람이 1위 | — |

보상·기준값은 `achievements` 테이블 값을 바꾸면 코드 수정 없이 반영됩니다.

## 알림

| 메서드 | 경로 | 요청 | 응답 |
|---|---|---|---|
| GET | `/api/notifications?limit=50` | | `[ {id, type, title, body, planId, read, createdAt} ]` |
| GET | `/api/notifications/unread-count` | | `{count}` |
| PATCH | `/api/notifications/{id}/read` | | |
| PATCH | `/api/notifications/read-all` | | |
| PUT | `/api/device-tokens` | `{token}` | FCM 토큰 등록 |
| DELETE | `/api/device-tokens?token=` | | 로그아웃 때 |

type: `VOTE_REQUEST, VOTE_REMINDER(23:00), VOTE_RECEIVED, VERIFICATION_PHOTO_ADDED, VERIFY_RESULT, PLAN_MISSED, WEEKLY_SETTLED, LEVEL_UP, CHARACTER_GROWN, MONTHLY_RANKING, ACHIEVEMENT_UNLOCKED, PARTY_JOINED, PARTY_LEFT` (90일 지나면 삭제)

## 사진

`GET /uploads/yyyy/MM/<UUID>.jpg` — 로그인 없이 제공 (추측할 수 없는 파일 이름). 서버 폴더 `uploads/` 에 저장.
