# PLAN:ON — 파티형 계획 인증 앱 (Android / Java)

함께 계획을 세우고, 사진으로 인증하고, 주간 랭킹으로 캐릭터를 키우는 앱입니다.

- 언어: Java 17
- 최소 SDK: API 31 (Android 12) · target/compile SDK 34
- 빌드: Android Gradle Plugin 9.4.1 · Gradle 9.6 (wrapper 포함)
- 데이터: SQLite(휴대폰 내부) · Spring + MySQL(서버, Retrofit으로 통신)

---

## 1. 바로 실행하기

1. Android Studio(Koala 2024.1 이상 권장)에서 **File › Open** → 압축을 푼 `PlanOn` 폴더 선택
2. Gradle Sync가 끝날 때까지 기다리기 (처음엔 라이브러리 다운로드로 몇 분 걸림)
3. API 31 이상 에뮬레이터 또는 휴대폰을 연결하고 ▶ Run

> Sync 중 "Gradle JDK" 오류가 나면: **Settings › Build, Execution, Deployment › Build Tools › Gradle › Gradle JDK** 를 17 이상(Android Studio 내장 JBR)으로 지정하세요.
> Android Studio가 AGP 업그레이드를 제안하면 그대로 진행해도 됩니다.

### 서버와 함께 실행 (기본값)
`AppConfig.USE_REMOTE_SERVER = true` 입니다. PC에서 Spring 서버를 켠 뒤 앱을 실행하세요.
**연결 방법과 막힐 때 확인할 것은 `docs/connect-guide.md`** 에 정리했습니다.
에뮬레이터는 그대로, 실제 휴대폰은 로그인 화면 아래 **서버 주소** 버튼에서 `http://PC의IP:8080/` 로 바꾸면 됩니다.

### 데모로 둘러보기 (서버 없이)
`AppConfig.USE_REMOTE_SERVER = false` 로 바꾸면 모든 데이터가 휴대폰 SQLite에 저장되고, 서버와 같은 규칙으로 동작합니다.

1. 로그인 화면 아래 **데모 데이터 만들기** 버튼
2. `demo1 / demo1234` 로 로그인 → 4명이 있는 파티 "기말고사 정복단"으로 입장
3. 계정을 바꿔가며 테스트 (마이페이지 › 로그아웃 → `demo2`, `demo3`, `demo4`)
   - demo2~4 로 지민(demo1)의 "알고리즘 문제 3개"에 투표, 자정 전까지 바꿔 보기
   - demo2 는 "헬스장 가기"에 미인정 표를 받은 상태 → 검토 화면의 **사진 추가하기**
   - 처음 접속 때 지난주 결산이 실행되어 경험치가 지급되고, **랭킹 › 지난주** 와 알림함에서 볼 수 있음
   - 자정 확정은 다음 날 앱을 열 때 처리됩니다 (서버 모드는 서버가 00:00:05 에 처리)

> 이전 버전에서 데모 데이터를 만들었다면 DB 구조가 바뀌어 처음 실행 때 초기화됩니다. 데모 데이터를 다시 만들어 주세요.

---

## 2. 화면 구성

| 화면 | 클래스 | 레이아웃 |
|---|---|---|
| 로그인 | `ui/auth/LoginActivity` | `activity_login.xml` |
| 회원가입 | `ui/auth/SignUpActivity` | `activity_signup.xml` |
| 파티 만들기 / 초대코드 입력 | `ui/party/PartyJoinActivity` | `activity_party_join.xml` |
| 캐릭터 선택 | `ui/party/CharacterSelectActivity` | `activity_character_select.xml` |
| 하단 메뉴 (홈·랭킹·마이페이지) | `ui/main/MainActivity` | `activity_main.xml` |
| 홈: 캘린더 + 진행도 + 오늘의 계획 | `ui/home/HomeFragment` | `fragment_home.xml` |
| 일정 추가 (바텀시트) | `ui/home/AddPlanBottomSheet` | `bottom_sheet_add_plan.xml` |
| 인증 사진 업로드 | `ui/verify/VerifyUploadActivity` | `activity_verify_upload.xml` |
| 파티원 인증 검토 | `ui/verify/VerifyReviewActivity` | `activity_verify_review.xml` |
| 랭킹 | `ui/ranking/RankingFragment` | `fragment_ranking.xml` |
| 마이페이지 | `ui/mypage/MyPageFragment` | `fragment_mypage.xml` |
| 알림함 | `ui/notification/NotificationActivity` | `activity_notifications.xml` |

## 3. 구현된 규칙 (서버 `common/LevelRule.java`, 앱 `util/LevelRule.java` 에 같은 값)

- **파티**: 최대 4명, **한 사람은 파티 하나만**. 6자리 초대 코드로 가입. 파티장이 나가면 가장 먼저 들어온 사람이 파티장.
- **캐릭터**: 4종 중 1개. 같은 파티에서 다른 사람이 먼저 고른 캐릭터는 선택 불가.
- **일정**: 오늘 ~ 30일 뒤, 하루 10개까지. 오늘 일정은 23:30 전까지만 추가. 팀원 일정은 **당일 것만** 열람.
- **진행도(홈)**: 오늘 일정 중 **인증을 제출한** 비율. 결과는 자정에 확정.
- **인증**: 일정 당일 **23:30 까지** 사진 1~5장 + 코멘트 제출. 23:30 전이면 **사진 추가**(합계 10장)도 가능하고, 이미 받은 표는 유지.
- **투표**: 제출하는 순간의 파티원(본인 제외)에게 투표권. **본인은 투표 불가**, **자정(24:00)까지 투표·변경 가능**, 마감 뒤 변경 불가.
  - 누군가 **미인정을 누를 때마다** 인증한 사람에게 푸시 (누가 눌렀는지는 비공개) → 23:30 전이면 사진을 보탤 수 있음
  - 확정 전에는 다른 사람의 표 내용은 숨기고 "투표함/대기"만 표시
- **자정 확정**: 표를 합산해 **미인정 > 인정 → 미수행(−10P)**, **같거나 적으면 인정(+10P)**. 투표 안 한 사람은 세지 않음.
  인증하지 않은 일정은 **미인증(0P)**. 포인트는 **일정당 한 번만** 지급.
- **경험치(월요일 결산에서만)**: 순위 60/45/35/25 (혼자면 35) + 달성률 100%·80%·50% → 25/15/5 + 받은 투표 요청에 모두 투표 15
  + 파티 전체 인정률 70% 이상 10. **주간 포인트가 0 이하이면 경험치 0**.
- **레벨**: Lv.L → L+1 에 `15 + 2×(L−1)` EXP (Lv.1→2 는 15, Lv.2→3 은 17 …), 최대 Lv.50, 10레벨마다 캐릭터 성장(1~5단계).
- **랭킹**: 이번 주(실시간·예상 경험치) / 지난주(결산 기록) / 이번 달 / 지난달(일정 날짜 기준 포인트 합계).
- **최근 로그인 계정**: 로그인할 때 "이 기기에 로그인 정보 저장"(기본 체크)을 켜 두면, 다음부터 로그인 화면에 계정 목록(최근 5개)이 보이고
  누르기만 하면 로그인돼요. ✕ 로 목록에서 지울 수 있고, 로그아웃해도 목록은 남아요. 서버 주소별로 따로 저장돼요.
- **인증 사진 수정**: 사진마다 올린 뒤 10분 안에만 바꾸거나 지울 수 있어요 (마지막 1장은 바꾸기만). 업로드 화면과 검토 화면에 안내 문구가 있어요.
- **업적**: 13개 (연속 올클·파티·재미·월간). 올클 = 하루 일정 3개 이상 전부 인정. 보상 포인트는 처음 한 번만. 마이페이지에서 확인.
  로컬 데모 모드에서는 목록과 연속 올클 업적만 판정합니다 (전체 판정은 서버).
- **캐릭터**: 1 블루 · 2 그린 · 3 레드 · 4 옐로, 레벨 10마다 5단계로 성장 (알 → … → 천사).
  `res/drawable-nodpi/char_{번호}_s{단계}.png`(원본, 마이페이지)와 `_face.png`(얼굴 확대, 랭킹·진행도 등 작은 아바타)
- **알림함**: 홈 오른쪽 위 종 아이콘. 휴대폰 알림은 Firebase(FCM)를 설정하면 즉시, 설정하지 않으면 15분마다 확인해 표시.

## 4. 프로젝트 구조

```
app/src/main/java/com/planon/app/
├─ AppConfig.java          ← 로컬/서버 모드, 서버 주소
├─ data/
│  ├─ Repository.java      ← 화면이 쓰는 데이터 인터페이스
│  ├─ local/               ← SQLite (DbHelper, LocalRepository, DemoSeeder)
│  └─ remote/              ← Spring 서버 통신 (Retrofit: ApiService, RemoteRepository)
├─ model/                  ← User, Party, Member, Plan, RankEntry, AppNotification ...
├─ push/                   ← 푸시 알림 (FCM, 알림함 주기 확인)
├─ ui/                     ← 화면 (Activity / Fragment / Adapter)
└─ util/                   ← LevelRule(규칙), DateUtil, Characters(캐릭터 이미지), Async
```

화면은 `Repository` 인터페이스만 사용하므로, 서버 모드로 바꿔도 화면 코드는 그대로입니다.

## 5. Spring 서버와 연결하기

- 서버 코드: `server` 프로젝트 (Spring Boot + JdbcTemplate + Flyway + MySQL)
- API 목록: `docs/server-api.md` · 연결 방법·문제 해결: `docs/connect-guide.md` · 테이블: 서버의 `db/migration/V1__init.sql`, `V2__settlement_and_exp.sql`
- 서버 모드에서도 로그인 토큰은 SQLite `session` 테이블에 저장되어 앱을 다시 켜면 자동 로그인됩니다.
- 화면 추가: 알림함 `ui/notification/NotificationActivity`, 푸시 `push/` (PushSetup · PlanOnMessagingService · NotificationPollWorker)

## 6. 캐릭터 이미지 교체

지금은 `res/drawable/char_1.xml ~ char_4.xml` 임시 그림이 들어 있습니다.

- 같은 이름의 PNG(`char_1.png` 등)를 `res/drawable` 에 넣고 xml 파일을 지우면 바로 교체됩니다.
- 성장 단계별 그림을 쓰려면 `char_1_s1.png ~ char_1_s5.png` 처럼 넣고 `util/Characters.java` 의 `IMAGES` 표를 수정하세요.

## 7. Git 협업

`.gitignore` 가 포함되어 있습니다. 첫 업로드 예시:

```bash
git init
git add .
git commit -m "PLAN:ON 초기 프로젝트"
git branch -M main
git remote add origin https://github.com/<팀계정>/PlanOn.git
git push -u origin main
```

기능별로 `feature/home-calendar`, `feature/ranking` 같은 브랜치를 만들어 작업한 뒤 Pull Request로 합치면 충돌이 줄어듭니다.
