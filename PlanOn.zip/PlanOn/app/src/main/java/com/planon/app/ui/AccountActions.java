package com.planon.app.ui;

import android.app.Activity;
import android.text.InputType;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.planon.app.data.Repository;
import com.planon.app.data.RepositoryProvider;
import com.planon.app.ui.party.PartyJoinActivity;
import com.planon.app.util.Async;

/** 마이페이지·파티 참여 화면에서 함께 쓰는 "파티 삭제", "회원 탈퇴" 확인 창 */
public final class AccountActions {
    private AccountActions() {
    }

    /** 파티 삭제 (파티장만). 끝나면 파티 참여 화면으로 */
    public static void confirmDeleteParty(Activity activity, String partyName) {
        Repository repo = RepositoryProvider.get();
        new MaterialAlertDialogBuilder(activity)
                .setTitle("파티 삭제")
                .setMessage("'" + partyName + "' 파티를 삭제할까요?\n\n"
                        + "· 파티원 모두 파티에서 빠지고, 각자 이 파티에서 만든 앞으로의 일정은 지워져요.\n"
                        + "· 오늘 이미 제출한 인증은 자정에 원래대로 확정돼요.\n"
                        + "· 레벨·경험치·업적은 각자 그대로 남아요.\n"
                        + "· 삭제한 파티는 되돌릴 수 없어요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제", (d, w) -> Async.run(() -> {
                    repo.deleteParty();
                    return true;
                }, ok -> {
                    Toast.makeText(activity, "파티를 삭제했어요", Toast.LENGTH_SHORT).show();
                    Router.go(activity, PartyJoinActivity.class);
                }, msg -> Toast.makeText(activity, msg, Toast.LENGTH_LONG).show()))
                .show();
    }

    /** 회원 탈퇴: 안내 → 비밀번호 확인 → 로그인 화면으로 */
    public static void confirmWithdraw(Activity activity) {
        new MaterialAlertDialogBuilder(activity)
                .setTitle("회원 탈퇴")
                .setMessage("탈퇴하면 이 계정으로 다시 로그인할 수 없어요.\n\n"
                        + "· 파티에서 나가지고, 파티장이면 다음 파티원에게 넘어가요.\n"
                        + "· 앞으로의 일정, 인증 사진, 알림이 삭제돼요.\n"
                        + "· 지난 순위·투표 기록은 다른 파티원을 위해 '탈퇴한 회원'으로 남아요.\n"
                        + "· 같은 아이디로 다시 가입할 수 있어요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("계속", (d, w) -> askPassword(activity))
                .show();
    }

    private static void askPassword(Activity activity) {
        Repository repo = RepositoryProvider.get();
        EditText input = new EditText(activity);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint("비밀번호");
        FrameLayout box = new FrameLayout(activity);
        int pad = Math.round(20 * activity.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);
        new MaterialAlertDialogBuilder(activity)
                .setTitle("비밀번호 확인")
                .setMessage("탈퇴하려면 비밀번호를 입력해 주세요.")
                .setView(box)
                .setNegativeButton("취소", null)
                .setPositiveButton("탈퇴하기", (d, w) -> {
                    String pw = input.getText().toString();
                    Async.run(() -> {
                        repo.withdraw(pw);
                        return true;
                    }, ok -> {
                        Toast.makeText(activity, "탈퇴했어요. 그동안 이용해 주셔서 고마워요", Toast.LENGTH_LONG).show();
                        Router.toLogin(activity);
                    }, msg -> Toast.makeText(activity, msg, Toast.LENGTH_LONG).show());
                })
                .show();
    }
}
