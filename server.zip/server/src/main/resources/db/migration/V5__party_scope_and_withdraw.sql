-- PLAN:ON V5: 파티 삭제 · 파티별 기록 분리 · 알림 30개 제한 · 회원 탈퇴

-- 1) 파티 삭제: 기록(일정·포인트·알림)이 참조하므로 행은 남기고 삭제 표시만
ALTER TABLE parties
    ADD COLUMN deleted_at TIMESTAMP NULL;

-- 2) 포인트를 어느 파티에서 얻었는지 기록 → 새 파티의 순위에는 그 파티에서 얻은 포인트만
ALTER TABLE point_events
    ADD COLUMN party_id BIGINT NULL,
    ADD CONSTRAINT fk_point_events_party FOREIGN KEY (party_id) REFERENCES parties(id),
    ADD INDEX idx_point_events_party_user (party_id, user_id);

-- 기존 기록 채우기: 일정 포인트는 그 일정의 파티, 업적 포인트는 받을 당시 파티
UPDATE point_events pe JOIN plans pl ON pl.id = pe.plan_id
SET pe.party_id = pl.party_id;
UPDATE point_events pe JOIN user_achievements ua ON ua.id = pe.user_achievement_id
SET pe.party_id = ua.party_id;

-- 3) 알림 종류에 파티 삭제 추가
ALTER TABLE notifications
    MODIFY COLUMN type ENUM(
        'VOTE_REQUEST',
        'VOTE_REMINDER',
        'VOTE_RECEIVED',
        'VERIFY_RESULT',
        'PLAN_MISSED',
        'VERIFICATION_PHOTO_ADDED',
        'WEEKLY_SETTLED',
        'LEVEL_UP',
        'CHARACTER_GROWN',
        'MONTHLY_RANKING',
        'PARTY_JOINED',
        'PARTY_LEFT',
        'ACHIEVEMENT_UNLOCKED',
        'PARTY_DELETED'
    ) NOT NULL;

-- 4) 알림은 회원별 최근 30개만 남김 (이후로는 새 알림이 생길 때마다 서버가 정리)
DELETE n FROM notifications n
    JOIN (SELECT id
          FROM (SELECT id, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY id DESC) AS rn
                FROM notifications) ranked
          WHERE ranked.rn > 30) old_rows ON old_rows.id = n.id;
