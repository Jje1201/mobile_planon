-- PLAN:ON V2: 주간 결산과 경험치 장부
-- V1 은 이미 적용된 DB가 있으므로 수정하지 않고, 필요한 테이블만 추가합니다.

-- 12. 주간 결산 실행 기록 (파티·주마다 한 번)
CREATE TABLE weekly_settlements (
                                    id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                    party_id BIGINT NOT NULL,
                                    week_start DATE NOT NULL,
                                    settled_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                    CONSTRAINT fk_weekly_settlements_party
                                        FOREIGN KEY (party_id) REFERENCES parties(id),
                                    UNIQUE KEY uq_weekly_settlement (party_id, week_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. 주간 순위와 경험치 근거
CREATE TABLE weekly_results (
                                settlement_id BIGINT NOT NULL,
                                user_id BIGINT NOT NULL,
                                `rank` INT NOT NULL,
                                points INT NOT NULL,
                                done_count INT NOT NULL,
                                plan_count INT NOT NULL,
                                review_ok BOOLEAN NOT NULL,
                                party_goal_ok BOOLEAN NOT NULL,
                                exp_total INT NOT NULL,
                                PRIMARY KEY (settlement_id, user_id),
                                CONSTRAINT fk_weekly_results_settlement
                                    FOREIGN KEY (settlement_id) REFERENCES weekly_settlements(id),
                                CONSTRAINT fk_weekly_results_user
                                    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. 경험치 장부
-- users.total_exp / users.level 은 이 표의 합계로 계산한 캐시입니다.
-- 경험치는 반드시 이 표에 한 줄을 쓰는 같은 트랜잭션 안에서만 users 를 갱신합니다.
CREATE TABLE exp_events (
                            id BIGINT PRIMARY KEY AUTO_INCREMENT,
                            user_id BIGINT NOT NULL,
                            settlement_id BIGINT NULL,
                            source ENUM(
        'WEEKLY_RANK', 'WEEKLY_COMPLETION', 'WEEKLY_REVIEW', 'PARTY_GOAL', 'ADJUST'
    ) NOT NULL,
                            amount INT NOT NULL,
                            level_before INT NOT NULL,
                            level_after INT NOT NULL,
                            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                            CONSTRAINT fk_exp_events_user
                                FOREIGN KEY (user_id) REFERENCES users(id),
                            CONSTRAINT fk_exp_events_settlement
                                FOREIGN KEY (settlement_id) REFERENCES weekly_settlements(id),
                            UNIQUE KEY uq_exp_settlement_source (user_id, settlement_id, source),
                            INDEX idx_exp_events_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 자정 확정 스케줄러가 "아직 확정 안 됐고 마감이 지난 인증"을 빨리 찾도록
CREATE INDEX idx_verifications_due ON verifications (finalized_at, vote_deadline);
CREATE INDEX idx_plans_status_date ON plans (status, plan_date);
