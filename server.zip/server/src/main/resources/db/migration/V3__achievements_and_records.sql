-- PLAN:ON V3: 업적 · 하루 기록 · 연속 기록 · 월간 랭킹 확정본
-- V1, V2 는 그대로 두고 필요한 테이블만 추가합니다. 서버를 켜면 Flyway 가 자동으로 적용합니다.

-- 15. 사람별 하루 결과
-- result: NONE(일정 없음) · PENDING(확정 안 된 일정 있음) · CLEAR(3개 이상 전부 인정)
--         · SHORT(1~2개 전부 인정) · FAIL(미인정·미인증이 하나라도 있음)
CREATE TABLE daily_records (
                               user_id BIGINT NOT NULL,
                               record_date DATE NOT NULL,
                               party_id BIGINT NULL,
                               plan_count TINYINT NOT NULL DEFAULT 0,
                               approved_count TINYINT NOT NULL DEFAULT 0,
                               rejected_count TINYINT NOT NULL DEFAULT 0,
                               missed_count TINYINT NOT NULL DEFAULT 0,
                               pending_count TINYINT NOT NULL DEFAULT 0,
                               result ENUM('NONE', 'PENDING', 'CLEAR', 'SHORT', 'FAIL') NOT NULL,
                               resolved_at TIMESTAMP NULL,
                               PRIMARY KEY (user_id, record_date),
                               CONSTRAINT fk_daily_records_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               INDEX idx_daily_records_party (party_id, record_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 16. 연속 기록 캐시 (daily_records 를 날짜 순서대로 반영한 결과)
CREATE TABLE user_streaks (
                              user_id BIGINT PRIMARY KEY,
                              clear_streak SMALLINT NOT NULL DEFAULT 0,
                              best_clear_streak SMALLINT NOT NULL DEFAULT 0,
                              fail_streak SMALLINT NOT NULL DEFAULT 0,
                              none_streak SMALLINT NOT NULL DEFAULT 0,
                              last_record_date DATE NULL,
                              CONSTRAINT fk_user_streaks_user
                                  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 17. 파티별 하루 결과 (그날 그 파티 소속이었던 사람 기준)
CREATE TABLE party_daily_records (
                                     party_id BIGINT NOT NULL,
                                     record_date DATE NOT NULL,
                                     member_count TINYINT NOT NULL,
                                     clear_count TINYINT NOT NULL,
                                     all_clear BOOLEAN NOT NULL,
                                     party_clear_streak SMALLINT NOT NULL DEFAULT 0,
                                     resolved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                     PRIMARY KEY (party_id, record_date),
                                     CONSTRAINT fk_party_daily_records_party
                                         FOREIGN KEY (party_id) REFERENCES parties(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 18. 업적 목록
CREATE TABLE achievements (
                              code VARCHAR(30) PRIMARY KEY,
                              name VARCHAR(20) NOT NULL,
                              description VARCHAR(100) NOT NULL,
                              category ENUM('STREAK', 'PARTY', 'FUN', 'MONTHLY') NOT NULL,
                              threshold INT NULL,
                              reward_points INT NOT NULL DEFAULT 0,
                              is_hidden BOOLEAN NOT NULL DEFAULT FALSE,
                              sort_order TINYINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 19. 받은 업적 (받을 때마다 한 줄. 보상 포인트는 처음 한 번만)
CREATE TABLE user_achievements (
                                   id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                   user_id BIGINT NOT NULL,
                                   achievement_code VARCHAR(30) NOT NULL,
                                   party_id BIGINT NULL,
                                   period_key VARCHAR(10) NOT NULL,
                                   achieved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                   point_event_id BIGINT NULL,
                                   CONSTRAINT fk_user_achievements_user
                                       FOREIGN KEY (user_id) REFERENCES users(id),
                                   CONSTRAINT fk_user_achievements_code
                                       FOREIGN KEY (achievement_code) REFERENCES achievements(code),
                                   UNIQUE KEY uq_user_achievement_period (user_id, achievement_code, period_key),
                                   INDEX idx_user_achievements_user (user_id, achieved_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 20. 월간 랭킹 확정본 (매월 1일에 지난달을 고정)
CREATE TABLE monthly_rankings (
                                  party_id BIGINT NOT NULL,
                                  month_start DATE NOT NULL,
                                  user_id BIGINT NOT NULL,
                                  `rank` TINYINT NOT NULL,
                                  points INT NOT NULL,
                                  done_count SMALLINT NOT NULL,
                                  exp_earned INT NOT NULL DEFAULT 0,
                                  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                  PRIMARY KEY (party_id, month_start, user_id),
                                  CONSTRAINT fk_monthly_rankings_party
                                      FOREIGN KEY (party_id) REFERENCES parties(id),
                                  CONSTRAINT fk_monthly_rankings_user
                                      FOREIGN KEY (user_id) REFERENCES users(id),
                                  INDEX idx_monthly_rankings_first (user_id, `rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 업적 보상 포인트를 어떤 업적에서 받았는지 연결 (업적당 한 번만)
ALTER TABLE point_events
    ADD COLUMN user_achievement_id BIGINT NULL,
    ADD CONSTRAINT uq_point_events_achievement UNIQUE (user_achievement_id),
    ADD CONSTRAINT fk_point_events_achievement
        FOREIGN KEY (user_achievement_id) REFERENCES user_achievements(id);

ALTER TABLE user_achievements
    ADD CONSTRAINT fk_user_achievements_point
        FOREIGN KEY (point_event_id) REFERENCES point_events(id);

-- 업적 13개 (보상 포인트·기준값은 여기서 바꾸면 코드 수정 없이 반영)
INSERT INTO achievements (code, name, description, category, threshold, reward_points, is_hidden, sort_order) VALUES
    ('STREAK_3',        '삼일천하',       '3일 연속 계획 올클',                                 'STREAK',  3,   15,  FALSE, 1),
    ('STREAK_7',        '칠일무패',       '7일 연속 계획 올클',                                 'STREAK',  7,   40,  FALSE, 2),
    ('STREAK_30',       '철의 의지',      '30일 연속 계획 올클',                                'STREAK',  30,  150, FALSE, 3),
    ('PARTY_CLEAR_1',   '환상의 팀워크',  '파티원 전원이 같은 날 계획 올클 (2명 이상)',           'PARTY',   1,   20,  FALSE, 4),
    ('PARTY_STREAK_7',  '전설의 파티',    '파티원 전원 올클 7일 연속',                          'PARTY',   7,   60,  FALSE, 5),
    ('WEEKEND_CLEAR',   '휴일 반납',      '같은 주말 토요일·일요일 모두 올클',                    'FUN',     NULL, 0,  FALSE, 6),
    ('STREAK_BROKEN',   '작심삼일',       '3일 이상 이어진 올클이 끊김',                         'FUN',     3,   0,   TRUE,  7),
    ('IDLE_7',          '잠수 전문가',    '7일 연속 계획을 하나도 등록하지 않음',                  'FUN',     7,   0,   TRUE,  8),
    ('FAIL_7',          '내일부터는 진짜', '7일 연속 계획 올클 실패',                            'FUN',     7,   0,   TRUE,  9),
    ('LAST_MINUTE',     '벼락치기의 미학', '사진 마감 10분 전(23:20~23:29)에 제출하고 인정받음',    'FUN',     NULL, 0,  TRUE,  10),
    ('MONTH_END_SPURT', '막판 스퍼트',    '한 달의 마지막 3일 동안 150P 이상',                   'MONTHLY', 150, 0,   FALSE, 11),
    ('THRONE_FIRST',    '왕좌의 주인',    '파티 월간 랭킹 1위를 처음 차지',                       'MONTHLY', NULL, 0,  FALSE, 12),
    ('THRONE_USURPER',  '왕좌 찬탈자',    '두 달 연속 1위였던 파티원을 끌어내리고 1위',             'MONTHLY', 2,   0,   FALSE, 13);
