
-- PLAN:ON 초기 데이터베이스 구조
-- MySQL 8.x / Flyway V1

-- 1. 회원
CREATE TABLE users (
                       id BIGINT PRIMARY KEY AUTO_INCREMENT,
                       login_id VARCHAR(50) NOT NULL UNIQUE,
                       password_hash VARCHAR(255) NOT NULL,
                       nickname VARCHAR(30) NOT NULL,
                       total_exp INT NOT NULL DEFAULT 0,
                       level INT NOT NULL DEFAULT 1,
                       created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                       deleted_at TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 파티
CREATE TABLE parties (
                         id BIGINT PRIMARY KEY AUTO_INCREMENT,
                         name VARCHAR(50) NOT NULL,
                         invite_code VARCHAR(20) NOT NULL UNIQUE,
                         leader_id BIGINT NOT NULL,
                         created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                         CONSTRAINT fk_parties_leader
                             FOREIGN KEY (leader_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 파티원
-- user_id가 PK이므로 회원 한 명은 파티 하나에만 소속
CREATE TABLE party_members (
                               user_id BIGINT PRIMARY KEY,
                               party_id BIGINT NOT NULL,
                               character_id VARCHAR(50) NULL,
                               joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               CONSTRAINT fk_party_members_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               CONSTRAINT fk_party_members_party
                                   FOREIGN KEY (party_id) REFERENCES parties(id),
                               UNIQUE KEY uq_party_character (party_id, character_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. 일정
CREATE TABLE plans (
                       id BIGINT PRIMARY KEY AUTO_INCREMENT,
                       user_id BIGINT NOT NULL,
                       party_id BIGINT NULL,
                       plan_date DATE NOT NULL,
                       title VARCHAR(100) NOT NULL,
                       start_time TIME NULL,
                       category VARCHAR(30) NULL,
                       memo TEXT NULL,
                       status ENUM(
        'TODO', 'VOTING', 'APPROVED', 'REJECTED', 'MISSED'
    ) NOT NULL DEFAULT 'TODO',
                       created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                       updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                           ON UPDATE CURRENT_TIMESTAMP,
                       CONSTRAINT fk_plans_user
                           FOREIGN KEY (user_id) REFERENCES users(id),
                       CONSTRAINT fk_plans_party
                           FOREIGN KEY (party_id) REFERENCES parties(id),
                       INDEX idx_plans_user_date (user_id, plan_date),
                       INDEX idx_plans_party_date (party_id, plan_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. 인증 회차
-- 일정 하나에 인증 회차를 여러 개 등록할 수 있음
CREATE TABLE verifications (
                               id BIGINT PRIMARY KEY AUTO_INCREMENT,
                               plan_id BIGINT NOT NULL,
                               comment TEXT NULL,
                               submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               vote_deadline TIMESTAMP NULL,
                               all_voted_at TIMESTAMP NULL,
                               confirm_at TIMESTAMP NULL,
                               reminded_at TIMESTAMP NULL,
                               finalized_at TIMESTAMP NULL,
                               result ENUM('APPROVED', 'REJECTED') NULL,
                               finalize_reason VARCHAR(100) NULL,
                               voter_count INT NOT NULL DEFAULT 0,
                               approve_count INT NOT NULL DEFAULT 0,
                               reject_count INT NOT NULL DEFAULT 0,
                               CONSTRAINT fk_verifications_plan
                                   FOREIGN KEY (plan_id) REFERENCES plans(id),
                               INDEX idx_verifications_plan (plan_id, submitted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. 인증사진
-- 인증 회차마다 여러 장의 사진을 등록할 수 있음
-- 추가 사진은 기존 인증 회차에 연결하므로 투표가 초기화되지 않음
CREATE TABLE verification_photos (
                                     id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                     verification_id BIGINT NOT NULL,
                                     image_path VARCHAR(500) NOT NULL,
                                     uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                     CONSTRAINT fk_verification_photos_verification
                                         FOREIGN KEY (verification_id) REFERENCES verifications(id),
                                     INDEX idx_verification_photos (verification_id, uploaded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. 인증 투표
-- 한 회원은 인증 회차당 투표 기록 하나를 가짐
-- APPROVE / REJECT 중 선택하고, 변경 시 기존 행을 갱신
CREATE TABLE verification_votes (
                                    verification_id BIGINT NOT NULL,
                                    voter_id BIGINT NOT NULL,
                                    vote ENUM('APPROVE', 'REJECT') NULL,
                                    voted_at TIMESTAMP NULL,
                                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                                        ON UPDATE CURRENT_TIMESTAMP,
                                    change_count INT NOT NULL DEFAULT 0,
                                    is_active BOOLEAN NOT NULL DEFAULT TRUE,
                                    PRIMARY KEY (verification_id, voter_id),
                                    CONSTRAINT fk_votes_verification
                                        FOREIGN KEY (verification_id) REFERENCES verifications(id),
                                    CONSTRAINT fk_votes_voter
                                        FOREIGN KEY (voter_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. 투표 변경 기록
CREATE TABLE vote_logs (
                           id BIGINT PRIMARY KEY AUTO_INCREMENT,
                           verification_id BIGINT NOT NULL,
                           voter_id BIGINT NOT NULL,
                           action ENUM('CAST', 'CHANGE', 'REMOVED') NOT NULL,
                           from_vote ENUM('APPROVE', 'REJECT') NULL,
                           to_vote ENUM('APPROVE', 'REJECT') NULL,
                           created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                           CONSTRAINT fk_vote_logs_verification
                               FOREIGN KEY (verification_id) REFERENCES verifications(id),
                           CONSTRAINT fk_vote_logs_voter
                               FOREIGN KEY (voter_id) REFERENCES users(id),
                           INDEX idx_vote_logs_verification (verification_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. 포인트 지급 기록
-- 일정당 포인트 이벤트는 한 번만 허용
CREATE TABLE point_events (
                              id BIGINT PRIMARY KEY AUTO_INCREMENT,
                              user_id BIGINT NOT NULL,
                              plan_id BIGINT NULL UNIQUE,
                              event_type ENUM(
        'PLAN_APPROVED', 'PLAN_REJECTED', 'ACHIEVEMENT', 'ADJUST'
    ) NOT NULL,
                              points INT NOT NULL,
                              description VARCHAR(255) NULL,
                              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                              CONSTRAINT fk_point_events_user
                                  FOREIGN KEY (user_id) REFERENCES users(id),
                              CONSTRAINT fk_point_events_plan
                                  FOREIGN KEY (plan_id) REFERENCES plans(id),
                              INDEX idx_point_events_user_date (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. 알림
CREATE TABLE notifications (
                               id BIGINT PRIMARY KEY AUTO_INCREMENT,
                               user_id BIGINT NOT NULL,
                               type ENUM(
        'VOTE_REQUEST',
        'VOTE_REMINDER',
        'VOTE_RECEIVED',
        'VERIFY_RESULT',
        'PLAN_MISSED',
        'VERIFICATION_PHOTO_ADDED',
        'WEEKLY_SETTLED',
        'LEVEL_UP',
        'CHARACTER_GROWN',
        'MONTHLY_RANKING',
        'PARTY_JOINED',
        'PARTY_LEFT',
        'ACHIEVEMENT_UNLOCKED'
    ) NOT NULL,
                               title VARCHAR(100) NOT NULL,
                               body VARCHAR(500) NOT NULL,
                               plan_id BIGINT NULL,
                               party_id BIGINT NULL,
                               achievement_code VARCHAR(50) NULL,
                               is_read BOOLEAN NOT NULL DEFAULT FALSE,
                               created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               read_at TIMESTAMP NULL,
                               CONSTRAINT fk_notifications_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               CONSTRAINT fk_notifications_plan
                                   FOREIGN KEY (plan_id) REFERENCES plans(id),
                               CONSTRAINT fk_notifications_party
                                   FOREIGN KEY (party_id) REFERENCES parties(id),
                               INDEX idx_notifications_user_read (user_id, is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. 푸시 알림용 기기 토큰
CREATE TABLE device_tokens (
                               id BIGINT PRIMARY KEY AUTO_INCREMENT,
                               user_id BIGINT NOT NULL,
                               fcm_token VARCHAR(500) NOT NULL UNIQUE,
                               created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                                   ON UPDATE CURRENT_TIMESTAMP,
                               CONSTRAINT fk_device_tokens_user
                                   FOREIGN KEY (user_id) REFERENCES users(id),
                               INDEX idx_device_tokens_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
