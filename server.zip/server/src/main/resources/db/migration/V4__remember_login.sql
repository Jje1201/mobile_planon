-- PLAN:ON V4: 기기에 저장한 계정으로 바로 로그인 (카카오 "간편로그인 계정 선택" 방식)
-- 토큰 원문은 휴대폰에만 있고, 서버에는 SHA-256 해시만 저장합니다.

CREATE TABLE remember_tokens (
                                 id BIGINT PRIMARY KEY AUTO_INCREMENT,
                                 user_id BIGINT NOT NULL,
                                 token_hash CHAR(64) NOT NULL,
                                 device_name VARCHAR(100) NULL,
                                 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                 last_used_at TIMESTAMP NULL,
                                 expires_at TIMESTAMP NOT NULL,
                                 revoked_at TIMESTAMP NULL,
                                 CONSTRAINT fk_remember_tokens_user
                                     FOREIGN KEY (user_id) REFERENCES users(id),
                                 UNIQUE KEY uq_remember_tokens_hash (token_hash),
                                 INDEX idx_remember_tokens_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
