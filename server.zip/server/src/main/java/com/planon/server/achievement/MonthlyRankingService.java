package com.planon.server.achievement;

import com.planon.server.common.Dtos.RankEntryDto;
import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import com.planon.server.notification.NotificationService;
import com.planon.server.ranking.RankingService;
import com.planon.server.ranking.StatsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.Date;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 매월 1일: 지난달 파티 순위를 monthly_rankings 에 고정하고 월간 업적(막판 스퍼트·왕좌의 주인·왕좌 찬탈자)을 판정.
 * (party_id, month_start, user_id) PK 라서 여러 번 실행돼도 한 번만 들어감. 서버가 꺼져 있었으면 최근 3개월까지 채움.
 */
@Service
public class MonthlyRankingService {

    private static final Logger log = LoggerFactory.getLogger(MonthlyRankingService.class);
    private static final int CATCH_UP_MONTHS = 3;

    private final JdbcTemplate jdbc;
    private final RankingService rankings;
    private final StatsRepository stats;
    private final AchievementService achievements;
    private final NotificationService notifications;
    private final TransactionTemplate tx;

    public MonthlyRankingService(JdbcTemplate jdbc, RankingService rankings, StatsRepository stats,
                                 AchievementService achievements, NotificationService notifications, TransactionTemplate tx) {
        this.jdbc = jdbc;
        this.rankings = rankings;
        this.stats = stats;
        this.achievements = achievements;
        this.notifications = notifications;
        this.tx = tx;
    }

    public int settleDueMonths() {
        YearMonth thisMonth = YearMonth.from(TimeRule.today());
        int count = 0;
        List<Map<String, Object>> parties = jdbc.queryForList("SELECT id, created_at FROM parties WHERE deleted_at IS NULL");
        for (int back = CATCH_UP_MONTHS; back >= 1; back--) { // 오래된 달부터 (찬탈자 판정에 앞 달 기록이 필요)
            YearMonth ym = thisMonth.minusMonths(back);
            for (Map<String, Object> p : parties) {
                long partyId = ((Number) p.get("id")).longValue();
                LocalDate created = Jdbc.dateTime(p.get("created_at")).toLocalDate();
                if (created.isAfter(ym.atEndOfMonth())) continue; // 그 달에 없던 파티
                try {
                    Boolean done = tx.execute(status -> settle(partyId, ym));
                    if (Boolean.TRUE.equals(done)) count++;
                } catch (Exception e) {
                    log.error("파티 {} {} 월간 확정 실패", partyId, ym, e);
                }
            }
        }
        if (count > 0) log.info("월간 랭킹 확정 {}건", count);
        return count;
    }

    private boolean settle(long partyId, YearMonth ym) {
        Date monthStart = Date.valueOf(ym.atDay(1));
        jdbc.queryForList("SELECT id FROM parties WHERE id = ? FOR UPDATE", partyId);
        if (Jdbc.count(jdbc, "SELECT COUNT(*) FROM monthly_rankings WHERE party_id = ? AND month_start = ?",
                partyId, monthStart) > 0) return false;
        List<StatsRepository.MemberRow> members = stats.members(partyId);
        if (members.isEmpty()) return false;

        LocalDate from = ym.atDay(1);
        LocalDate to = ym.plusMonths(1).atDay(1);
        List<RankEntryDto> entries = rankings.monthEntries(partyId, members, from, to);
        for (RankEntryDto e : entries) {
            jdbc.update("INSERT IGNORE INTO monthly_rankings (party_id, month_start, user_id, `rank`, points, done_count, "
                    + "exp_earned) VALUES (?, ?, ?, ?, ?, ?, ?)", partyId, monthStart, e.userId(), e.rank(), e.points(),
                    e.doneCount(), e.exp());
            notifications.notify(e.userId(), NotificationService.MONTHLY_RANKING, ym.getMonthValue() + "월 랭킹 확정",
                    ym.getMonthValue() + "월 파티 " + e.rank() + "위 · " + e.points() + "P", null, partyId);
        }

        String key = ym.toString(); // 2026-10
        // 막판 스퍼트: 그 달 마지막 3일 포인트 합계
        int spurt = achievements.threshold("MONTH_END_SPURT", 150);
        LocalDate last3 = ym.atEndOfMonth().minusDays(2);
        for (RankEntryDto e : entries) {
            if (stats.points(e.userId(), partyId, last3, to) >= spurt) achievements.award(e.userId(), "MONTH_END_SPURT", key, partyId);
        }

        // 1위: 포인트가 0보다 커야 인정 (아무도 안 한 달에 전원이 1위가 되는 것 방지)
        List<Long> tops = new ArrayList<>();
        for (RankEntryDto e : entries) if (e.rank() == 1 && e.points() > 0) tops.add(e.userId());
        for (Long top : tops) {
            int before = Jdbc.count(jdbc, "SELECT COUNT(*) FROM monthly_rankings WHERE user_id = ? AND `rank` = 1 "
                    + "AND points > 0 AND month_start < ?", top, monthStart);
            if (before == 0) achievements.award(top, "THRONE_FIRST", key, partyId);
        }
        // 왕좌 찬탈자: 앞의 두 달 같은 사람이 단독 1위, 이번 달 1위는 다른 사람
        Long prev1 = soleWinner(partyId, ym.minusMonths(1));
        Long prev2 = soleWinner(partyId, ym.minusMonths(2));
        if (prev1 != null && prev1.equals(prev2)) {
            for (Long top : tops) {
                if (!top.equals(prev1)) achievements.award(top, "THRONE_USURPER", key, partyId);
            }
        }
        return true;
    }

    private Long soleWinner(long partyId, YearMonth ym) {
        List<Long> w = jdbc.queryForList("SELECT user_id FROM monthly_rankings WHERE party_id = ? AND month_start = ? "
                + "AND `rank` = 1 AND points > 0", Long.class, partyId, Date.valueOf(ym.atDay(1)));
        return w.size() == 1 ? w.get(0) : null;
    }
}
