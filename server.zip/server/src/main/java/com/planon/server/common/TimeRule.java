package com.planon.server.common;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

/**
 * 시간 규칙 (모두 한국 시간)
 * - 인증사진 등록·추가: 일정 날짜 23:30 까지
 * - 투표·투표 변경: 일정 날짜 24:00(다음 날 00:00) 까지
 * - 결과 반영: 자정에 합산
 */
public final class TimeRule {
    private TimeRule() {
    }

    public static final ZoneId ZONE = ZoneId.of("Asia/Seoul");
    public static final LocalTime PHOTO_DEADLINE = LocalTime.of(23, 30);
    /** 사진은 올린 뒤 이 시간(분) 동안만 지우거나 바꿀 수 있음 */
    public static final int PHOTO_EDIT_MINUTES = 10;
    public static final DateTimeFormatter MINUTE = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    public static LocalDateTime now() {
        return LocalDateTime.now(ZONE).withNano(0);
    }

    public static LocalDate today() {
        return LocalDate.now(ZONE);
    }

    public static LocalDateTime photoDeadline(LocalDate planDate) {
        return planDate.atTime(PHOTO_DEADLINE);
    }

    public static LocalDateTime voteDeadline(LocalDate planDate) {
        return planDate.plusDays(1).atStartOfDay();
    }

    public static LocalDate weekStart(LocalDate d) {
        return d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    }

    public static String minute(LocalDateTime t) {
        return t == null ? null : t.format(MINUTE);
    }
}
