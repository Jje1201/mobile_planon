package com.planon.server.plan;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.PhotoDto;
import com.planon.server.common.Dtos.PlanDto;
import com.planon.server.common.Dtos.VoteInfoDto;
import com.planon.server.common.Jdbc;
import com.planon.server.common.LevelRule;
import com.planon.server.common.TimeRule;
import com.planon.server.ranking.StatsRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * plans + 최근 인증 회차 + 사진 + 투표를 앱의 Plan JSON 으로 만듭니다.
 * 투표가 확정되기 전에는 누가 무엇을 눌렀는지(남의 표 내용)는 숨기고, 투표 여부만 보여줍니다.
 */
@Component
public class PlanReader {

    public static final int MAX_PHOTOS = 10;

    private static final String PLAN_SELECT = "SELECT pl.id, pl.user_id, pl.plan_date, pl.title, pl.start_time, "
            + "pl.category, pl.memo, pl.status, u.nickname, u.total_exp, pm.character_id FROM plans pl "
            + "JOIN users u ON u.id = pl.user_id LEFT JOIN party_members pm ON pm.user_id = pl.user_id ";

    private final JdbcTemplate jdbc;

    public PlanReader(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** partyId: 이 파티에서 만든 일정만 (파티가 없으면 null → 파티 없이 만든 일정) */
    public List<PlanDto> list(long ownerId, Long partyId, LocalDate date, long viewerId) {
        List<Map<String, Object>> rows = jdbc.queryForList(PLAN_SELECT
                + "WHERE pl.user_id = ? AND pl.party_id <=> ? AND pl.plan_date = ? "
                + "ORDER BY pl.start_time IS NULL, pl.start_time, pl.id",
                ownerId, partyId, Date.valueOf(date));
        List<PlanDto> out = new ArrayList<>();
        for (Map<String, Object> r : rows) out.add(toDto(r, viewerId, false));
        return out;
    }

    public PlanDto one(long planId, long viewerId, boolean withVotes) {
        List<Map<String, Object>> rows = jdbc.queryForList(PLAN_SELECT + "WHERE pl.id = ?", planId);
        if (rows.isEmpty()) throw ApiException.notFound("일정을 찾을 수 없어요");
        return toDto(rows.get(0), viewerId, withVotes);
    }

    /** 일정의 가장 최근 인증 회차 (없으면 null) */
    public Map<String, Object> latestVerification(long planId) {
        List<Map<String, Object>> v = jdbc.queryForList("SELECT * FROM verifications WHERE plan_id = ? "
                + "ORDER BY id DESC LIMIT 1", planId);
        return v.isEmpty() ? null : v.get(0);
    }

    private PlanDto toDto(Map<String, Object> r, long viewerId, boolean withVotes) {
        long planId = num(r.get("id"));
        long ownerId = num(r.get("user_id"));
        LocalDate date = Jdbc.date(r.get("plan_date"));
        String status = (String) r.get("status");
        LocalTime start = Jdbc.time(r.get("start_time"));
        boolean owner = ownerId == viewerId;
        LocalDateTime now = TimeRule.now();
        LocalDateTime photoDeadline = TimeRule.photoDeadline(date);
        LocalDateTime voteDeadline = TimeRule.voteDeadline(date);

        List<String> images = new ArrayList<>();
        List<PhotoDto> photos = new ArrayList<>();
        String comment = null;
        String submittedAt = null;
        boolean finalized = false;
        int approve = 0;
        int reject = 0;
        int voted = 0;
        int voters = 0;
        int myVote = 0;
        boolean amVoter = false;
        List<VoteInfoDto> votes = new ArrayList<>();

        Map<String, Object> v = latestVerification(planId);
        if (v != null) {
            long verificationId = num(v.get("id"));
            comment = (String) v.get("comment");
            submittedAt = TimeRule.minute(Jdbc.dateTime(v.get("submitted_at")));
            finalized = v.get("finalized_at") != null;
            LocalDateTime deadline = Jdbc.dateTime(v.get("vote_deadline"));
            if (deadline != null) voteDeadline = deadline;
            boolean open = !finalized && "VOTING".equals(status);
            for (Map<String, Object> ph : jdbc.queryForList("SELECT id, image_path, uploaded_at FROM verification_photos "
                    + "WHERE verification_id = ? ORDER BY uploaded_at, id", verificationId)) {
                String url = (String) ph.get("image_path");
                LocalDateTime uploaded = Jdbc.dateTime(ph.get("uploaded_at"));
                LocalDateTime until = uploaded.plusMinutes(TimeRule.PHOTO_EDIT_MINUTES);
                images.add(url);
                photos.add(new PhotoDto(((Number) ph.get("id")).longValue(), url, TimeRule.minute(uploaded),
                        TimeRule.minute(until), owner && open && now.isBefore(until)));
            }

            List<Map<String, Object>> rows = jdbc.queryForList("SELECT vv.voter_id, vv.vote, u.nickname "
                    + "FROM verification_votes vv JOIN users u ON u.id = vv.voter_id "
                    + "WHERE vv.verification_id = ? AND vv.is_active = TRUE ORDER BY u.id", verificationId);
            for (Map<String, Object> row : rows) {
                long voterId = num(row.get("voter_id"));
                int value = voteValue((String) row.get("vote"));
                voters++;
                if (value != 0) voted++;
                if (value > 0) approve++;
                if (value < 0) reject++;
                if (voterId == viewerId) {
                    myVote = value;
                    amVoter = true;
                }
                if (withVotes) {
                    int shown = finalized || voterId == viewerId ? value : 0;
                    votes.add(new VoteInfoDto(voterId, (String) row.get("nickname"), value != 0, shown));
                }
            }
            if (finalized) {
                // 확정 때 기록한 값 (나중에 누가 나가도 결과 숫자는 그대로)
                approve = ((Number) v.get("approve_count")).intValue();
                reject = ((Number) v.get("reject_count")).intValue();
            } else if (!owner) {
                approve = 0;
                reject = 0;
            } else {
                // 본인은 미인정이 있는지 알아야 사진을 보탤 수 있으므로 미인정 수만 보여줌
                approve = 0;
            }
        }

        boolean canSubmit = owner && "TODO".equals(status) && date.equals(TimeRule.today()) && now.isBefore(photoDeadline);
        boolean canAddPhotos = owner && "VOTING".equals(status) && !finalized && now.isBefore(photoDeadline)
                && images.size() < MAX_PHOTOS;
        boolean canVote = !owner && amVoter && "VOTING".equals(status) && !finalized && now.isBefore(voteDeadline);

        return new PlanDto(planId, ownerId, (String) r.get("nickname"),
                StatsRepository.parseCharacter((String) r.get("character_id")),
                LevelRule.stageFor(LevelRule.levelFor(((Number) r.get("total_exp")).intValue())),
                date.toString(), (String) r.get("title"),
                start == null ? null : String.format("%02d:%02d", start.getHour(), start.getMinute()),
                (String) r.get("category"), (String) r.get("memo"), status,
                images, photos, comment, submittedAt,
                TimeRule.minute(photoDeadline), TimeRule.minute(voteDeadline), finalized,
                approve, reject, voted, voters, myVote,
                canSubmit, canAddPhotos, canVote, withVotes ? votes : null);
    }

    public static int voteValue(String vote) {
        if ("APPROVE".equals(vote)) return 1;
        if ("REJECT".equals(vote)) return -1;
        return 0;
    }

    private static long num(Object o) {
        return ((Number) o).longValue();
    }
}
