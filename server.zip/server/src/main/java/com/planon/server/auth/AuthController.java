package com.planon.server.auth;

import com.planon.server.common.Dtos.AvailableResponse;
import com.planon.server.common.Dtos.LoginRequest;
import com.planon.server.common.Dtos.LoginResponse;
import com.planon.server.common.Dtos.QuickLoginRequest;
import org.springframework.http.ResponseEntity;
import com.planon.server.common.Dtos.SignUpRequest;
import com.planon.server.common.Dtos.UserDto;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * 회원가입·로그인. 예전 주소(/api/users/signup, /api/users/login)도 같은 기능으로 받습니다.
 */
@RestController
public class AuthController {

    private final AuthService auth;

    public AuthController(AuthService auth) {
        this.auth = auth;
    }

    @GetMapping("/api/auth/check-id")
    public AvailableResponse checkId(@RequestParam String loginId) {
        return new AvailableResponse(auth.isAvailable(loginId));
    }

    @PostMapping({"/api/auth/signup", "/api/users/signup"})
    @ResponseStatus(HttpStatus.CREATED)
    public UserDto signUp(@RequestBody SignUpRequest body) {
        return auth.signUp(body.loginId(), body.password(), body.nickname());
    }

    @PostMapping({"/api/auth/login", "/api/users/login"})
    public LoginResponse login(@RequestBody LoginRequest body) {
        return auth.login(body.loginId(), body.password(), Boolean.TRUE.equals(body.remember()), body.deviceName());
    }

    /** 이 기기에 저장한 계정으로 바로 로그인 */
    @PostMapping("/api/auth/quick-login")
    public LoginResponse quickLogin(@RequestBody QuickLoginRequest body) {
        return auth.quickLogin(body.rememberToken());
    }

    /** 저장한 계정을 기기 목록에서 지울 때 서버 토큰도 폐기 (토큰을 가진 기기만 가능) */
    @PostMapping("/api/auth/forget")
    public ResponseEntity<Void> forget(@RequestBody QuickLoginRequest body) {
        auth.forget(body.rememberToken());
        return ResponseEntity.ok().build();
    }
}
