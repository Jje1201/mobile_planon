package com.planon.server.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;

/**
 * 로그인 토큰: base64url("userId:만료시각") + "." + HMAC-SHA256 서명.
 * 외부 라이브러리 없이 JDK만으로 만들고 검증합니다. 앱은 SQLite session 테이블에 저장해 자동 로그인에 씁니다.
 */
@Component
public class TokenService {

    private final byte[] secret;
    private final long ttlDays;

    public TokenService(@Value("${planon.token.secret}") String secret,
                        @Value("${planon.token.ttl-days:14}") long ttlDays) {
        this.secret = secret.getBytes(StandardCharsets.UTF_8);
        this.ttlDays = ttlDays;
    }

    public String issue(long userId) {
        long exp = Instant.now().plus(ttlDays, ChronoUnit.DAYS).getEpochSecond();
        String payload = b64(userId + ":" + exp);
        return payload + "." + sign(payload);
    }

    /** 유효하면 userId, 아니면 -1 */
    public long verify(String token) {
        if (token == null) return -1;
        int dot = token.indexOf('.');
        if (dot <= 0) return -1;
        String payload = token.substring(0, dot);
        String signature = token.substring(dot + 1);
        if (!MessageDigest.isEqual(sign(payload).getBytes(StandardCharsets.US_ASCII),
                signature.getBytes(StandardCharsets.US_ASCII))) {
            return -1;
        }
        try {
            String[] parts = new String(Base64.getUrlDecoder().decode(payload), StandardCharsets.UTF_8).split(":");
            long userId = Long.parseLong(parts[0]);
            long exp = Long.parseLong(parts[1]);
            return Instant.now().getEpochSecond() < exp ? userId : -1;
        } catch (RuntimeException e) {
            return -1;
        }
    }

    private String sign(String payload) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding()
                    .encodeToString(mac.doFinal(payload.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException("토큰 서명 실패", e);
        }
    }

    private static String b64(String s) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(s.getBytes(StandardCharsets.UTF_8));
    }
}
