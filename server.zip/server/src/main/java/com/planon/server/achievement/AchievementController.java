package com.planon.server.achievement;

import com.planon.server.common.Dtos.AchievementsResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AchievementController {

    private final AchievementService achievements;

    public AchievementController(AchievementService achievements) {
        this.achievements = achievements;
    }

    /** 업적 13개 (받은 횟수·처음 받은 날) + 현재·최고 연속 올클 */
    @GetMapping("/api/achievements")
    public AchievementsResponse mine(@RequestAttribute("userId") long userId) {
        return achievements.list(userId);
    }
}
