package com.planon.server.plan;

import com.planon.server.common.Dtos.PlanDto;
import com.planon.server.common.Dtos.PlanRequest;
import com.planon.server.common.Dtos.VoteRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
public class PlanController {

    private final PlanService plans;
    private final VerificationService verifications;

    public PlanController(PlanService plans, VerificationService verifications) {
        this.plans = plans;
        this.verifications = verifications;
    }

    @GetMapping("/api/plans")
    public List<PlanDto> list(@RequestAttribute("userId") long me,
                              @RequestParam(required = false) Long userId,
                              @RequestParam String date) {
        return plans.list(me, userId == null ? me : userId, date);
    }

    @GetMapping("/api/plans/dates")
    public List<String> dates(@RequestAttribute("userId") long me, @RequestParam String yearMonth) {
        return plans.myDates(me, yearMonth);
    }

    @PostMapping("/api/plans")
    @ResponseStatus(HttpStatus.CREATED)
    public PlanDto add(@RequestAttribute("userId") long me, @RequestBody PlanRequest body) {
        return plans.add(me, body.date(), body.title(), body.time(), body.category(), body.memo());
    }

    @DeleteMapping("/api/plans/{id}")
    public ResponseEntity<Void> delete(@RequestAttribute("userId") long me, @PathVariable long id) {
        plans.delete(me, id);
        return ResponseEntity.ok().build();
    }

    /** multipart: images (1~5장, 같은 이름으로 여러 개) + comment. 예전 앱의 image 한 장도 받음 */
    @PostMapping("/api/plans/{id}/verification")
    public PlanDto submit(@RequestAttribute("userId") long me, @PathVariable long id,
                          @RequestParam(value = "images", required = false) List<MultipartFile> images,
                          @RequestParam(value = "image", required = false) MultipartFile image,
                          @RequestParam(value = "comment", required = false) String comment) {
        return verifications.submit(me, id, merge(images, image), comment);
    }

    /** 23:30 전까지 사진 보태기 (투표는 유지) */
    @PostMapping("/api/plans/{id}/verification/photos")
    public PlanDto addPhotos(@RequestAttribute("userId") long me, @PathVariable long id,
                             @RequestParam(value = "images", required = false) List<MultipartFile> images,
                             @RequestParam(value = "image", required = false) MultipartFile image) {
        return verifications.addPhotos(me, id, merge(images, image));
    }

    /** 올린 지 10분 안의 사진 지우기 (마지막 1장은 불가) */
    @DeleteMapping("/api/plans/{id}/verification/photos/{photoId}")
    public PlanDto deletePhoto(@RequestAttribute("userId") long me, @PathVariable long id, @PathVariable long photoId) {
        return verifications.deletePhoto(me, id, photoId);
    }

    /** 올린 지 10분 안의 사진 바꾸기: multipart image 한 장 (multipart 는 POST 로) */
    @PostMapping("/api/plans/{id}/verification/photos/{photoId}/replace")
    public PlanDto replacePhoto(@RequestAttribute("userId") long me, @PathVariable long id, @PathVariable long photoId,
                                @RequestParam("image") MultipartFile image) {
        return verifications.replacePhoto(me, id, photoId, image);
    }

    @GetMapping("/api/plans/{id}/verification")
    public PlanDto verification(@RequestAttribute("userId") long me, @PathVariable long id) {
        return verifications.get(me, id);
    }

    @PostMapping("/api/plans/{id}/votes")
    public PlanDto vote(@RequestAttribute("userId") long me, @PathVariable long id, @RequestBody VoteRequest body) {
        return verifications.vote(me, id, body.approve());
    }

    private static List<MultipartFile> merge(List<MultipartFile> images, MultipartFile image) {
        List<MultipartFile> all = new ArrayList<>();
        if (images != null) all.addAll(images);
        if (image != null) all.add(image);
        return all;
    }
}
