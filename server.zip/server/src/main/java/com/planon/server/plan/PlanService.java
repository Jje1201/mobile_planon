package com.planon.server.plan;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.PlanDto;
import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import com.planon.server.party.PartyService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Objects;

@Service
public class PlanService {

    public static final int MAX_PER_DAY = 10;
    public static final int MAX_DAYS_AHEAD = 30;
    private static final int TITLE_MAX = 50;
    private static final int CATEGORY_MAX = 30;
    private static final int MEMO_MAX = 500;

    private final JdbcTemplate jdbc;
    private final PlanReader reader;
    private final PartyService parties;

    public PlanService(JdbcTemplate jdbc, PlanReader reader, PartyService parties) {
        this.jdbc = jdbc;
        this.reader = reader;
        this.parties = parties;
    }

    /** 내 일정은 모든 날짜, 같은 파티원의 일정은 오늘 것만 볼 수 있음 */
    public List<PlanDto> list(long viewerId, long ownerId, String dateText) {
        LocalDate date = parseDate(dateText);
        if (ownerId != viewerId) {
            Long mine = parties.partyIdOf(viewerId);
            Long theirs = parties.partyIdOf(ownerId);
            if (mine == null || !Objects.equals(mine, theirs)) throw ApiException.forbidden("같은 파티원의 일정만 볼 수 있어요");
            if (!date.equals(TimeRule.today())) throw ApiException.forbidden("다른 파티원의 일정은 오늘 것만 볼 수 있어요");
        }
        // 지금 파티에서 만든 일정만 (파티를 옮기면 이전 파티 일정은 보이지 않음)
        return reader.list(ownerId, parties.partyIdOf(ownerId), date, viewerId);
    }

    public List<String> myDates(long userId, String yearMonth) {
        YearMonth ym;
        try {
            ym = YearMonth.parse(yearMonth);
        } catch (DateTimeParseException | NullPointerException e) {
            throw ApiException.badRequest("yearMonth 는 2026-10 형식이에요");
        }
        return jdbc.queryForList("SELECT DISTINCT DATE_FORMAT(plan_date, '%Y-%m-%d') FROM plans "
                        + "WHERE user_id = ? AND party_id <=> ? AND plan_date >= ? AND plan_date < ? ORDER BY 1", String.class,
                userId, parties.partyIdOf(userId), Date.valueOf(ym.atDay(1)), Date.valueOf(ym.plusMonths(1).atDay(1)));
    }

    @Transactional
    public PlanDto add(long userId, String dateText, String title, String timeText, String category, String memo) {
        LocalDate date = parseDate(dateText);
        LocalDate today = TimeRule.today();
        if (date.isBefore(today)) throw ApiException.badRequest("지난 날짜에는 일정을 만들 수 없어요");
        if (date.isAfter(today.plusDays(MAX_DAYS_AHEAD)))
            throw ApiException.badRequest("일정은 " + MAX_DAYS_AHEAD + "일 뒤까지만 만들 수 있어요");
        if (date.equals(today) && !TimeRule.now().isBefore(TimeRule.photoDeadline(today)))
            throw ApiException.badRequest("오늘 일정은 23:30 까지만 추가할 수 있어요 (인증 마감)");
        String t = title == null ? "" : title.trim();
        if (t.isEmpty() || t.length() > TITLE_MAX) throw ApiException.badRequest("일정 제목은 1~" + TITLE_MAX + "자로 입력해 주세요");
        LocalTime time = null;
        if (timeText != null && !timeText.isBlank()) {
            try {
                time = LocalTime.parse(timeText.trim());
            } catch (DateTimeParseException e) {
                throw ApiException.badRequest("시간은 09:30 형식으로 입력해 주세요");
            }
        }
        // 같은 사람이 동시에 추가해도 하루 10개를 넘지 않도록 회원 행을 잠금
        jdbc.queryForList("SELECT id FROM users WHERE id = ? FOR UPDATE", userId);
        int count = Jdbc.count(jdbc, "SELECT COUNT(*) FROM plans WHERE user_id = ? AND plan_date = ? AND party_id <=> ?",
                userId, Date.valueOf(date), parties.partyIdOf(userId));
        if (count >= MAX_PER_DAY) throw ApiException.badRequest("하루 일정은 " + MAX_PER_DAY + "개까지 만들 수 있어요");

        long id = Jdbc.insert(jdbc, "INSERT INTO plans (user_id, party_id, plan_date, title, start_time, category, memo, status) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, 'TODO')",
                userId, parties.partyIdOf(userId), Date.valueOf(date), t,
                time == null ? null : Time.valueOf(time), cut(category, CATEGORY_MAX), cut(memo, MEMO_MAX));
        return reader.one(id, userId, false);
    }

    /** 인증 전(TODO) 일정만 삭제 */
    @Transactional
    public void delete(long userId, long planId) {
        List<String> status = jdbc.queryForList("SELECT status FROM plans WHERE id = ? AND user_id = ? FOR UPDATE",
                String.class, planId, userId);
        if (status.isEmpty()) throw ApiException.notFound("일정을 찾을 수 없어요");
        if (!"TODO".equals(status.get(0))) throw ApiException.conflict("인증을 제출한 일정은 지울 수 없어요");
        jdbc.update("DELETE FROM notifications WHERE plan_id = ?", planId);
        jdbc.update("DELETE FROM plans WHERE id = ?", planId);
    }

    private static LocalDate parseDate(String text) {
        try {
            return LocalDate.parse(text);
        } catch (DateTimeParseException | NullPointerException e) {
            throw ApiException.badRequest("날짜는 2026-10-28 형식이에요");
        }
    }

    private static String cut(String s, int max) {
        if (s == null || s.isBlank()) return null;
        String t = s.trim();
        return t.length() <= max ? t : t.substring(0, max);
    }
}
