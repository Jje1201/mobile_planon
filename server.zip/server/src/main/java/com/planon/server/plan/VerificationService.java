package com.planon.server.plan;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.PlanDto;
import com.planon.server.common.Jdbc;
import com.planon.server.common.LevelRule;
import com.planon.server.common.TimeRule;
import com.planon.server.config.FileStorageService;
import com.planon.server.notification.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 인증 제출 · 사진 추가 · 투표 · 자정 확정.
 *
 * 규칙
 * - 사진 등록·추가: 일정 날짜 23:30 까지 (처음 1~5장, 합계 10장까지)
 * - 투표·변경: 일정 날짜 24:00 까지, 본인은 투표 불가, 마감 뒤에는 변경 불가
 * - 투표권: 제출하는 순간의 파티원(본인 제외)으로 고정, 나간 사람의 표는 빠짐
 * - 결과: 자정에 한 번 합산. 미인정 > 인정 이면 미수행(REJECTED), 같으면 인정. 안 한 표는 세지 않음
 * - 포인트: 일정당 한 번 (point_events.plan_id UNIQUE)
 */
@Service
public class VerificationService {

    private static final Logger log = LoggerFactory.getLogger(VerificationService.class);
    public static final int MAX_FIRST_PHOTOS = 5;
    private static final int COMMENT_MAX = 300;

    private final JdbcTemplate jdbc;
    private final PlanReader reader;
    private final FileStorageService files;
    private final NotificationService notifications;
    private final TransactionTemplate tx;

    public VerificationService(JdbcTemplate jdbc, PlanReader reader, FileStorageService files,
                               NotificationService notifications, TransactionTemplate tx) {
        this.jdbc = jdbc;
        this.reader = reader;
        this.files = files;
        this.notifications = notifications;
        this.tx = tx;
    }

    // ------------------------------------------------------------------ 제출

    @Transactional
    public PlanDto submit(long userId, long planId, List<MultipartFile> images, String comment) {
        Map<String, Object> plan = lockOwnPlan(userId, planId);
        LocalDate date = Jdbc.date(plan.get("plan_date"));
        String status = (String) plan.get("status");
        if (!"TODO".equals(status)) throw ApiException.conflict("이미 인증을 제출한 일정이에요. 사진은 '사진 추가'로 보탤 수 있어요");
        if (!date.equals(TimeRule.today())) throw ApiException.badRequest("인증은 일정 당일에만 제출할 수 있어요");
        LocalDateTime now = TimeRule.now();
        if (!now.isBefore(TimeRule.photoDeadline(date))) throw ApiException.badRequest("인증 사진은 23:30 까지만 올릴 수 있어요");
        List<MultipartFile> photos = nonEmpty(images);
        if (photos.isEmpty()) throw ApiException.badRequest("인증 사진을 한 장 이상 올려 주세요");
        if (photos.size() > MAX_FIRST_PHOTOS) throw ApiException.badRequest("처음에는 사진을 " + MAX_FIRST_PHOTOS + "장까지 올릴 수 있어요");

        // 투표권: 지금 파티원 중 본인 제외
        Long partyId = Jdbc.longOrNull(jdbc, "SELECT party_id FROM party_members WHERE user_id = ?", userId);
        List<Long> voters = partyId == null ? List.of() : jdbc.queryForList(
                "SELECT user_id FROM party_members WHERE party_id = ? AND user_id <> ?", Long.class, partyId, userId);

        long verificationId = Jdbc.insert(jdbc, "INSERT INTO verifications (plan_id, comment, submitted_at, vote_deadline, "
                        + "voter_count, approve_count, reject_count) VALUES (?, ?, ?, ?, ?, 0, 0)",
                planId, cut(comment), Timestamp.valueOf(now), Timestamp.valueOf(TimeRule.voteDeadline(date)), voters.size());
        savePhotos(verificationId, photos, now);
        for (Long voter : voters) {
            jdbc.update("INSERT INTO verification_votes (verification_id, voter_id, vote, change_count, is_active) "
                    + "VALUES (?, ?, NULL, 0, TRUE)", verificationId, voter);
        }
        jdbc.update("UPDATE plans SET status = 'VOTING' WHERE id = ?", planId);

        String nickname = nickname(userId);
        String title = (String) plan.get("title");
        for (Long voter : voters) {
            notifications.notify(voter, NotificationService.VOTE_REQUEST, "인증 검토 요청",
                    nickname + "님이 '" + title + "' 인증을 올렸어요. 자정 전까지 투표해 주세요", planId, partyId);
        }
        return reader.one(planId, userId, true);
    }

    /** 미인정을 받았을 때 등 마감(23:30) 전까지 사진을 보탭니다. 이미 한 투표는 그대로 유지 */
    @Transactional
    public PlanDto addPhotos(long userId, long planId, List<MultipartFile> images) {
        Map<String, Object> plan = lockOwnPlan(userId, planId);
        LocalDate date = Jdbc.date(plan.get("plan_date"));
        if (!"VOTING".equals(plan.get("status"))) throw ApiException.conflict("검토 중인 인증에만 사진을 추가할 수 있어요");
        LocalDateTime now = TimeRule.now();
        if (!now.isBefore(TimeRule.photoDeadline(date))) throw ApiException.badRequest("사진 추가는 23:30 까지만 할 수 있어요");
        Map<String, Object> v = reader.latestVerification(planId);
        if (v == null || v.get("finalized_at") != null) throw ApiException.conflict("이미 결과가 확정됐어요");
        long verificationId = ((Number) v.get("id")).longValue();
        List<MultipartFile> photos = nonEmpty(images);
        if (photos.isEmpty()) throw ApiException.badRequest("추가할 사진을 골라 주세요");
        int existing = Jdbc.count(jdbc, "SELECT COUNT(*) FROM verification_photos WHERE verification_id = ?", verificationId);
        if (existing + photos.size() > PlanReader.MAX_PHOTOS)
            throw ApiException.badRequest("사진은 모두 " + PlanReader.MAX_PHOTOS + "장까지예요 (지금 " + existing + "장)");
        savePhotos(verificationId, photos, now);

        String nickname = nickname(userId);
        List<Long> voters = jdbc.queryForList("SELECT voter_id FROM verification_votes WHERE verification_id = ? "
                + "AND is_active = TRUE", Long.class, verificationId);
        for (Long voter : voters) {
            notifications.notify(voter, NotificationService.PHOTO_ADDED, "인증 사진 추가",
                    nickname + "님이 '" + plan.get("title") + "' 인증에 사진 " + photos.size() + "장을 더 올렸어요",
                    planId, (Long) toLong(plan.get("party_id")));
        }
        return reader.one(planId, userId, true);
    }

    /**
     * 올린 지 10분 안의 사진 삭제. 인증에는 사진이 최소 1장 있어야 하므로 마지막 1장은 '바꾸기'만 가능.
     * 바꾸거나 지워도 이미 받은 표는 유지.
     */
    @Transactional
    public PlanDto deletePhoto(long userId, long planId, long photoId) {
        Map<String, Object> ph = lockEditablePhoto(userId, planId, photoId);
        long verificationId = ((Number) ph.get("verification_id")).longValue();
        int count = Jdbc.count(jdbc, "SELECT COUNT(*) FROM verification_photos WHERE verification_id = ?", verificationId);
        if (count <= 1) throw ApiException.badRequest("인증 사진은 최소 1장 있어야 해요. 지우는 대신 '바꾸기'를 써 주세요");
        jdbc.update("DELETE FROM verification_photos WHERE id = ?", photoId);
        String path = (String) ph.get("image_path");
        afterCommit(() -> files.delete(path));
        return reader.one(planId, userId, true);
    }

    /** 올린 지 10분 안의 사진을 다른 사진으로 교체. 수정 가능 시간은 처음 올린 시각 기준 그대로 (교체로 연장되지 않음) */
    @Transactional
    public PlanDto replacePhoto(long userId, long planId, long photoId, MultipartFile image) {
        if (image == null || image.isEmpty()) throw ApiException.badRequest("바꿀 사진을 골라 주세요");
        Map<String, Object> ph = lockEditablePhoto(userId, planId, photoId);
        String newPath = files.save(image);
        jdbc.update("UPDATE verification_photos SET image_path = ? WHERE id = ?", newPath, photoId);
        String oldPath = (String) ph.get("image_path");
        afterCommit(() -> files.delete(oldPath));

        Map<String, Object> plan = jdbc.queryForMap("SELECT title, party_id FROM plans WHERE id = ?", planId);
        String nickname = nickname(userId);
        for (Long voter : jdbc.queryForList("SELECT voter_id FROM verification_votes WHERE verification_id = ? "
                + "AND is_active = TRUE", Long.class, ((Number) ph.get("verification_id")).longValue())) {
            notifications.notify(voter, NotificationService.PHOTO_ADDED, "인증 사진 변경",
                    nickname + "님이 '" + plan.get("title") + "' 인증 사진을 바꿨어요", planId, toLong(plan.get("party_id")));
        }
        return reader.one(planId, userId, true);
    }

    /** 내 사진이고, 투표 중이고, 올린 지 10분이 안 지났는지 확인하고 잠금 */
    private Map<String, Object> lockEditablePhoto(long userId, long planId, long photoId) {
        Map<String, Object> plan = lockOwnPlan(userId, planId);
        if (!"VOTING".equals(plan.get("status"))) throw ApiException.conflict("결과가 확정된 인증의 사진은 바꿀 수 없어요");
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT p.id, p.verification_id, p.image_path, p.uploaded_at "
                + "FROM verification_photos p JOIN verifications v ON v.id = p.verification_id "
                + "WHERE p.id = ? AND v.plan_id = ? AND v.finalized_at IS NULL FOR UPDATE", photoId, planId);
        if (rows.isEmpty()) throw ApiException.notFound("사진을 찾을 수 없어요");
        LocalDateTime until = Jdbc.dateTime(rows.get(0).get("uploaded_at")).plusMinutes(TimeRule.PHOTO_EDIT_MINUTES);
        if (!TimeRule.now().isBefore(until)) {
            throw ApiException.conflict("사진은 올린 뒤 " + TimeRule.PHOTO_EDIT_MINUTES + "분 안에만 바꾸거나 지울 수 있어요");
        }
        return rows.get(0);
    }

    /** DB 커밋이 끝난 뒤에 파일 삭제 (롤백되면 파일은 남김) */
    private static void afterCommit(Runnable r) {
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    r.run();
                }
            });
        } else {
            r.run();
        }
    }

    public PlanDto get(long viewerId, long planId) {
        PlanDto dto = reader.one(planId, viewerId, true);
        if (dto.userId() != viewerId) {
            Long mine = Jdbc.longOrNull(jdbc, "SELECT party_id FROM party_members WHERE user_id = ?", viewerId);
            Long theirs = Jdbc.longOrNull(jdbc, "SELECT party_id FROM party_members WHERE user_id = ?", dto.userId());
            boolean voter = Jdbc.count(jdbc, "SELECT COUNT(*) FROM verification_votes vv JOIN verifications v "
                    + "ON v.id = vv.verification_id WHERE v.plan_id = ? AND vv.voter_id = ?", planId, viewerId) > 0;
            if (!voter && (mine == null || !mine.equals(theirs))) throw ApiException.forbidden("같은 파티원의 인증만 볼 수 있어요");
        }
        return dto;
    }

    // ------------------------------------------------------------------ 투표

    @Transactional
    public PlanDto vote(long voterId, long planId, boolean approve) {
        Map<String, Object> v = reader.latestVerification(planId);
        if (v == null) throw ApiException.notFound("아직 인증이 제출되지 않았어요");
        long verificationId = ((Number) v.get("id")).longValue();
        // 같은 인증에 동시에 투표해도 집계가 꼬이지 않게 잠금
        v = jdbc.queryForMap("SELECT * FROM verifications WHERE id = ? FOR UPDATE", verificationId);
        Map<String, Object> plan = jdbc.queryForMap("SELECT user_id, title, party_id FROM plans WHERE id = ?", planId);
        long ownerId = ((Number) plan.get("user_id")).longValue();
        if (ownerId == voterId) throw ApiException.forbidden("내 인증에는 투표할 수 없어요");
        if (v.get("finalized_at") != null) throw ApiException.conflict("이미 결과가 확정돼서 투표를 바꿀 수 없어요");
        LocalDateTime deadline = Jdbc.dateTime(v.get("vote_deadline"));
        if (deadline != null && !TimeRule.now().isBefore(deadline)) throw ApiException.conflict("투표는 자정까지만 할 수 있어요");

        List<Map<String, Object>> mine = jdbc.queryForList("SELECT vote, is_active FROM verification_votes "
                + "WHERE verification_id = ? AND voter_id = ?", verificationId, voterId);
        if (mine.isEmpty()) throw ApiException.forbidden("이 인증에 투표할 수 있는 파티원이 아니에요 (인증 뒤에 들어온 경우 포함)");
        if (!Boolean.TRUE.equals(asBool(mine.get(0).get("is_active")))) throw ApiException.forbidden("파티를 나가서 투표권이 없어요");

        String before = (String) mine.get(0).get("vote");
        String after = approve ? "APPROVE" : "REJECT";
        if (after.equals(before)) return reader.one(planId, voterId, true);

        Timestamp now = Timestamp.valueOf(TimeRule.now());
        jdbc.update("UPDATE verification_votes SET vote = ?, voted_at = ?, change_count = change_count + ? "
                + "WHERE verification_id = ? AND voter_id = ?", after, now, before == null ? 0 : 1, verificationId, voterId);
        jdbc.update("INSERT INTO vote_logs (verification_id, voter_id, action, from_vote, to_vote, created_at) "
                + "VALUES (?, ?, ?, ?, ?, ?)", verificationId, voterId, before == null ? "CAST" : "CHANGE", before, after, now);
        refreshCounts(verificationId, now);

        // 미인정을 누를 때마다 본인에게 알림 (누가 눌렀는지는 밝히지 않음) → 23:30 전이면 사진을 보탤 수 있음
        if (!approve) {
            notifications.notify(ownerId, NotificationService.VOTE_RECEIVED, "미인정 표를 받았어요",
                    "'" + plan.get("title") + "' 인증에 미인정 표가 있어요. 23:30 전까지 사진을 더 올릴 수 있어요",
                    planId, toLong(plan.get("party_id")));
        }
        return reader.one(planId, voterId, true);
    }

    /** 현재 활성 표로 집계 숫자를 다시 계산 (확정 전 진행 상황용). 모두 투표하면 all_voted_at 기록 */
    private void refreshCounts(long verificationId, Timestamp now) {
        Map<String, Object> c = jdbc.queryForMap("SELECT COUNT(*) AS voters, "
                + "COALESCE(SUM(vote = 'APPROVE'), 0) AS approves, COALESCE(SUM(vote = 'REJECT'), 0) AS rejects, "
                + "COALESCE(SUM(vote IS NOT NULL), 0) AS voted "
                + "FROM verification_votes WHERE verification_id = ? AND is_active = TRUE", verificationId);
        int voters = ((Number) c.get("voters")).intValue();
        int voted = ((Number) c.get("voted")).intValue();
        jdbc.update("UPDATE verifications SET voter_count = ?, approve_count = ?, reject_count = ?, "
                        + "all_voted_at = CASE WHEN ? > 0 AND ? = ? THEN COALESCE(all_voted_at, ?) ELSE NULL END WHERE id = ?",
                voters, ((Number) c.get("approves")).intValue(), ((Number) c.get("rejects")).intValue(),
                voters, voted, voters, now, verificationId);
    }

    // ------------------------------------------------------------------ 자정 확정

    /** 투표 마감이 지난 인증을 모두 확정. 한 건씩 따로 커밋하므로 중간에 실패해도 나머지는 진행 */
    public int finalizeDue() {
        List<Long> due = jdbc.queryForList("SELECT id FROM verifications WHERE finalized_at IS NULL "
                + "AND vote_deadline <= ? ORDER BY vote_deadline, id", Long.class, Timestamp.valueOf(TimeRule.now()));
        int done = 0;
        for (Long id : due) {
            try {
                Boolean ok = tx.execute(status -> finalizeOne(id));
                if (Boolean.TRUE.equals(ok)) done++;
            } catch (Exception e) {
                log.error("인증 {} 확정 실패", id, e);
            }
        }
        return done;
    }

    private boolean finalizeOne(long verificationId) {
        Map<String, Object> v = jdbc.queryForMap("SELECT * FROM verifications WHERE id = ? FOR UPDATE", verificationId);
        if (v.get("finalized_at") != null) return false;
        long planId = ((Number) v.get("plan_id")).longValue();
        Map<String, Object> plan = jdbc.queryForMap("SELECT user_id, title, party_id, status FROM plans WHERE id = ? FOR UPDATE", planId);
        long ownerId = ((Number) plan.get("user_id")).longValue();
        Timestamp now = Timestamp.valueOf(TimeRule.now());

        refreshCounts(verificationId, now);
        Map<String, Object> c = jdbc.queryForMap("SELECT approve_count, reject_count, voter_count FROM verifications WHERE id = ?", verificationId);
        int approves = ((Number) c.get("approve_count")).intValue();
        int rejects = ((Number) c.get("reject_count")).intValue();
        int voters = ((Number) c.get("voter_count")).intValue();
        boolean ok = LevelRule.approved(approves, rejects);
        String result = ok ? "APPROVED" : "REJECTED";
        String reason = voters == 0 ? "NO_VOTERS" : (approves + rejects == 0 ? "NO_VOTES" : "MIDNIGHT_TALLY");

        jdbc.update("UPDATE verifications SET finalized_at = ?, confirm_at = ?, result = ?, finalize_reason = ? WHERE id = ?",
                now, now, result, reason, verificationId);
        jdbc.update("UPDATE plans SET status = ? WHERE id = ?", result, planId);

        // 포인트는 일정당 한 번만 (plan_id UNIQUE → 두 번째 INSERT 는 무시)
        int points = ok ? LevelRule.PLAN_POINT : -LevelRule.FAIL_PENALTY;
        jdbc.update("INSERT IGNORE INTO point_events (user_id, plan_id, party_id, event_type, points, description, created_at) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)", ownerId, planId, toLong(plan.get("party_id")),
                ok ? "PLAN_APPROVED" : "PLAN_REJECTED", points, "인정 " + approves + " / 미인정 " + rejects, now);

        String title = (String) plan.get("title");
        String body = ok
                ? "'" + title + "' 인정! +" + LevelRule.PLAN_POINT + "pt (인정 " + approves + " · 미인정 " + rejects + ")"
                : "'" + title + "' 미수행 처리 −" + LevelRule.FAIL_PENALTY + "pt (인정 " + approves + " · 미인정 " + rejects + ")";
        notifications.notify(ownerId, NotificationService.VERIFY_RESULT, ok ? "인증 인정" : "인증 미인정", body,
                planId, toLong(plan.get("party_id")));
        return true;
    }

    /** 날짜가 지났는데 인증하지 않은 일정 → MISSED (포인트 0) */
    @Transactional
    public int markMissed() {
        LocalDate today = TimeRule.today();
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT id, user_id, title, party_id FROM plans "
                + "WHERE status = 'TODO' AND plan_date < ? FOR UPDATE", Date.valueOf(today));
        for (Map<String, Object> r : rows) {
            long planId = ((Number) r.get("id")).longValue();
            jdbc.update("UPDATE plans SET status = 'MISSED' WHERE id = ? AND status = 'TODO'", planId);
            notifications.notify(((Number) r.get("user_id")).longValue(), NotificationService.PLAN_MISSED, "미수행 일정",
                    "'" + r.get("title") + "' 일정을 인증하지 않아 미수행으로 기록됐어요", planId, toLong(r.get("party_id")));
        }
        return rows.size();
    }

    /** 23:00, 아직 투표하지 않은 사람에게 알림 (한 인증에 한 번) */
    @Transactional
    public int remindVoters() {
        LocalDateTime now = TimeRule.now();
        List<Map<String, Object>> due = jdbc.queryForList("SELECT v.id, v.plan_id, pl.title, pl.party_id FROM verifications v "
                        + "JOIN plans pl ON pl.id = v.plan_id WHERE v.finalized_at IS NULL AND v.reminded_at IS NULL "
                        + "AND v.vote_deadline > ? AND v.vote_deadline <= ? FOR UPDATE",
                Timestamp.valueOf(now), Timestamp.valueOf(now.plusHours(2)));
        for (Map<String, Object> v : due) {
            long verificationId = ((Number) v.get("id")).longValue();
            List<Long> waiting = jdbc.queryForList("SELECT voter_id FROM verification_votes WHERE verification_id = ? "
                    + "AND is_active = TRUE AND vote IS NULL", Long.class, verificationId);
            for (Long voter : waiting) {
                notifications.notify(voter, NotificationService.VOTE_REMINDER, "투표 마감 1시간 전",
                        "'" + v.get("title") + "' 인증 투표가 자정에 마감돼요", ((Number) v.get("plan_id")).longValue(),
                        toLong(v.get("party_id")));
            }
            jdbc.update("UPDATE verifications SET reminded_at = ? WHERE id = ?", Timestamp.valueOf(now), verificationId);
        }
        return due.size();
    }

    // ------------------------------------------------------------------ 보조

    private Map<String, Object> lockOwnPlan(long userId, long planId) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT id, user_id, plan_date, title, status, party_id FROM plans WHERE id = ? FOR UPDATE", planId);
        if (rows.isEmpty()) throw ApiException.notFound("일정을 찾을 수 없어요");
        if (((Number) rows.get(0).get("user_id")).longValue() != userId) throw ApiException.forbidden("내 일정만 인증할 수 있어요");
        return rows.get(0);
    }

    private void savePhotos(long verificationId, List<MultipartFile> photos, LocalDateTime now) {
        for (MultipartFile f : photos) {
            String path = files.save(f);
            jdbc.update("INSERT INTO verification_photos (verification_id, image_path, uploaded_at) VALUES (?, ?, ?)",
                    verificationId, path, Timestamp.valueOf(now));
        }
    }

    private static List<MultipartFile> nonEmpty(List<MultipartFile> images) {
        List<MultipartFile> out = new ArrayList<>();
        if (images != null) for (MultipartFile f : images) if (f != null && !f.isEmpty()) out.add(f);
        return out;
    }

    private String nickname(long userId) {
        return jdbc.queryForObject("SELECT nickname FROM users WHERE id = ?", String.class, userId);
    }

    private static Long toLong(Object o) {
        return o == null ? null : ((Number) o).longValue();
    }

    private static Boolean asBool(Object o) {
        if (o instanceof Boolean b) return b;
        if (o instanceof Number n) return n.intValue() != 0;
        return Boolean.FALSE;
    }

    private static String cut(String s) {
        if (s == null || s.isBlank()) return null;
        String t = s.trim();
        return t.length() <= COMMENT_MAX ? t : t.substring(0, COMMENT_MAX);
    }
}
