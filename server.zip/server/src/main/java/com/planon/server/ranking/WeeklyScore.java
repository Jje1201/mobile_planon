package com.planon.server.ranking;

import com.planon.server.common.LevelRule;

/** 한 사람의 한 주 성적과 경로별 경험치 */
public class WeeklyScore {
    public final long userId;
    public final String nickname;
    public final int characterId;
    public final int totalExp;
    public final int points;
    public final int doneCount;
    public final int planCount;
    public final boolean reviewOk;
    public int rank;
    public boolean partyGoalOk;

    public WeeklyScore(StatsRepository.MemberRow m, int points, int doneCount, int planCount, boolean reviewOk) {
        this.userId = m.userId();
        this.nickname = m.nickname();
        this.characterId = m.characterId();
        this.totalExp = m.totalExp();
        this.points = points;
        this.doneCount = doneCount;
        this.planCount = planCount;
        this.reviewOk = reviewOk;
    }

    /** 주간 포인트가 0 이하이면 모든 경로 0 (아무것도 안 하고 경험치를 받는 것 방지) */
    private boolean active() {
        return points > 0;
    }

    public int rankExp(int memberCount) {
        return active() ? LevelRule.rankExp(rank, memberCount) : 0;
    }

    public int completionExp() {
        return active() ? LevelRule.completionExp(doneCount, planCount) : 0;
    }

    public int reviewExp() {
        return active() && reviewOk ? LevelRule.REVIEW_EXP : 0;
    }

    public int partyGoalExp() {
        return active() && partyGoalOk ? LevelRule.PARTY_GOAL_EXP : 0;
    }

    public int totalExpGain(int memberCount) {
        return rankExp(memberCount) + completionExp() + reviewExp() + partyGoalExp();
    }
}
