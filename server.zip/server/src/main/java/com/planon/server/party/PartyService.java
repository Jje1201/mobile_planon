package com.planon.server.party;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.MemberDto;
import com.planon.server.common.Dtos.PartyDto;
import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import com.planon.server.notification.NotificationService;
import com.planon.server.ranking.StatsRepository;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

/**
 * 파티: 한 사람은 파티 하나에만 (party_members.user_id 가 PK), 파티당 최대 4명.
 * 일정·포인트는 만든 파티(party_id)에 묶여 있어서, 파티를 나가고 새 파티에 들어가면 새 파티 기록은 0부터 시작합니다.
 * (레벨·경험치·업적은 개인 기록이라 그대로 유지)
 * 파티장이 파티를 삭제하면 기록이 참조하고 있어 행은 남기고 deleted_at 만 표시합니다.
 */
@Service
public class PartyService {

    public static final int MAX_MEMBERS = 4;
    private static final String CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 0, O, 1, I 제외
    private static final int CODE_LENGTH = 6;
    private static final int NAME_MAX = 20;

    private final JdbcTemplate jdbc;
    private final NotificationService notifications;
    private final SecureRandom random = new SecureRandom();

    public PartyService(JdbcTemplate jdbc, NotificationService notifications) {
        this.jdbc = jdbc;
        this.notifications = notifications;
    }

    public Long partyIdOf(long userId) {
        return Jdbc.longOrNull(jdbc, "SELECT party_id FROM party_members WHERE user_id = ?", userId);
    }

    @Transactional
    public PartyDto create(long userId, String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.length() > NAME_MAX) throw ApiException.badRequest("파티 이름은 1~" + NAME_MAX + "자로 입력해 주세요");
        if (partyIdOf(userId) != null) throw ApiException.conflict("이미 파티에 속해 있어요. 한 사람은 파티 하나만 가입할 수 있어요");
        long partyId = 0;
        for (int attempt = 0; attempt < 10 && partyId == 0; attempt++) {
            try {
                partyId = Jdbc.insert(jdbc, "INSERT INTO parties (name, invite_code, leader_id) VALUES (?, ?, ?)",
                        n, newCode(), userId);
            } catch (DuplicateKeyException ignored) {
                // 초대 코드가 겹치면 다시 만듦
            }
        }
        if (partyId == 0) throw new IllegalStateException("초대 코드를 만들지 못했습니다");
        try {
            jdbc.update("INSERT INTO party_members (user_id, party_id, character_id) VALUES (?, ?, NULL)", userId, partyId);
        } catch (DuplicateKeyException e) {
            throw ApiException.conflict("이미 파티에 속해 있어요");
        }
        adoptSoloPlans(userId, partyId);
        return get(partyId);
    }

    /** 파티 없이 만들어 둔 앞으로의 일정(TODO)은 새 파티로 가져감. 다른 파티의 일정은 건드리지 않음 */
    private void adoptSoloPlans(long userId, long partyId) {
        jdbc.update("UPDATE plans SET party_id = ? WHERE user_id = ? AND party_id IS NULL AND status = 'TODO' "
                + "AND plan_date >= ?", partyId, userId, Date.valueOf(TimeRule.today()));
    }

    /** 파티를 떠날 때 그 파티에서 만든 앞으로의 일정(아직 인증 전)은 지움 → 새 파티로 넘어가지 않음 */
    private void dropFutureTodos(long userId, long partyId) {
        Date today = Date.valueOf(TimeRule.today());
        jdbc.update("DELETE FROM notifications WHERE plan_id IN (SELECT id FROM plans WHERE user_id = ? AND party_id = ? "
                + "AND status = 'TODO' AND plan_date >= ?)", userId, partyId, today);
        jdbc.update("DELETE FROM plans WHERE user_id = ? AND party_id = ? AND status = 'TODO' AND plan_date >= ?",
                userId, partyId, today);
    }

    @Transactional
    public PartyDto join(long userId, String inviteCode) {
        String code = inviteCode == null ? "" : inviteCode.trim().toUpperCase();
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT id, name FROM parties WHERE invite_code = ? AND deleted_at IS NULL FOR UPDATE", code);
        if (rows.isEmpty()) throw ApiException.notFound("초대 코드에 맞는 파티가 없어요");
        long partyId = ((Number) rows.get(0).get("id")).longValue();
        String partyName = (String) rows.get(0).get("name");
        Long current = partyIdOf(userId);
        if (current != null) {
            if (current == partyId) throw ApiException.conflict("이미 이 파티의 파티원이에요");
            throw ApiException.conflict("이미 다른 파티에 속해 있어요. 나간 뒤에 가입할 수 있어요");
        }
        int size = Jdbc.count(jdbc, "SELECT COUNT(*) FROM party_members WHERE party_id = ?", partyId);
        if (size >= MAX_MEMBERS) throw ApiException.conflict("파티 정원(" + MAX_MEMBERS + "명)이 다 찼어요");
        try {
            jdbc.update("INSERT INTO party_members (user_id, party_id, character_id) VALUES (?, ?, NULL)", userId, partyId);
        } catch (DuplicateKeyException e) {
            throw ApiException.conflict("이미 파티에 속해 있어요");
        }
        if (size == 0) jdbc.update("UPDATE parties SET leader_id = ? WHERE id = ?", userId, partyId);
        adoptSoloPlans(userId, partyId);
        String nickname = nickname(userId);
        for (Long other : memberIds(partyId)) {
            if (other != userId) {
                notifications.notify(other, NotificationService.PARTY_JOINED, "새 파티원",
                        nickname + "님이 " + partyName + "에 들어왔어요", null, partyId);
            }
        }
        return get(partyId);
    }

    /** 내 파티 (없으면 null) */
    public PartyDto mine(long userId) {
        Long partyId = partyIdOf(userId);
        return partyId == null ? null : get(partyId);
    }

    public PartyDto get(long partyId) {
        Map<String, Object> p = jdbc.queryForMap("SELECT id, name, invite_code, leader_id FROM parties WHERE id = ?", partyId);
        long leaderId = ((Number) p.get("leader_id")).longValue();
        Date today = Date.valueOf(TimeRule.today());
        List<MemberDto> members = jdbc.query(
                "SELECT u.id, u.nickname, u.total_exp, pm.character_id, "
                        + "(SELECT COUNT(*) FROM plans pl WHERE pl.user_id = u.id AND pl.party_id = pm.party_id "
                        + "  AND pl.plan_date = ?) AS today_total, "
                        + "(SELECT COUNT(*) FROM plans pl WHERE pl.user_id = u.id AND pl.party_id = pm.party_id "
                        + "  AND pl.plan_date = ? AND pl.status IN ('VOTING', 'APPROVED')) AS today_done "
                        + "FROM party_members pm JOIN users u ON u.id = pm.user_id "
                        + "WHERE pm.party_id = ? ORDER BY pm.joined_at, u.id",
                (rs, i) -> new MemberDto(rs.getLong("id"), rs.getString("nickname"),
                        StatsRepository.parseCharacter(rs.getString("character_id")), rs.getInt("total_exp"),
                        rs.getLong("id") == leaderId, rs.getInt("today_total"), rs.getInt("today_done")),
                today, today, partyId);
        return new PartyDto(partyId, (String) p.get("name"), (String) p.get("invite_code"), leaderId, members);
    }

    @Transactional
    public void leave(long userId) {
        Long partyId = partyIdOf(userId);
        if (partyId == null) throw ApiException.notFound("속한 파티가 없어요");
        jdbc.queryForList("SELECT id FROM parties WHERE id = ? FOR UPDATE", partyId);
        String nickname = nickname(userId);
        Timestamp now = Timestamp.valueOf(TimeRule.now());

        // 아직 확정되지 않은 인증의 투표권 회수 (나간 사람의 표는 세지 않음)
        List<Long> pending = jdbc.queryForList("SELECT vv.verification_id FROM verification_votes vv "
                + "JOIN verifications v ON v.id = vv.verification_id "
                + "WHERE vv.voter_id = ? AND vv.is_active = TRUE AND v.finalized_at IS NULL", Long.class, userId);
        for (Long verificationId : pending) {
            jdbc.update("INSERT INTO vote_logs (verification_id, voter_id, action, from_vote, to_vote, created_at) "
                    + "SELECT verification_id, voter_id, 'REMOVED', vote, NULL, ? FROM verification_votes "
                    + "WHERE verification_id = ? AND voter_id = ?", now, verificationId, userId);
            jdbc.update("UPDATE verification_votes SET is_active = FALSE WHERE verification_id = ? AND voter_id = ?",
                    verificationId, userId);
        }

        dropFutureTodos(userId, partyId);
        jdbc.update("DELETE FROM party_members WHERE user_id = ?", userId);
        List<Long> rest = memberIds(partyId);
        Long leaderId = Jdbc.longOrNull(jdbc, "SELECT leader_id FROM parties WHERE id = ?", partyId);
        if (leaderId != null && leaderId == userId && !rest.isEmpty()) {
            jdbc.update("UPDATE parties SET leader_id = ? WHERE id = ?", rest.get(0), partyId);
        }
        for (Long other : rest) {
            notifications.notify(other, NotificationService.PARTY_LEFT, "파티원이 나갔어요",
                    nickname + "님이 파티를 떠났어요", null, partyId);
        }
    }

    /**
     * 파티 삭제 (파티장만). 파티원 모두 파티에서 빠지고, 각자 그 파티에서 만든 앞으로의 일정은 지워집니다.
     * 오늘 이미 제출한 인증은 자정에 원래대로 확정되도록 투표권을 그대로 둡니다.
     */
    @Transactional
    public void deleteParty(long userId) {
        Long partyId = partyIdOf(userId);
        if (partyId == null) throw ApiException.notFound("속한 파티가 없어요");
        Map<String, Object> p = jdbc.queryForMap("SELECT name, leader_id FROM parties WHERE id = ? FOR UPDATE", partyId);
        if (((Number) p.get("leader_id")).longValue() != userId) throw ApiException.forbidden("파티장만 파티를 삭제할 수 있어요");
        String partyName = (String) p.get("name");

        List<Long> members = memberIds(partyId);
        for (Long member : members) dropFutureTodos(member, partyId);
        jdbc.update("DELETE FROM party_members WHERE party_id = ?", partyId);
        // 초대 코드는 다시 쓰일 수 있게 비워 둠 (UNIQUE 라서 삭제 표시용 값으로 바꿈)
        jdbc.update("UPDATE parties SET deleted_at = ?, invite_code = ? WHERE id = ?",
                Timestamp.valueOf(TimeRule.now()), "DELETED-" + partyId, partyId);
        for (Long member : members) {
            if (member == userId) continue;
            notifications.notify(member, NotificationService.PARTY_DELETED, "파티가 삭제됐어요",
                    "파티장이 '" + partyName + "' 파티를 삭제했어요. 새 파티를 만들거나 다른 파티에 참여해 주세요", null, partyId);
        }
    }

    @Transactional
    public void selectCharacter(long userId, int characterId) {
        if (characterId < 1 || characterId > 4) throw ApiException.badRequest("캐릭터는 1~4번 중에서 골라 주세요");
        Long partyId = partyIdOf(userId);
        if (partyId == null) throw ApiException.badRequest("파티에 들어간 뒤에 캐릭터를 고를 수 있어요");
        jdbc.queryForList("SELECT id FROM parties WHERE id = ? FOR UPDATE", partyId);
        int taken = Jdbc.count(jdbc, "SELECT COUNT(*) FROM party_members WHERE party_id = ? AND character_id = ? "
                + "AND user_id <> ?", partyId, String.valueOf(characterId), userId);
        if (taken > 0) throw ApiException.conflict("다른 파티원이 이미 고른 캐릭터예요");
        try {
            jdbc.update("UPDATE party_members SET character_id = ? WHERE user_id = ?", String.valueOf(characterId), userId);
        } catch (DuplicateKeyException e) {
            throw ApiException.conflict("다른 파티원이 이미 고른 캐릭터예요");
        }
    }

    public List<Long> memberIds(long partyId) {
        return jdbc.queryForList("SELECT user_id FROM party_members WHERE party_id = ? ORDER BY joined_at, user_id",
                Long.class, partyId);
    }

    private String nickname(long userId) {
        return jdbc.queryForObject("SELECT nickname FROM users WHERE id = ?", String.class, userId);
    }

    private String newCode() {
        StringBuilder sb = new StringBuilder(CODE_LENGTH);
        for (int i = 0; i < CODE_LENGTH; i++) sb.append(CODE_CHARS.charAt(random.nextInt(CODE_CHARS.length())));
        return sb.toString();
    }
}
