package com.planon.server.ranking;

import com.planon.server.common.LevelRule;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 한 파티의 한 주 성적을 계산합니다 (결산과 실시간 순위가 같은 코드를 씀).
 * 순위: 주간 포인트 내림차순, 같으면 인정 일정 수 내림차순. 그래도 같으면 같은 순위(1, 1, 3 …).
 */
@Component
public class RankingCalculator {

    private final StatsRepository stats;

    public RankingCalculator(StatsRepository stats) {
        this.stats = stats;
    }

    public List<StatsRepository.MemberRow> members(long partyId) {
        return stats.members(partyId);
    }

    public List<WeeklyScore> compute(long partyId, LocalDate weekStart) {
        return compute(partyId, stats.members(partyId), weekStart);
    }

    /** partyId: 이 파티에서 얻은 기록만 셈 (파티가 없으면 null) */
    public List<WeeklyScore> compute(Long partyId, List<StatsRepository.MemberRow> members, LocalDate weekStart) {
        LocalDate end = weekStart.plusDays(7);
        List<WeeklyScore> scores = new ArrayList<>();
        int partyDone = 0;
        int partyPlans = 0;
        for (StatsRepository.MemberRow m : members) {
            int points = stats.points(m.userId(), partyId, weekStart, end);
            int done = stats.approvedCount(m.userId(), partyId, weekStart, end);
            int plans = stats.finishedCount(m.userId(), partyId, weekStart, end);
            // 혼자인 파티는 검토할 인증이 없으므로 검토 참여 경험치 없음
            boolean reviewOk = members.size() > 1 && stats.missedVotes(m.userId(), partyId, weekStart, end) == 0;
            scores.add(new WeeklyScore(m, points, done, plans, reviewOk));
            partyDone += done;
            partyPlans += plans;
        }
        scores.sort(Comparator.comparingInt((WeeklyScore s) -> s.points).reversed()
                .thenComparing(Comparator.comparingInt((WeeklyScore s) -> s.doneCount).reversed()));
        boolean partyGoal = members.size() > 1 && partyPlans > 0
                && partyDone >= Math.ceil(partyPlans * LevelRule.PARTY_GOAL_RATE);
        for (int i = 0; i < scores.size(); i++) {
            WeeklyScore s = scores.get(i);
            if (i > 0 && sameScore(scores.get(i - 1), s)) s.rank = scores.get(i - 1).rank;
            else s.rank = i + 1;
            s.partyGoalOk = partyGoal;
        }
        return scores;
    }

    private static boolean sameScore(WeeklyScore a, WeeklyScore b) {
        return a.points == b.points && a.doneCount == b.doneCount;
    }
}
