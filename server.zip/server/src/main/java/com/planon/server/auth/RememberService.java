package com.planon.server.auth;

import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

/**
 * "이 기기에 로그인 정보 저장" 토큰.
 * - 원문(32바이트 난수)은 휴대폰에만 저장, 서버에는 SHA-256 해시만
 * - 마지막으로 쓴 날부터 60일 동안 유효 (쓸 때마다 연장)
 * - 휴대폰 목록에서 계정을 지우면 서버에서도 폐기
 */
@Service
public class RememberService {

    public static final int VALID_DAYS = 60;
    private static final int MAX_PER_USER = 10;

    private final JdbcTemplate jdbc;
    private final SecureRandom random = new SecureRandom();

    public RememberService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** 새 토큰 발급 (원문 반환) */
    public String issue(long userId, String deviceName) {
        byte[] raw = new byte[32];
        random.nextBytes(raw);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
        Timestamp now = Timestamp.valueOf(TimeRule.now());
        jdbc.update("INSERT INTO remember_tokens (user_id, token_hash, device_name, created_at, last_used_at, expires_at) "
                        + "VALUES (?, ?, ?, ?, ?, ?)", userId, hash(token), cut(deviceName), now, now,
                Timestamp.valueOf(TimeRule.now().plusDays(VALID_DAYS)));
        // 한 사람이 너무 많이 쌓지 않게 오래된 것부터 폐기
        jdbc.update("UPDATE remember_tokens SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL AND id NOT IN "
                + "(SELECT id FROM (SELECT id FROM remember_tokens WHERE user_id = ? AND revoked_at IS NULL "
                + "ORDER BY id DESC LIMIT " + MAX_PER_USER + ") keep)", now, userId, userId);
        return token;
    }

    /** 유효하면 회원 id, 아니면 null. 사용하면 유효기간 연장 */
    public Long use(String token) {
        if (token == null || token.isBlank()) return null;
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT r.id, r.user_id FROM remember_tokens r "
                + "JOIN users u ON u.id = r.user_id WHERE r.token_hash = ? AND r.revoked_at IS NULL "
                + "AND r.expires_at > ? AND u.deleted_at IS NULL", hash(token.trim()), Timestamp.valueOf(TimeRule.now()));
        if (rows.isEmpty()) return null;
        long id = ((Number) rows.get(0).get("id")).longValue();
        jdbc.update("UPDATE remember_tokens SET last_used_at = ?, expires_at = ? WHERE id = ?",
                Timestamp.valueOf(TimeRule.now()), Timestamp.valueOf(TimeRule.now().plusDays(VALID_DAYS)), id);
        return ((Number) rows.get(0).get("user_id")).longValue();
    }

    public void revoke(String token) {
        if (token == null || token.isBlank()) return;
        jdbc.update("UPDATE remember_tokens SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL",
                Timestamp.valueOf(TimeRule.now()), hash(token.trim()));
    }

    public int activeCount(long userId) {
        return Jdbc.count(jdbc, "SELECT COUNT(*) FROM remember_tokens WHERE user_id = ? AND revoked_at IS NULL", userId);
    }

    private static String hash(String token) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(md.digest(token.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static String cut(String s) {
        if (s == null || s.isBlank()) return null;
        String t = s.trim();
        return t.length() <= 100 ? t : t.substring(0, 100);
    }
}
