package com.planon.server.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.nio.charset.StandardCharsets;

/**
 * "Authorization: Bearer {token}" 을 확인해 요청 속성 userId 에 넣습니다.
 * 컨트롤러는 @RequestAttribute("userId") long userId 로 받습니다.
 */
@Component
public class AuthInterceptor implements HandlerInterceptor {

    public static final String USER_ID = "userId";

    private final TokenService tokens;
    private final JdbcTemplate jdbc;

    public AuthInterceptor(TokenService tokens, JdbcTemplate jdbc) {
        this.tokens = tokens;
        this.jdbc = jdbc;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) return true;

        String header = request.getHeader("Authorization");
        String token = header != null && header.startsWith("Bearer ") ? header.substring(7).trim() : null;
        long userId = tokens.verify(token);
        if (userId > 0) {
            Integer alive = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM users WHERE id = ? AND deleted_at IS NULL", Integer.class, userId);
            if (alive != null && alive > 0) {
                request.setAttribute(USER_ID, userId);
                return true;
            }
        }
        response.setStatus(401);
        response.setContentType("application/json;charset=UTF-8");
        response.getOutputStream().write("{\"message\":\"로그인이 필요해요\"}".getBytes(StandardCharsets.UTF_8));
        return false;
    }
}
