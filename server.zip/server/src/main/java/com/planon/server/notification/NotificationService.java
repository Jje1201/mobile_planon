package com.planon.server.notification;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.NotificationDto;
import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

/**
 * 알림함(notifications 테이블) + 푸시.
 * 알림은 그 사건을 처리하는 트랜잭션 안에서 저장되고, 푸시는 커밋된 뒤에 나갑니다.
 */
@Service
public class NotificationService {

    // V1 notifications.type ENUM 값
    public static final String VOTE_REQUEST = "VOTE_REQUEST";
    public static final String VOTE_REMINDER = "VOTE_REMINDER";
    public static final String VOTE_RECEIVED = "VOTE_RECEIVED";
    public static final String VERIFY_RESULT = "VERIFY_RESULT";
    public static final String PLAN_MISSED = "PLAN_MISSED";
    public static final String PHOTO_ADDED = "VERIFICATION_PHOTO_ADDED";
    public static final String WEEKLY_SETTLED = "WEEKLY_SETTLED";
    public static final String LEVEL_UP = "LEVEL_UP";
    public static final String CHARACTER_GROWN = "CHARACTER_GROWN";
    public static final String PARTY_JOINED = "PARTY_JOINED";
    public static final String PARTY_LEFT = "PARTY_LEFT";
    public static final String ACHIEVEMENT_UNLOCKED = "ACHIEVEMENT_UNLOCKED";
    public static final String MONTHLY_RANKING = "MONTHLY_RANKING";
    public static final String PARTY_DELETED = "PARTY_DELETED";

    private static final int KEEP_DAYS = 90;
    /** 회원별로 남겨 두는 알림 수 (넘으면 오래된 것부터 삭제) */
    public static final int MAX_PER_USER = 30;

    private final JdbcTemplate jdbc;
    private final PushService push;

    public NotificationService(JdbcTemplate jdbc, PushService push) {
        this.jdbc = jdbc;
        this.push = push;
    }

    public void notify(long userId, String type, String title, String body, Long planId, Long partyId) {
        notify(userId, type, title, body, planId, partyId, null);
    }

    /** 업적 알림은 achievement_code 도 함께 저장 */
    public void notify(long userId, String type, String title, String body, Long planId, Long partyId,
                       String achievementCode) {
        jdbc.update("INSERT INTO notifications (user_id, type, title, body, plan_id, party_id, achievement_code, "
                        + "is_read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, FALSE, ?)",
                userId, type, cut(title, 100), cut(body, 500), planId, partyId, achievementCode,
                Timestamp.valueOf(TimeRule.now()));
        trim(userId);
        push.sendAfterCommit(userId, type, title, body, planId);
    }

    /** 최근 30개만 남기고 오래된 알림 삭제 (서버 DB 가 계속 쌓이지 않게) */
    public void trim(long userId) {
        Long cutoff = Jdbc.longOrNull(jdbc, "SELECT id FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 1 OFFSET "
                + (MAX_PER_USER - 1), userId);
        if (cutoff != null) jdbc.update("DELETE FROM notifications WHERE user_id = ? AND id < ?", userId, cutoff);
    }

    public List<NotificationDto> list(long userId, int limit) {
        int n = Math.max(1, Math.min(limit, MAX_PER_USER));
        return jdbc.query("SELECT id, type, title, body, plan_id, is_read, created_at FROM notifications "
                        + "WHERE user_id = ? ORDER BY id DESC LIMIT " + n,
                (rs, i) -> {
                    long rawPlanId = rs.getLong("plan_id");
                    Long planId = rs.wasNull() ? null : rawPlanId;
                    Timestamp created = rs.getTimestamp("created_at");
                    return new NotificationDto(rs.getLong("id"), rs.getString("type"), rs.getString("title"),
                            rs.getString("body"), planId, rs.getBoolean("is_read"),
                            created == null ? null : TimeRule.minute(created.toLocalDateTime()));
                }, userId);
    }

    public int unreadCount(long userId) {
        Integer n = jdbc.queryForObject(
                "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = FALSE", Integer.class, userId);
        return n == null ? 0 : n;
    }

    public void markRead(long userId, long id) {
        int n = jdbc.update("UPDATE notifications SET is_read = TRUE, read_at = ? WHERE id = ? AND user_id = ?",
                Timestamp.valueOf(TimeRule.now()), id, userId);
        if (n == 0) throw ApiException.notFound("알림을 찾을 수 없어요");
    }

    public void markAllRead(long userId) {
        jdbc.update("UPDATE notifications SET is_read = TRUE, read_at = ? WHERE user_id = ? AND is_read = FALSE",
                Timestamp.valueOf(TimeRule.now()), userId);
    }

    public void deleteOld() {
        jdbc.update("DELETE FROM notifications WHERE created_at < ?",
                Timestamp.valueOf(TimeRule.now().minusDays(KEEP_DAYS)));
    }

    public void saveDeviceToken(long userId, String token) {
        if (token == null || token.isBlank()) throw ApiException.badRequest("토큰이 비어 있어요");
        jdbc.update("INSERT INTO device_tokens (user_id, fcm_token) VALUES (?, ?) "
                + "ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), updated_at = CURRENT_TIMESTAMP", userId, token.trim());
    }

    public void deleteDeviceToken(long userId, String token) {
        if (token == null) return;
        jdbc.update("DELETE FROM device_tokens WHERE user_id = ? AND fcm_token = ?", userId, token.trim());
    }

    private static String cut(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }
}
