package com.planon.server;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class TestController {

    @GetMapping("/")
    public String home() {
        return "PLAN:ON 서버 연결 성공!";
    }

    /** 앱·휴대폰 브라우저에서 연결 확인용 (로그인 불필요) */
    @GetMapping("/api/health")
    public Map<String, String> health() {
        return Map.of("status", "ok");
    }
}
