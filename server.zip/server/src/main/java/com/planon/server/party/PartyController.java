package com.planon.server.party;

import com.planon.server.common.Dtos.CharacterRequest;
import com.planon.server.common.Dtos.JoinRequest;
import com.planon.server.common.Dtos.PartyCreateRequest;
import com.planon.server.common.Dtos.PartyDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PartyController {

    private final PartyService parties;

    public PartyController(PartyService parties) {
        this.parties = parties;
    }

    @PostMapping("/api/parties")
    @ResponseStatus(HttpStatus.CREATED)
    public PartyDto create(@RequestAttribute("userId") long userId, @RequestBody PartyCreateRequest body) {
        return parties.create(userId, body.name());
    }

    @PostMapping("/api/parties/join")
    public PartyDto join(@RequestAttribute("userId") long userId, @RequestBody JoinRequest body) {
        return parties.join(userId, body.inviteCode());
    }

    /** 파티가 없으면 204 No Content */
    @GetMapping("/api/parties/my")
    public ResponseEntity<PartyDto> mine(@RequestAttribute("userId") long userId) {
        PartyDto party = parties.mine(userId);
        return party == null ? ResponseEntity.noContent().build() : ResponseEntity.ok(party);
    }

    @DeleteMapping("/api/parties/my/members/me")
    public ResponseEntity<Void> leave(@RequestAttribute("userId") long userId) {
        parties.leave(userId);
        return ResponseEntity.ok().build();
    }

    /** 파티 삭제 (파티장만) */
    @DeleteMapping("/api/parties/my")
    public ResponseEntity<Void> delete(@RequestAttribute("userId") long userId) {
        parties.deleteParty(userId);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/api/parties/my/character")
    public ResponseEntity<Void> character(@RequestAttribute("userId") long userId, @RequestBody CharacterRequest body) {
        parties.selectCharacter(userId, body.characterId());
        return ResponseEntity.ok().build();
    }
}
