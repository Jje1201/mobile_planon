package com.planon.server.achievement;

import com.planon.server.common.Dtos.AchievementDto;
import com.planon.server.common.Dtos.AchievementsResponse;
import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import com.planon.server.notification.NotificationService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 업적 지급과 조회.
 * - 같은 업적·같은 기간(period_key)은 한 번만 (UNIQUE)
 * - 배지와 횟수는 계속 쌓이고, 보상 포인트는 그 업적을 처음 받을 때 한 번만
 * - 보상 포인트는 point_events(ACHIEVEMENT) 한 줄 + user_achievements.point_event_id 로 연결
 */
@Service
public class AchievementService {

    private final JdbcTemplate jdbc;
    private final NotificationService notifications;

    public AchievementService(JdbcTemplate jdbc, NotificationService notifications) {
        this.jdbc = jdbc;
        this.notifications = notifications;
    }

    /** achievements 테이블의 기준값 (없으면 기본값) */
    public int threshold(String code, int fallback) {
        List<Integer> v = jdbc.queryForList("SELECT threshold FROM achievements WHERE code = ?", Integer.class, code);
        return v.isEmpty() || v.get(0) == null ? fallback : v.get(0);
    }

    /**
     * 업적 지급. 반드시 바깥 트랜잭션 안에서 호출 (알림·포인트가 함께 커밋/롤백).
     *
     * @return 새로 받았으면 true (같은 기간에 이미 받았으면 false)
     */
    public boolean award(long userId, String code, String periodKey, Long partyId) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT name, description, reward_points FROM achievements WHERE code = ?", code);
        if (rows.isEmpty()) return false;
        Map<String, Object> a = rows.get(0);
        Timestamp now = Timestamp.valueOf(TimeRule.now());

        int inserted = jdbc.update("INSERT IGNORE INTO user_achievements "
                + "(user_id, achievement_code, party_id, period_key, achieved_at) VALUES (?, ?, ?, ?, ?)",
                userId, code, partyId, periodKey, now);
        if (inserted == 0) return false;
        Long uaId = Jdbc.longOrNull(jdbc, "SELECT id FROM user_achievements WHERE user_id = ? AND achievement_code = ? "
                + "AND period_key = ?", userId, code, periodKey);
        int times = Jdbc.count(jdbc, "SELECT COUNT(*) FROM user_achievements WHERE user_id = ? AND achievement_code = ?",
                userId, code);

        String name = (String) a.get("name");
        int reward = times == 1 ? ((Number) a.get("reward_points")).intValue() : 0;
        if (reward > 0 && uaId != null) {
            long pointId = Jdbc.insert(jdbc, "INSERT INTO point_events (user_id, plan_id, party_id, event_type, points, "
                            + "description, created_at, user_achievement_id) VALUES (?, NULL, ?, 'ACHIEVEMENT', ?, ?, ?, ?)",
                    userId, partyId, reward, "업적 " + name, now, uaId);
            jdbc.update("UPDATE user_achievements SET point_event_id = ? WHERE id = ?", pointId, uaId);
        }

        String body = a.get("description") + (reward > 0 ? " · +" + reward + "P" : "")
                + (times > 1 ? " (" + times + "번째)" : "");
        notifications.notify(userId, NotificationService.ACHIEVEMENT_UNLOCKED, "업적 달성: " + name, body,
                null, partyId, code);
        return true;
    }

    /** 마이페이지: 업적 13개 + 받은 횟수 + 연속 기록. 받기 전 숨김 업적은 "???" */
    public AchievementsResponse list(long userId) {
        Map<String, Object[]> earned = new HashMap<>();
        jdbc.query("SELECT achievement_code, COUNT(*) AS cnt, MIN(achieved_at) AS first_at FROM user_achievements "
                + "WHERE user_id = ? GROUP BY achievement_code", rs -> {
            Timestamp first = rs.getTimestamp("first_at");
            earned.put(rs.getString("achievement_code"), new Object[]{rs.getInt("cnt"),
                    first == null ? null : TimeRule.minute(first.toLocalDateTime())});
        }, userId);

        List<AchievementDto> items = new ArrayList<>();
        jdbc.query("SELECT code, name, description, category, reward_points, is_hidden FROM achievements "
                + "ORDER BY sort_order", rs -> {
            String code = rs.getString("code");
            Object[] e = earned.get(code);
            boolean hidden = rs.getBoolean("is_hidden");
            boolean got = e != null;
            items.add(new AchievementDto(code,
                    hidden && !got ? "???" : rs.getString("name"),
                    hidden && !got ? "숨겨진 업적이에요. 조건을 채우면 공개돼요" : rs.getString("description"),
                    rs.getString("category"), rs.getInt("reward_points"), hidden, got,
                    got ? (Integer) e[0] : 0, got ? (String) e[1] : null));
        });

        List<Map<String, Object>> s = jdbc.queryForList(
                "SELECT clear_streak, best_clear_streak, fail_streak, none_streak FROM user_streaks WHERE user_id = ?", userId);
        int clear = 0, best = 0;
        if (!s.isEmpty()) {
            clear = ((Number) s.get(0).get("clear_streak")).intValue();
            best = ((Number) s.get(0).get("best_clear_streak")).intValue();
        }
        int earnedCount = (int) items.stream().filter(AchievementDto::earned).count();
        return new AchievementsResponse(clear, best, earnedCount, items.size(), items);
    }
}
