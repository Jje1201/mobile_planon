package com.planon.server.notification;

import com.planon.server.common.Dtos.CountResponse;
import com.planon.server.common.Dtos.NotificationDto;
import com.planon.server.common.Dtos.TokenRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class NotificationController {

    private final NotificationService notifications;

    public NotificationController(NotificationService notifications) {
        this.notifications = notifications;
    }

    @GetMapping("/api/notifications")
    public List<NotificationDto> list(@RequestAttribute("userId") long userId,
                                      @RequestParam(defaultValue = "30") int limit) {
        return notifications.list(userId, limit);
    }

    @GetMapping("/api/notifications/unread-count")
    public CountResponse unread(@RequestAttribute("userId") long userId) {
        return new CountResponse(notifications.unreadCount(userId));
    }

    @PatchMapping("/api/notifications/{id}/read")
    public ResponseEntity<Void> read(@RequestAttribute("userId") long userId, @PathVariable long id) {
        notifications.markRead(userId, id);
        return ResponseEntity.ok().build();
    }

    @PatchMapping("/api/notifications/read-all")
    public ResponseEntity<Void> readAll(@RequestAttribute("userId") long userId) {
        notifications.markAllRead(userId);
        return ResponseEntity.ok().build();
    }

    /** 앱이 FCM 토큰을 받으면 등록 (같은 토큰이면 소유자만 갱신) */
    @PutMapping("/api/device-tokens")
    public ResponseEntity<Void> saveToken(@RequestAttribute("userId") long userId, @RequestBody TokenRequest body) {
        notifications.saveDeviceToken(userId, body.token());
        return ResponseEntity.ok().build();
    }

    /** 로그아웃할 때 이 기기로 푸시가 오지 않게 삭제 */
    @DeleteMapping("/api/device-tokens")
    public ResponseEntity<Void> deleteToken(@RequestAttribute("userId") long userId, @RequestParam String token) {
        notifications.deleteDeviceToken(userId, token);
        return ResponseEntity.ok().build();
    }
}
