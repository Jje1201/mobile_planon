package com.planon.server.user;

import com.planon.server.common.Dtos.UserDto;
import com.planon.server.common.Dtos.WithdrawRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    private final UserService users;
    private final AccountService accounts;

    public UserController(UserService users, AccountService accounts) {
        this.users = users;
        this.accounts = accounts;
    }

    /** 회원 탈퇴 (비밀번호 확인). 성공하면 이 토큰은 더 이상 쓸 수 없음 */
    @PostMapping("/api/users/me/withdraw")
    public ResponseEntity<Void> withdraw(@RequestAttribute("userId") long userId, @RequestBody WithdrawRequest body) {
        accounts.withdraw(userId, body.password());
        return ResponseEntity.ok().build();
    }

    @GetMapping("/api/users/me")
    public UserDto me(@RequestAttribute("userId") long userId) {
        return users.me(userId);
    }
}
