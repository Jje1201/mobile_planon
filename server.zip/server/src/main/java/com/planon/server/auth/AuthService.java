package com.planon.server.auth;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.LoginResponse;
import com.planon.server.common.Dtos.UserDto;
import com.planon.server.common.Jdbc;
import com.planon.server.config.TokenService;
import com.planon.server.user.UserService;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

@Service
public class AuthService {

    private static final Pattern LOGIN_ID = Pattern.compile("^[A-Za-z0-9]{4,16}$");
    private static final Pattern PASSWORD = Pattern.compile("^(?=.*[A-Za-z])(?=.*\\d).{8,64}$");
    private static final int NICKNAME_MAX = 10;

    private final JdbcTemplate jdbc;
    private final TokenService tokens;
    private final UserService users;
    private final RememberService remember;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AuthService(JdbcTemplate jdbc, TokenService tokens, UserService users, RememberService remember) {
        this.jdbc = jdbc;
        this.tokens = tokens;
        this.users = users;
        this.remember = remember;
    }

    public boolean isAvailable(String loginId) {
        if (loginId == null || !LOGIN_ID.matcher(loginId.trim()).matches()) return false;
        return Jdbc.count(jdbc, "SELECT COUNT(*) FROM users WHERE login_id = ?", loginId.trim()) == 0;
    }

    @Transactional
    public UserDto signUp(String loginId, String password, String nickname) {
        String id = loginId == null ? "" : loginId.trim();
        String nick = nickname == null ? "" : nickname.trim();
        if (!LOGIN_ID.matcher(id).matches()) throw ApiException.badRequest("아이디는 영문·숫자 4~16자로 입력해 주세요");
        if (password == null || !PASSWORD.matcher(password).matches())
            throw ApiException.badRequest("비밀번호는 영문과 숫자를 섞어 8자 이상으로 입력해 주세요");
        if (nick.isEmpty() || nick.length() > NICKNAME_MAX)
            throw ApiException.badRequest("닉네임은 1~" + NICKNAME_MAX + "자로 입력해 주세요");
        long userId;
        try {
            userId = Jdbc.insert(jdbc, "INSERT INTO users (login_id, password_hash, nickname, total_exp, level) "
                    + "VALUES (?, ?, ?, 0, 1)", id, encoder.encode(password), nick);
        } catch (DuplicateKeyException e) {
            throw ApiException.conflict("이미 사용 중인 아이디예요");
        }
        return users.me(userId);
    }

    /** 아이디·비밀번호가 틀리면 400 (401은 앱이 '로그인 만료'로 처리하므로 쓰지 않음) */
    public LoginResponse login(String loginId, String password, boolean remember, String deviceName) {
        String id = loginId == null ? "" : loginId.trim();
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT id, password_hash FROM users WHERE login_id = ? AND deleted_at IS NULL", id);
        if (rows.isEmpty() || password == null
                || !encoder.matches(password, (String) rows.get(0).get("password_hash"))) {
            throw ApiException.badRequest("아이디 또는 비밀번호가 맞지 않아요");
        }
        long userId = ((Number) rows.get(0).get("id")).longValue();
        String rememberToken = remember ? this.remember.issue(userId, deviceName) : null;
        return new LoginResponse(tokens.issue(userId), users.me(userId), rememberToken);
    }

    /** 기기에 저장한 계정으로 로그인. 만료·폐기된 토큰이면 401 (앱이 목록에서 지우고 비밀번호 입력으로) */
    public LoginResponse quickLogin(String rememberToken) {
        Long userId = remember.use(rememberToken);
        if (userId == null) throw ApiException.unauthorized("저장된 로그인 정보가 만료됐어요. 비밀번호로 다시 로그인해 주세요");
        return new LoginResponse(tokens.issue(userId), users.me(userId), rememberToken);
    }

    /** 휴대폰 목록에서 계정을 지울 때 */
    public void forget(String rememberToken) {
        remember.revoke(rememberToken);
    }
}
