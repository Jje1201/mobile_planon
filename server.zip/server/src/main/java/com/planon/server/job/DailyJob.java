package com.planon.server.job;

import com.planon.server.achievement.DailyRecordService;
import com.planon.server.achievement.MonthlyRankingService;
import com.planon.server.notification.NotificationService;
import com.planon.server.plan.VerificationService;
import com.planon.server.ranking.ExpService;
import com.planon.server.ranking.SettlementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 정해진 시각에 도는 일 (모두 한국 시간)
 * - 매시 0분 5초: 마감 지난 인증 확정 → 지난 일정 미수행 처리 → 주간 결산
 *   → 하루 기록·연속 기록·업적 → 월간 랭킹 확정·월간 업적 → 오래된 알림 정리
 *   (자정 00:00:05 에 결과가 반영되고, 서버가 꺼져 있었으면 켜진 뒤 첫 실행에서 따라잡음)
 * - 23:00: 아직 투표 안 한 파티원에게 마감 알림
 * - 서버 시작: 위 작업 한 번 + 경험치 장부 점검
 */
@Component
public class DailyJob implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DailyJob.class);

    private final VerificationService verifications;
    private final SettlementService settlements;
    private final NotificationService notifications;
    private final ExpService exp;
    private final DailyRecordService dailyRecords;
    private final MonthlyRankingService monthly;

    public DailyJob(VerificationService verifications, SettlementService settlements,
                    NotificationService notifications, ExpService exp,
                    DailyRecordService dailyRecords, MonthlyRankingService monthly) {
        this.verifications = verifications;
        this.settlements = settlements;
        this.notifications = notifications;
        this.exp = exp;
        this.dailyRecords = dailyRecords;
        this.monthly = monthly;
    }

    @Override
    public void run(ApplicationArguments args) {
        try {
            exp.check();
        } catch (Exception e) {
            log.error("경험치 점검 실패", e);
        }
        catchUp();
    }

    @Scheduled(cron = "5 0 * * * *", zone = "Asia/Seoul")
    public synchronized void catchUp() {
        try {
            int finalized = verifications.finalizeDue();
            int missed = verifications.markMissed();
            int settled = settlements.settleDueWeeks();
            int days = dailyRecords.processAll();
            int months = monthly.settleDueMonths();
            notifications.deleteOld();
            if (finalized + missed + settled + days + months > 0) {
                log.info("정기 작업: 인증 확정 {}건, 미수행 {}건, 주간 결산 {}건, 하루 기록 {}건, 월간 확정 {}건",
                        finalized, missed, settled, days, months);
            }
        } catch (Exception e) {
            log.error("정기 작업 실패", e);
        }
    }

    @Scheduled(cron = "0 0 23 * * *", zone = "Asia/Seoul")
    public void remind() {
        try {
            verifications.remindVoters();
        } catch (Exception e) {
            log.error("투표 알림 실패", e);
        }
    }
}
