package com.planon.server.ranking;

import com.planon.server.common.Jdbc;
import com.planon.server.common.LevelRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * 경험치 장부(exp_events)와 users.total_exp/level 를 맞춰 둡니다.
 *
 * - exp_events 가 원본, users.total_exp/level 은 합계를 담아둔 캐시
 * - grant() 는 회원 행을 잠그고, 장부 INSERT 와 users UPDATE 를 같은 트랜잭션에서 함 → 둘 중 하나만 반영되는 일이 없음
 * - (user, settlement, source) UNIQUE 라서 결산이 두 번 돌아도 두 번 지급되지 않음
 * - 서버 시작 때 check() 로 합계와 캐시가 다른 회원을 찾아 고침 (planon.exp.auto-repair=true)
 */
@Service
public class ExpService {

    private static final Logger log = LoggerFactory.getLogger(ExpService.class);

    public record Grant(boolean applied, int levelBefore, int levelAfter) {
    }

    private final JdbcTemplate jdbc;
    private final boolean autoRepair;

    public ExpService(JdbcTemplate jdbc, @Value("${planon.exp.auto-repair:true}") boolean autoRepair) {
        this.jdbc = jdbc;
        this.autoRepair = autoRepair;
    }

    /** 반드시 바깥 트랜잭션 안에서 호출 (결산 트랜잭션과 함께 커밋/롤백) */
    @Transactional
    public Grant grant(long userId, Long settlementId, String source, int amount) {
        Map<String, Object> u = jdbc.queryForMap("SELECT total_exp FROM users WHERE id = ? FOR UPDATE", userId);
        int before = ((Number) u.get("total_exp")).intValue();
        int levelBefore = LevelRule.levelFor(before);
        if (amount == 0) return new Grant(false, levelBefore, levelBefore);
        int after = Math.max(0, before + amount);
        int levelAfter = LevelRule.levelFor(after);
        try {
            jdbc.update("INSERT INTO exp_events (user_id, settlement_id, source, amount, level_before, level_after) "
                    + "VALUES (?, ?, ?, ?, ?, ?)", userId, settlementId, source, after - before, levelBefore, levelAfter);
        } catch (DuplicateKeyException e) {
            return new Grant(false, levelBefore, levelBefore);
        }
        jdbc.update("UPDATE users SET total_exp = ?, level = ? WHERE id = ?", after, levelAfter, userId);
        return new Grant(true, levelBefore, levelAfter);
    }

    /** 장부 합계와 users 캐시가 다른 회원 수. autoRepair 면 장부 기준으로 고침 */
    @Transactional
    public int check() {
        List<Map<String, Object>> diff = jdbc.queryForList("SELECT u.id, u.total_exp, u.level, "
                + "COALESCE(SUM(e.amount), 0) AS ledger, COUNT(e.id) AS rows_ FROM users u LEFT JOIN exp_events e ON e.user_id = u.id "
                + "GROUP BY u.id, u.total_exp, u.level");
        int bad = 0;
        for (Map<String, Object> r : diff) {
            long id = ((Number) r.get("id")).longValue();
            int cached = ((Number) r.get("total_exp")).intValue();
            int level = ((Number) r.get("level")).intValue();
            int ledger = Math.max(0, ((Number) r.get("ledger")).intValue());
            int expectLevel = LevelRule.levelFor(ledger);
            if (cached == ledger && level == expectLevel) continue;
            if (((Number) r.get("rows_")).intValue() == 0 && cached > 0) {
                // V2 이전에 들어간 값(테스트 데이터 등): 지우지 않고 장부에 ADJUST 한 줄로 옮겨 기준을 맞춤
                int lv = LevelRule.levelFor(cached);
                jdbc.update("INSERT INTO exp_events (user_id, settlement_id, source, amount, level_before, level_after) "
                        + "VALUES (?, NULL, 'ADJUST', ?, 1, ?)", id, cached, lv);
                jdbc.update("UPDATE users SET level = ? WHERE id = ?", lv, id);
                log.info("user {} 의 기존 경험치 {} 를 장부(ADJUST)로 옮겼습니다", id, cached);
                continue;
            }
            bad++;
            log.warn("경험치 불일치: user {} users.total_exp={} level={} / 장부 합계={} level={}", id, cached, level, ledger, expectLevel);
            if (autoRepair) {
                jdbc.update("UPDATE users SET total_exp = ?, level = ? WHERE id = ?", ledger, expectLevel, id);
            }
        }
        if (bad > 0) log.warn("경험치 불일치 {}명 {}", bad, autoRepair ? "→ 장부 기준으로 고쳤습니다" : "(auto-repair 꺼짐)");
        return bad;
    }

    public int earned(long userId, java.time.LocalDate from, java.time.LocalDate toExclusive) {
        return Jdbc.count(jdbc, "SELECT COALESCE(SUM(e.amount), 0) FROM exp_events e "
                + "LEFT JOIN weekly_settlements s ON s.id = e.settlement_id WHERE e.user_id = ? "
                + "AND COALESCE(s.week_start, DATE(e.created_at)) >= ? AND COALESCE(s.week_start, DATE(e.created_at)) < ?",
                userId, from, toExclusive);
    }
}
