package com.planon.server.ranking;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.RankEntryDto;
import com.planon.server.common.Dtos.RankingResultDto;
import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * 순위
 * - 주간 이번 주: 실시간 계산, exp = 지금 끝나면 받을 예상 경험치
 * - 주간 지난주: 결산 기록(weekly_results). 아직 결산 전이면 실시간 계산
 * - 월간: 그 달 일정 날짜 기준 포인트 합계, exp = 그 달 결산으로 받은 경험치
 */
@Service
public class RankingService {

    private final JdbcTemplate jdbc;
    private final StatsRepository stats;
    private final RankingCalculator calculator;
    private final ExpService exp;

    public RankingService(JdbcTemplate jdbc, StatsRepository stats, RankingCalculator calculator, ExpService exp) {
        this.jdbc = jdbc;
        this.stats = stats;
        this.calculator = calculator;
        this.exp = exp;
    }

    public RankingResultDto weekly(long userId, String week) {
        boolean last = "last".equalsIgnoreCase(week);
        if (!last && week != null && !week.isBlank() && !"current".equalsIgnoreCase(week))
            throw ApiException.badRequest("week 는 current 또는 last 예요");
        LocalDate weekStart = TimeRule.weekStart(TimeRule.today());
        if (last) weekStart = weekStart.minusWeeks(1);
        String period = last ? "WEEK_LAST" : "WEEK_CURRENT";
        String from = weekStart.toString();
        String to = weekStart.plusDays(6).toString();

        Long partyId = Jdbc.longOrNull(jdbc, "SELECT party_id FROM party_members WHERE user_id = ?", userId);
        List<StatsRepository.MemberRow> members = partyId == null ? List.of(self(userId)) : stats.members(partyId);

        if (last && partyId != null) {
            Long settlementId = Jdbc.longOrNull(jdbc, "SELECT id FROM weekly_settlements WHERE party_id = ? AND week_start = ?",
                    partyId, Date.valueOf(weekStart));
            if (settlementId != null) {
                List<RankEntryDto> entries = jdbc.query("SELECT r.`rank`, r.user_id, r.points, r.done_count, r.exp_total, "
                                + "u.nickname, u.total_exp, pm.character_id FROM weekly_results r JOIN users u ON u.id = r.user_id "
                                + "LEFT JOIN party_members pm ON pm.user_id = r.user_id WHERE r.settlement_id = ? "
                                + "ORDER BY r.`rank`, r.user_id",
                        (rs, i) -> new RankEntryDto(rs.getInt("rank"), rs.getLong("user_id"), rs.getString("nickname"),
                                StatsRepository.parseCharacter(rs.getString("character_id")), rs.getInt("total_exp"),
                                rs.getInt("points"), rs.getInt("done_count"), rs.getInt("exp_total")),
                        settlementId);
                return new RankingResultDto(period, from, to, true, entries);
            }
        }
        List<RankEntryDto> entries = new ArrayList<>();
        for (WeeklyScore s : calculator.compute(partyId, members, weekStart)) {
            entries.add(new RankEntryDto(s.rank, s.userId, s.nickname, s.characterId, s.totalExp,
                    s.points, s.doneCount, s.totalExpGain(members.size())));
        }
        return new RankingResultDto(period, from, to, false, entries);
    }

    public RankingResultDto monthly(long userId, String month) {
        boolean last = "last".equalsIgnoreCase(month);
        if (!last && month != null && !month.isBlank() && !"current".equalsIgnoreCase(month))
            throw ApiException.badRequest("month 는 current 또는 last 예요");
        YearMonth ym = YearMonth.from(TimeRule.today());
        if (last) ym = ym.minusMonths(1);
        LocalDate from = ym.atDay(1);
        LocalDate to = ym.plusMonths(1).atDay(1);

        Long partyId = Jdbc.longOrNull(jdbc, "SELECT party_id FROM party_members WHERE user_id = ?", userId);
        String period = last ? "MONTH_LAST" : "MONTH_CURRENT";
        // 지난달은 매월 1일에 고정한 확정본(monthly_rankings)이 있으면 그것을 보여줌
        if (partyId != null) {
            List<RankEntryDto> saved = jdbc.query("SELECT r.`rank`, r.user_id, r.points, r.done_count, r.exp_earned, "
                            + "u.nickname, u.total_exp, pm.character_id FROM monthly_rankings r JOIN users u ON u.id = r.user_id "
                            + "LEFT JOIN party_members pm ON pm.user_id = r.user_id "
                            + "WHERE r.party_id = ? AND r.month_start = ? ORDER BY r.`rank`, r.user_id",
                    (rs, i) -> new RankEntryDto(rs.getInt("rank"), rs.getLong("user_id"), rs.getString("nickname"),
                            StatsRepository.parseCharacter(rs.getString("character_id")), rs.getInt("total_exp"),
                            rs.getInt("points"), rs.getInt("done_count"), rs.getInt("exp_earned")),
                    partyId, java.sql.Date.valueOf(from));
            if (!saved.isEmpty()) return new RankingResultDto(period, from.toString(), to.minusDays(1).toString(), true, saved);
        }
        List<StatsRepository.MemberRow> members = partyId == null ? List.of(self(userId)) : stats.members(partyId);
        boolean finished = !to.isAfter(TimeRule.today());
        return new RankingResultDto(period, from.toString(), to.minusDays(1).toString(), finished,
                monthEntries(partyId, members, from, to));
    }

    /** 한 달 순위: 일정 날짜 기준 포인트 내림차순, 같으면 인정 수. 같은 점수는 같은 순위 */
    public List<RankEntryDto> monthEntries(Long partyId, List<StatsRepository.MemberRow> members, LocalDate from,
                                           LocalDate toExclusive) {
        List<RankEntryDto> raw = new ArrayList<>();
        for (StatsRepository.MemberRow m : members) {
            raw.add(new RankEntryDto(0, m.userId(), m.nickname(), m.characterId(), m.totalExp(),
                    stats.points(m.userId(), partyId, from, toExclusive),
                    stats.approvedCount(m.userId(), partyId, from, toExclusive),
                    exp.earned(m.userId(), from, toExclusive)));
        }
        raw.sort(Comparator.comparingInt(RankEntryDto::points).reversed()
                .thenComparing(Comparator.comparingInt(RankEntryDto::doneCount).reversed()));
        List<RankEntryDto> entries = new ArrayList<>();
        for (int i = 0; i < raw.size(); i++) {
            RankEntryDto e = raw.get(i);
            int rank = i + 1;
            if (i > 0) {
                RankEntryDto prev = raw.get(i - 1);
                if (prev.points() == e.points() && prev.doneCount() == e.doneCount()) rank = entries.get(i - 1).rank();
            }
            entries.add(new RankEntryDto(rank, e.userId(), e.nickname(), e.characterId(), e.totalExp(),
                    e.points(), e.doneCount(), e.exp()));
        }
        return entries;
    }

    private StatsRepository.MemberRow self(long userId) {
        Map<String, Object> u = jdbc.queryForMap("SELECT id, nickname, total_exp FROM users WHERE id = ?", userId);
        return new StatsRepository.MemberRow(userId, (String) u.get("nickname"), 0, ((Number) u.get("total_exp")).intValue());
    }
}
