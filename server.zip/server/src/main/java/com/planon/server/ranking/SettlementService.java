package com.planon.server.ranking;

import com.planon.server.common.Jdbc;
import com.planon.server.common.LevelRule;
import com.planon.server.common.TimeRule;
import com.planon.server.notification.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 주간 결산: 월요일 00:05 이후, 지난주(월~일)를 파티마다 한 번 계산해 경험치를 지급합니다.
 * weekly_settlements(party_id, week_start) UNIQUE 라서 여러 번 실행돼도 한 번만 지급됩니다.
 * 서버가 꺼져 있던 주가 있으면 최근 8주까지 거슬러 올라가 채웁니다.
 */
@Service
public class SettlementService {

    private static final Logger log = LoggerFactory.getLogger(SettlementService.class);
    private static final int CATCH_UP_WEEKS = 8;

    private final JdbcTemplate jdbc;
    private final RankingCalculator calculator;
    private final ExpService exp;
    private final NotificationService notifications;
    private final TransactionTemplate tx;

    public SettlementService(JdbcTemplate jdbc, RankingCalculator calculator, ExpService exp,
                             NotificationService notifications, TransactionTemplate tx) {
        this.jdbc = jdbc;
        this.calculator = calculator;
        this.exp = exp;
        this.notifications = notifications;
        this.tx = tx;
    }

    public int settleDueWeeks() {
        LocalDate lastWeek = TimeRule.weekStart(TimeRule.today()).minusWeeks(1);
        LocalDate oldest = lastWeek.minusWeeks(CATCH_UP_WEEKS - 1);
        List<Map<String, Object>> parties = jdbc.queryForList("SELECT id, created_at FROM parties WHERE deleted_at IS NULL");
        int count = 0;
        for (Map<String, Object> p : parties) {
            long partyId = ((Number) p.get("id")).longValue();
            LocalDate created = TimeRule.weekStart(Jdbc.dateTime(p.get("created_at")).toLocalDate());
            LocalDate from = created.isAfter(oldest) ? created : oldest;
            for (LocalDate week = from; !week.isAfter(lastWeek); week = week.plusWeeks(1)) {
                final LocalDate w = week;
                try {
                    Boolean done = tx.execute(status -> settle(partyId, w));
                    if (Boolean.TRUE.equals(done)) count++;
                } catch (Exception e) {
                    log.error("파티 {} {} 주 결산 실패", partyId, w, e);
                }
            }
        }
        if (count > 0) log.info("주간 결산 {}건 완료", count);
        return count;
    }

    /** 이미 결산된 주면 false */
    private boolean settle(long partyId, LocalDate weekStart) {
        if (Jdbc.count(jdbc, "SELECT COUNT(*) FROM weekly_settlements WHERE party_id = ? AND week_start = ?",
                partyId, Date.valueOf(weekStart)) > 0) return false;
        List<StatsRepository.MemberRow> members = calculator.members(partyId);
        if (members.isEmpty()) return false;
        long settlementId;
        try {
            settlementId = Jdbc.insert(jdbc, "INSERT INTO weekly_settlements (party_id, week_start) VALUES (?, ?)",
                    partyId, Date.valueOf(weekStart));
        } catch (DuplicateKeyException e) {
            return false;
        }
        List<WeeklyScore> scores = calculator.compute(partyId, members, weekStart);
        int size = members.size();
        for (WeeklyScore s : scores) {
            int total = s.totalExpGain(size);
            jdbc.update("INSERT INTO weekly_results (settlement_id, user_id, `rank`, points, done_count, plan_count, "
                            + "review_ok, party_goal_ok, exp_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    settlementId, s.userId, s.rank, s.points, s.doneCount, s.planCount, s.reviewOk, s.partyGoalOk, total);

            int levelBefore = LevelRule.levelFor(s.totalExp);
            int levelAfter = levelBefore;
            levelAfter = apply(s.userId, settlementId, "WEEKLY_RANK", s.rankExp(size), levelAfter);
            levelAfter = apply(s.userId, settlementId, "WEEKLY_COMPLETION", s.completionExp(), levelAfter);
            levelAfter = apply(s.userId, settlementId, "WEEKLY_REVIEW", s.reviewExp(), levelAfter);
            levelAfter = apply(s.userId, settlementId, "PARTY_GOAL", s.partyGoalExp(), levelAfter);

            String body = total > 0
                    ? "지난주 " + s.rank + "위 · " + s.points + "pt → 경험치 +" + total
                    : "지난주 " + s.rank + "위 · " + s.points + "pt (포인트가 0 이하라 경험치는 없어요)";
            notifications.notify(s.userId, NotificationService.WEEKLY_SETTLED, "주간 결산", body, null, partyId);
            if (levelAfter > levelBefore) {
                notifications.notify(s.userId, NotificationService.LEVEL_UP, "레벨 업!",
                        "Lv." + levelBefore + " → Lv." + levelAfter, null, partyId);
                int stageBefore = LevelRule.stageFor(levelBefore);
                int stageAfter = LevelRule.stageFor(levelAfter);
                if (stageAfter > stageBefore) {
                    notifications.notify(s.userId, NotificationService.CHARACTER_GROWN, "캐릭터가 자랐어요",
                            "캐릭터가 " + stageAfter + "단계로 성장했어요", null, partyId);
                }
            }
        }
        return true;
    }

    private int apply(long userId, long settlementId, String source, int amount, int currentLevel) {
        if (amount <= 0) return currentLevel;
        ExpService.Grant g = exp.grant(userId, settlementId, source, amount);
        return g.applied() ? g.levelAfter() : currentLevel;
    }
}
