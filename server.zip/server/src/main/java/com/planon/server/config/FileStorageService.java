package com.planon.server.config;

import com.planon.server.common.ApiException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** 인증 사진을 uploads/yyyy/MM/<UUID>.확장자 로 저장하고 "/uploads/..." 경로를 돌려줍니다. */
@Component
public class FileStorageService {

    private static final Set<String> EXTENSIONS = Set.of("jpg", "jpeg", "png", "webp", "heic");

    private final Path root;

    public FileStorageService(@Value("${planon.upload-dir:uploads}") String uploadDir) {
        this.root = Path.of(uploadDir).toAbsolutePath().normalize();
    }

    public String save(MultipartFile file) {
        if (file == null || file.isEmpty()) throw ApiException.badRequest("빈 사진은 올릴 수 없어요");
        String ext = extension(file);
        LocalDate today = LocalDate.now();
        String relative = String.format("%d/%02d/%s.%s", today.getYear(), today.getMonthValue(), UUID.randomUUID(), ext);
        Path target = root.resolve(relative).normalize();
        if (!target.startsWith(root)) throw ApiException.badRequest("잘못된 파일 경로예요");
        try {
            Files.createDirectories(target.getParent());
            try (InputStream in = file.getInputStream()) {
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            throw new IllegalStateException("사진 저장 실패", e);
        }
        return "/uploads/" + relative;
    }

    /** save() 가 돌려준 "/uploads/..." 경로의 파일 삭제 (없으면 무시) */
    public void delete(String publicPath) {
        if (publicPath == null || !publicPath.startsWith("/uploads/")) return;
        Path target = root.resolve(publicPath.substring("/uploads/".length())).normalize();
        if (!target.startsWith(root)) return;
        try {
            Files.deleteIfExists(target);
        } catch (IOException ignored) {
            // 파일 정리 실패는 무시 (DB 기록은 이미 지움)
        }
    }

    private static String extension(MultipartFile file) {
        String type = file.getContentType() == null ? "" : file.getContentType().toLowerCase(Locale.ROOT);
        String name = file.getOriginalFilename() == null ? "" : file.getOriginalFilename().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        String ext = dot >= 0 ? name.substring(dot + 1) : "";
        if (EXTENSIONS.contains(ext)) return ext.equals("jpeg") ? "jpg" : ext;
        if (type.equals("image/jpeg")) return "jpg";
        if (type.equals("image/png")) return "png";
        if (type.equals("image/webp")) return "webp";
        throw ApiException.badRequest("사진 파일(jpg, png, webp)만 올릴 수 있어요");
    }
}
