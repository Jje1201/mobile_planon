package com.planon.server.achievement;

import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

/**
 * 하루 결과(daily_records) · 연속 기록(user_streaks) · 파티 하루 결과(party_daily_records)를 만들고
 * 연속·재미·파티 업적을 판정합니다.
 *
 * 자정에 인증이 확정되고 지난 TODO 가 MISSED 로 바뀐 뒤에 실행되므로, 어제까지의 날은 모두 결과가 정해져 있습니다.
 * 날짜 순서대로 하루씩 반영하고(last_record_date), 서버가 꺼져 있던 날도 켜진 뒤 차례로 채웁니다 (최근 60일까지).
 */
@Service
public class DailyRecordService {

    private static final Logger log = LoggerFactory.getLogger(DailyRecordService.class);
    /** 올클 = 그날 일정이 이 개수 이상이고 전부 인정 */
    public static final int MIN_PLANS_FOR_CLEAR = 3;
    private static final int CATCH_UP_DAYS = 60;
    /** 벼락치기의 미학: 사진 마감(23:30) 전 10분 */
    private static final LocalTime LAST_MINUTE_FROM = LocalTime.of(23, 20);
    private static final LocalTime LAST_MINUTE_TO = LocalTime.of(23, 30);

    private final JdbcTemplate jdbc;
    private final AchievementService achievements;
    private final TransactionTemplate tx;

    public DailyRecordService(JdbcTemplate jdbc, AchievementService achievements, TransactionTemplate tx) {
        this.jdbc = jdbc;
        this.achievements = achievements;
        this.tx = tx;
    }

    /** 모든 회원 → 모든 파티 순서로 어제까지 반영. 반영한 (회원·날) 수를 돌려줌 */
    public int processAll() {
        int days = 0;
        List<Map<String, Object>> users = jdbc.queryForList("SELECT id, created_at FROM users WHERE deleted_at IS NULL");
        for (Map<String, Object> u : users) {
            long userId = ((Number) u.get("id")).longValue();
            LocalDate created = Jdbc.dateTime(u.get("created_at")).toLocalDate();
            try {
                Integer n = tx.execute(status -> processUser(userId, created));
                days += n == null ? 0 : n;
            } catch (Exception e) {
                log.error("회원 {} 하루 기록 실패", userId, e);
            }
        }
        List<Map<String, Object>> parties = jdbc.queryForList("SELECT id, created_at FROM parties WHERE deleted_at IS NULL");
        for (Map<String, Object> p : parties) {
            long partyId = ((Number) p.get("id")).longValue();
            LocalDate created = Jdbc.dateTime(p.get("created_at")).toLocalDate();
            try {
                tx.execute(status -> processParty(partyId, created));
            } catch (Exception e) {
                log.error("파티 {} 하루 기록 실패", partyId, e);
            }
        }
        return days;
    }

    private int processUser(long userId, LocalDate created) {
        jdbc.update("INSERT IGNORE INTO user_streaks (user_id) VALUES (?)", userId);
        Map<String, Object> s = jdbc.queryForMap("SELECT * FROM user_streaks WHERE user_id = ? FOR UPDATE", userId);
        int clear = ((Number) s.get("clear_streak")).intValue();
        int best = ((Number) s.get("best_clear_streak")).intValue();
        int fail = ((Number) s.get("fail_streak")).intValue();
        int none = ((Number) s.get("none_streak")).intValue();
        LocalDate last = Jdbc.date(s.get("last_record_date"));

        LocalDate today = TimeRule.today();
        LocalDate oldest = today.minusDays(CATCH_UP_DAYS);
        LocalDate start = last != null ? last.plusDays(1) : (created.isAfter(oldest) ? created : oldest);
        Long partyId = Jdbc.longOrNull(jdbc, "SELECT party_id FROM party_members WHERE user_id = ?", userId);

        int done = 0;
        for (LocalDate d = start; d.isBefore(today); d = d.plusDays(1)) {
            Map<String, Object> c = jdbc.queryForMap("SELECT COUNT(*) AS total, "
                    + "COALESCE(SUM(status = 'APPROVED'), 0) AS approved, COALESCE(SUM(status = 'REJECTED'), 0) AS rejected, "
                    + "COALESCE(SUM(status = 'MISSED'), 0) AS missed, COALESCE(SUM(status IN ('TODO', 'VOTING')), 0) AS pending "
                    + "FROM plans WHERE user_id = ? AND plan_date = ?", userId, Date.valueOf(d));
            int total = num(c.get("total"));
            int approved = num(c.get("approved"));
            int rejected = num(c.get("rejected"));
            int missed = num(c.get("missed"));
            int pending = num(c.get("pending"));
            String result;
            if (total == 0) result = "NONE";
            else if (pending > 0) result = "PENDING";
            else if (rejected + missed > 0) result = "FAIL";
            else if (total < MIN_PLANS_FOR_CLEAR) result = "SHORT";
            else result = "CLEAR";

            jdbc.update("INSERT INTO daily_records (user_id, record_date, party_id, plan_count, approved_count, rejected_count, "
                            + "missed_count, pending_count, result, resolved_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                            + "ON DUPLICATE KEY UPDATE party_id = VALUES(party_id), plan_count = VALUES(plan_count), "
                            + "approved_count = VALUES(approved_count), rejected_count = VALUES(rejected_count), "
                            + "missed_count = VALUES(missed_count), pending_count = VALUES(pending_count), "
                            + "result = VALUES(result), resolved_at = VALUES(resolved_at)",
                    userId, Date.valueOf(d), partyId, total, approved, rejected, missed, pending, result,
                    "PENDING".equals(result) ? null : Timestamp.valueOf(TimeRule.now()));
            if ("PENDING".equals(result)) break; // 아직 확정 안 된 날에서 멈추고 다음 실행 때 이어서

            int prevClear = clear;
            switch (result) {
                case "CLEAR" -> {
                    clear++;
                    fail = 0;
                    none = 0;
                }
                case "FAIL" -> {
                    clear = 0;
                    fail++;
                    none = 0;
                }
                case "NONE" -> {
                    clear = 0;
                    fail = 0;
                    none++;
                }
                default -> { // SHORT: 세 기록 모두 0
                    clear = 0;
                    fail = 0;
                    none = 0;
                }
            }
            best = Math.max(best, clear);
            String key = d.toString();

            if ("CLEAR".equals(result)) {
                if (clear == achievements.threshold("STREAK_3", 3)) achievements.award(userId, "STREAK_3", key, partyId);
                if (clear == achievements.threshold("STREAK_7", 7)) achievements.award(userId, "STREAK_7", key, partyId);
                if (clear == achievements.threshold("STREAK_30", 30)) achievements.award(userId, "STREAK_30", key, partyId);
                if (d.getDayOfWeek() == DayOfWeek.SUNDAY && "CLEAR".equals(resultOf(userId, d.minusDays(1)))) {
                    achievements.award(userId, "WEEKEND_CLEAR", key, partyId);
                }
            }
            if ("FAIL".equals(result) && prevClear >= achievements.threshold("STREAK_BROKEN", 3)) {
                achievements.award(userId, "STREAK_BROKEN", key, partyId);
            }
            if (fail == achievements.threshold("FAIL_7", 7)) achievements.award(userId, "FAIL_7", key, partyId);
            if (none == achievements.threshold("IDLE_7", 7)) achievements.award(userId, "IDLE_7", key, partyId);
            if (approved > 0 && lastMinute(userId, d)) achievements.award(userId, "LAST_MINUTE", key, partyId);

            jdbc.update("UPDATE user_streaks SET clear_streak = ?, best_clear_streak = ?, fail_streak = ?, none_streak = ?, "
                    + "last_record_date = ? WHERE user_id = ?", clear, best, fail, none, Date.valueOf(d), userId);
            done++;
        }
        return done;
    }

    /** 그날 인정된 일정 중 23:20~23:29 에 제출한 것이 있는지 */
    private boolean lastMinute(long userId, LocalDate d) {
        return Jdbc.count(jdbc, "SELECT COUNT(*) FROM plans pl JOIN verifications v ON v.plan_id = pl.id "
                        + "WHERE pl.user_id = ? AND pl.plan_date = ? AND pl.status = 'APPROVED' "
                        + "AND v.submitted_at >= ? AND v.submitted_at < ?", userId, Date.valueOf(d),
                Timestamp.valueOf(d.atTime(LAST_MINUTE_FROM)), Timestamp.valueOf(d.atTime(LAST_MINUTE_TO))) > 0;
    }

    private String resultOf(long userId, LocalDate d) {
        List<String> r = jdbc.queryForList("SELECT result FROM daily_records WHERE user_id = ? AND record_date = ?",
                String.class, userId, Date.valueOf(d));
        return r.isEmpty() ? null : r.get(0);
    }

    /** 파티 하루 결과: 그날 그 파티로 기록된 사람 기준. 2명 이상 전원 올클이면 파티 업적 */
    private int processParty(long partyId, LocalDate created) {
        jdbc.queryForList("SELECT id FROM parties WHERE id = ? FOR UPDATE", partyId);
        LocalDate today = TimeRule.today();
        LocalDate last = Jdbc.date(jdbc.queryForObject(
                "SELECT MAX(record_date) FROM party_daily_records WHERE party_id = ?", Object.class, partyId));
        LocalDate oldest = today.minusDays(CATCH_UP_DAYS);
        LocalDate start = last != null ? last.plusDays(1) : (created.isAfter(oldest) ? created : oldest);
        List<Long> current = jdbc.queryForList("SELECT user_id FROM party_members WHERE party_id = ?", Long.class, partyId);

        int done = 0;
        for (LocalDate d = start; d.isBefore(today); d = d.plusDays(1)) {
            // 지금 파티원 중 그날 기록이 아직 없거나 확정 전인 사람이 있으면 다음 실행 때
            if (!membersReady(current, d)) break;

            List<Map<String, Object>> rows = jdbc.queryForList("SELECT user_id, result FROM daily_records "
                    + "WHERE party_id = ? AND record_date = ?", partyId, Date.valueOf(d));
            int members = rows.size();
            int clears = (int) rows.stream().filter(r -> "CLEAR".equals(r.get("result"))).count();
            boolean allClear = members >= 2 && clears == members;
            List<Integer> prev = jdbc.queryForList("SELECT party_clear_streak FROM party_daily_records "
                    + "WHERE party_id = ? AND record_date = ?", Integer.class, partyId, Date.valueOf(d.minusDays(1)));
            int streak = allClear ? (prev.isEmpty() ? 0 : prev.get(0)) + 1 : 0;

            jdbc.update("INSERT IGNORE INTO party_daily_records (party_id, record_date, member_count, clear_count, all_clear, "
                            + "party_clear_streak, resolved_at) VALUES (?, ?, ?, ?, ?, ?, ?)", partyId, Date.valueOf(d),
                    members, clears, allClear, streak, Timestamp.valueOf(TimeRule.now()));
            if (allClear) {
                for (Map<String, Object> r : rows) {
                    long userId = ((Number) r.get("user_id")).longValue();
                    achievements.award(userId, "PARTY_CLEAR_1", d.toString(), partyId);
                    if (streak == achievements.threshold("PARTY_STREAK_7", 7)) {
                        achievements.award(userId, "PARTY_STREAK_7", d.toString(), partyId);
                    }
                }
            }
            done++;
        }
        return done;
    }

    /** 지금 파티원이 모두 그날까지 반영됐는지 (그날 이후 가입한 회원은 제외) */
    private boolean membersReady(List<Long> members, LocalDate d) {
        for (Long member : members) {
            Map<String, Object> m = jdbc.queryForMap("SELECT u.created_at, s.last_record_date FROM users u "
                    + "LEFT JOIN user_streaks s ON s.user_id = u.id WHERE u.id = ?", member);
            LocalDate created = Jdbc.dateTime(m.get("created_at")).toLocalDate();
            if (created.isAfter(d)) continue;
            LocalDate last = Jdbc.date(m.get("last_record_date"));
            if (last == null || last.isBefore(d)) return false;
        }
        return true;
    }

    private static int num(Object o) {
        return o == null ? 0 : ((Number) o).intValue();
    }
}
