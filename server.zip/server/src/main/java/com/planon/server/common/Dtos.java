package com.planon.server.common;

import java.util.List;

/**
 * 앱과 주고받는 JSON. 필드 이름은 앱의 model/*.java, data/remote/Dtos.java 와 같아야 합니다.
 */
public final class Dtos {
    private Dtos() {
    }

    // ---------- 요청 ----------
    public record SignUpRequest(String loginId, String password, String nickname) {
    }

    /** remember=true 면 이 기기에 로그인 정보 저장 (응답의 rememberToken) */
    public record LoginRequest(String loginId, String password, Boolean remember, String deviceName) {
    }

    public record QuickLoginRequest(String rememberToken) {
    }

    /** 회원 탈퇴: 비밀번호로 한 번 더 확인 */
    public record WithdrawRequest(String password) {
    }

    public record PartyCreateRequest(String name) {
    }

    public record JoinRequest(String inviteCode) {
    }

    public record CharacterRequest(int characterId) {
    }

    public record PlanRequest(String date, String title, String time, String category, String memo) {
    }

    public record VoteRequest(boolean approve) {
    }

    public record TokenRequest(String token) {
    }

    // ---------- 응답 ----------
    public record UserDto(long id, String loginId, String nickname,
                          long partyId, String partyName, int characterId,
                          int totalExp, int level, int expInLevel, int expForNext, int stage,
                          int weeklyPoints, int totalPoints, int weeklyRank) {
    }

    /** rememberToken: 저장을 선택했을 때만 (없으면 null) */
    public record LoginResponse(String token, UserDto user, String rememberToken) {
    }

    public record AvailableResponse(boolean available) {
    }

    public record CountResponse(int count) {
    }

    public record MemberDto(long userId, String nickname, int characterId, int totalExp, boolean leader,
                            int todayTotal, int todayDone) {
    }

    public record PartyDto(long id, String name, String inviteCode, long leaderId, List<MemberDto> members) {
    }

    /** vote: 1 인정, -1 미인정, 0 안 했거나 비공개(투표 중에는 남의 표 내용을 숨김) */
    public record VoteInfoDto(long userId, String nickname, boolean voted, int vote) {
    }

    /** 인증 사진 한 장. editable: 지금 지우거나 바꿀 수 있는지 (올린 뒤 10분, 본인만) */
    public record PhotoDto(long id, String url, String uploadedAt, String editableUntil, boolean editable) {
    }

    public record PlanDto(long id, long userId, String ownerNickname, int ownerCharacterId, int ownerStage,
                          String date, String title, String time, String category, String memo,
                          String status,
                          List<String> imageUrls, List<PhotoDto> photos, String comment, String submittedAt,
                          String photoDeadline, String voteDeadline, boolean finalized,
                          int approveCount, int rejectCount, int votedCount, int voterCount, int myVote,
                          boolean canSubmit, boolean canAddPhotos, boolean canVote,
                          List<VoteInfoDto> votes) {
    }

    public record RankEntryDto(int rank, long userId, String nickname, int characterId, int totalExp,
                               int points, int doneCount, int exp) {
    }

    /** period: WEEK_CURRENT, WEEK_LAST, MONTH_CURRENT, MONTH_LAST. weekStart/weekEnd 는 기간 시작·끝 날짜 */
    public record RankingResultDto(String period, String weekStart, String weekEnd, boolean settled,
                                   List<RankEntryDto> entries) {
    }

    /** 업적 하나. 받기 전 숨김 업적은 name "???" */
    public record AchievementDto(String code, String name, String description, String category, int rewardPoints,
                                 boolean hidden, boolean earned, int count, String firstAchievedAt) {
    }

    public record AchievementsResponse(int clearStreak, int bestClearStreak, int earnedCount, int totalCount,
                                       List<AchievementDto> items) {
    }

    public record NotificationDto(long id, String type, String title, String body, Long planId,
                                  boolean read, String createdAt) {
    }
}
