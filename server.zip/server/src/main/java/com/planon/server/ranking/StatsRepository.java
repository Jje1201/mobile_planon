package com.planon.server.ranking;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * 포인트·달성률·검토 참여 집계 쿼리.
 * 포인트는 "일정 날짜" 기준으로 셉니다 (자정에 확정돼도 그 일정의 날짜가 속한 주·달에 들어감).
 * 순위·결산용 집계는 파티별로 나눕니다(partyId, 파티가 없으면 null) → 파티를 옮겨도 이전 파티 기록이 새 파티에 섞이지 않음.
 */
@Repository
public class StatsRepository {

    /** 파티원 한 명 (가입 순) */
    public record MemberRow(long userId, String nickname, int characterId, int totalExp) {
    }

    private static final String POINT_DATE = "COALESCE(pl.plan_date, DATE(pe.created_at))";

    private final JdbcTemplate jdbc;

    public StatsRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<MemberRow> members(long partyId) {
        return jdbc.query("SELECT u.id, u.nickname, u.total_exp, pm.character_id FROM party_members pm "
                        + "JOIN users u ON u.id = pm.user_id WHERE pm.party_id = ? ORDER BY pm.joined_at, u.id",
                (rs, i) -> new MemberRow(rs.getLong("id"), rs.getString("nickname"),
                        parseCharacter(rs.getString("character_id")), rs.getInt("total_exp")),
                partyId);
    }

    public int points(long userId, Long partyId, LocalDate from, LocalDate toExclusive) {
        Integer n = jdbc.queryForObject("SELECT COALESCE(SUM(pe.points), 0) FROM point_events pe "
                        + "LEFT JOIN plans pl ON pl.id = pe.plan_id WHERE pe.user_id = ? AND pe.party_id <=> ? "
                        + "AND " + POINT_DATE + " >= ? AND " + POINT_DATE + " < ?",
                Integer.class, userId, partyId, from, toExclusive);
        return n == null ? 0 : n;
    }

    public int totalPoints(long userId) {
        Integer n = jdbc.queryForObject("SELECT COALESCE(SUM(points), 0) FROM point_events WHERE user_id = ?",
                Integer.class, userId);
        return n == null ? 0 : n;
    }

    /** 기간 안의 인정된 일정 수 */
    public int approvedCount(long userId, Long partyId, LocalDate from, LocalDate toExclusive) {
        return count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND party_id <=> ? AND plan_date >= ? AND plan_date < ? "
                + "AND status = 'APPROVED'", userId, partyId, from, toExclusive);
    }

    /** 기간 안의 결과가 확정된 일정 수 (달성률 분모) */
    public int finishedCount(long userId, Long partyId, LocalDate from, LocalDate toExclusive) {
        return count("SELECT COUNT(*) FROM plans WHERE user_id = ? AND party_id <=> ? AND plan_date >= ? AND plan_date < ? "
                + "AND status IN ('APPROVED', 'REJECTED', 'MISSED')", userId, partyId, from, toExclusive);
    }

    /** 기간 안에 확정된 인증 중, 투표권이 있었는데 투표하지 않은 건수 (0이면 검토 참여 경험치) */
    public int missedVotes(long userId, Long partyId, LocalDate from, LocalDate toExclusive) {
        return count("SELECT COUNT(*) FROM verification_votes vv "
                + "JOIN verifications v ON v.id = vv.verification_id JOIN plans pl ON pl.id = v.plan_id "
                + "WHERE vv.voter_id = ? AND pl.party_id <=> ? AND vv.is_active = TRUE AND vv.vote IS NULL "
                + "AND v.finalized_at IS NOT NULL AND pl.plan_date >= ? AND pl.plan_date < ?", userId, partyId, from, toExclusive);
    }

    private int count(String sql, Object... args) {
        Integer n = jdbc.queryForObject(sql, Integer.class, args);
        return n == null ? 0 : n;
    }

    /** V1 의 party_members.character_id 는 VARCHAR. 앱에는 1~4 숫자로, 미선택은 0 */
    public static int parseCharacter(String raw) {
        if (raw == null) return 0;
        try {
            int v = Integer.parseInt(raw.trim());
            return v >= 1 && v <= 4 ? v : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
