package com.planon.server.user;

import com.planon.server.common.ApiException;
import com.planon.server.common.Dtos.UserDto;
import com.planon.server.common.LevelRule;
import com.planon.server.common.TimeRule;
import com.planon.server.ranking.RankingCalculator;
import com.planon.server.ranking.StatsRepository;
import com.planon.server.ranking.WeeklyScore;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class UserService {

    private final JdbcTemplate jdbc;
    private final StatsRepository stats;
    private final RankingCalculator calculator;

    public UserService(JdbcTemplate jdbc, StatsRepository stats, RankingCalculator calculator) {
        this.jdbc = jdbc;
        this.stats = stats;
        this.calculator = calculator;
    }

    public UserDto me(long userId) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT u.id, u.login_id, u.nickname, u.total_exp, pm.party_id, pm.character_id, p.name AS party_name "
                        + "FROM users u LEFT JOIN party_members pm ON pm.user_id = u.id "
                        + "LEFT JOIN parties p ON p.id = pm.party_id WHERE u.id = ? AND u.deleted_at IS NULL", userId);
        if (rows.isEmpty()) throw ApiException.notFound("회원 정보를 찾을 수 없어요");
        Map<String, Object> r = rows.get(0);
        int totalExp = ((Number) r.get("total_exp")).intValue();
        long partyId = r.get("party_id") == null ? 0 : ((Number) r.get("party_id")).longValue();
        int level = LevelRule.levelFor(totalExp);

        LocalDate weekStart = TimeRule.weekStart(TimeRule.today());
        // 이번 주 포인트는 지금 파티에서 얻은 것만 (파티를 옮기면 새로 시작)
        int weeklyPoints = stats.points(userId, partyId > 0 ? partyId : null, weekStart, weekStart.plusDays(7));
        int weeklyRank = 0;
        if (partyId > 0) {
            for (WeeklyScore s : calculator.compute(partyId, weekStart)) {
                if (s.userId == userId) weeklyRank = s.rank;
            }
        } else {
            weeklyRank = 1;
        }
        int expInLevel = totalExp - LevelRule.totalForLevel(level);
        int expForNext = level >= LevelRule.MAX_LEVEL ? 0 : LevelRule.needForNext(level);
        return new UserDto(userId, (String) r.get("login_id"), (String) r.get("nickname"),
                partyId, (String) r.get("party_name"),
                StatsRepository.parseCharacter((String) r.get("character_id")),
                totalExp, level, expInLevel, expForNext, LevelRule.stageFor(level),
                weeklyPoints, stats.totalPoints(userId), weeklyRank);
    }
}
