package com.planon.server.user;

import com.planon.server.common.ApiException;
import com.planon.server.common.Jdbc;
import com.planon.server.common.TimeRule;
import com.planon.server.config.FileStorageService;
import com.planon.server.party.PartyService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

/**
 * 회원 탈퇴.
 * 일정·투표·포인트 기록은 다른 파티원의 순위·결산에 쓰였으므로 지우지 않고, 개인을 알아볼 수 있는 정보만 지웁니다.
 * - 아이디·닉네임·비밀번호를 지워 다시 로그인할 수 없게 하고(아이디는 새 회원이 다시 쓸 수 있음) deleted_at 표시
 * - 파티에서 빠짐 (파티장이면 다음 사람에게 넘기고, 혼자였으면 파티도 삭제 표시)
 * - 앞으로의 일정, 인증 사진 파일, 알림, 푸시 토큰, 기기 저장 로그인을 삭제
 * - 남아 있던 로그인 토큰은 AuthInterceptor 가 deleted_at 을 보고 거부 (401)
 */
@Service
public class AccountService {

    public static final String DELETED_NICKNAME = "탈퇴한 회원";

    private final JdbcTemplate jdbc;
    private final PartyService parties;
    private final FileStorageService files;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AccountService(JdbcTemplate jdbc, PartyService parties, FileStorageService files) {
        this.jdbc = jdbc;
        this.parties = parties;
        this.files = files;
    }

    @Transactional
    public void withdraw(long userId, String password) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT password_hash FROM users WHERE id = ? AND deleted_at IS NULL FOR UPDATE", userId);
        if (rows.isEmpty()) throw ApiException.notFound("회원 정보를 찾을 수 없어요");
        if (password == null || !encoder.matches(password, (String) rows.get(0).get("password_hash"))) {
            throw ApiException.badRequest("비밀번호가 맞지 않아요");
        }
        Timestamp now = Timestamp.valueOf(TimeRule.now());

        // 1) 파티에서 빠지기 (투표권 회수·파티장 넘기기·그 파티의 앞으로의 일정 삭제는 leave 가 처리)
        Long partyId = parties.partyIdOf(userId);
        if (partyId != null) {
            parties.leave(userId);
            if (parties.memberIds(partyId).isEmpty()) {
                jdbc.update("UPDATE parties SET deleted_at = ?, invite_code = ? WHERE id = ? AND deleted_at IS NULL",
                        now, "DELETED-" + partyId, partyId);
            }
        }
        // 파티 밖에 남은 투표권도 회수
        jdbc.update("UPDATE verification_votes vv JOIN verifications v ON v.id = vv.verification_id "
                + "SET vv.is_active = FALSE WHERE vv.voter_id = ? AND v.finalized_at IS NULL", userId);

        // 2) 앞으로의 일정(아직 인증 전) 삭제
        Date today = Date.valueOf(TimeRule.today());
        jdbc.update("DELETE FROM notifications WHERE plan_id IN (SELECT id FROM plans WHERE user_id = ? "
                + "AND status = 'TODO' AND plan_date >= ?)", userId, today);
        jdbc.update("DELETE FROM plans WHERE user_id = ? AND status = 'TODO' AND plan_date >= ?", userId, today);

        // 3) 인증 사진: DB 행 삭제, 파일은 커밋된 뒤 삭제
        List<String> photoPaths = jdbc.queryForList("SELECT p.image_path FROM verification_photos p "
                + "JOIN verifications v ON v.id = p.verification_id JOIN plans pl ON pl.id = v.plan_id "
                + "WHERE pl.user_id = ?", String.class, userId);
        jdbc.update("DELETE p FROM verification_photos p JOIN verifications v ON v.id = p.verification_id "
                + "JOIN plans pl ON pl.id = v.plan_id WHERE pl.user_id = ?", userId);

        // 4) 알림·푸시·기기 저장 로그인
        jdbc.update("DELETE FROM notifications WHERE user_id = ?", userId);
        jdbc.update("DELETE FROM device_tokens WHERE user_id = ?", userId);
        jdbc.update("UPDATE remember_tokens SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL", now, userId);

        // 5) 개인 정보 지우기 (아이디는 비워서 같은 아이디로 다시 가입할 수 있게)
        jdbc.update("UPDATE users SET login_id = ?, nickname = ?, password_hash = ?, deleted_at = ? WHERE id = ?",
                "deleted_" + userId, DELETED_NICKNAME, "!", now, userId);

        afterCommit(() -> photoPaths.forEach(files::delete));
    }

    public boolean exists(long userId) {
        return Jdbc.count(jdbc, "SELECT COUNT(*) FROM users WHERE id = ? AND deleted_at IS NULL", userId) > 0;
    }

    private static void afterCommit(Runnable r) {
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    r.run();
                }
            });
        } else {
            r.run();
        }
    }
}
