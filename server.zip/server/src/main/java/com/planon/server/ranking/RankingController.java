package com.planon.server.ranking;

import com.planon.server.common.Dtos.RankingResultDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RankingController {

    private final RankingService rankings;

    public RankingController(RankingService rankings) {
        this.rankings = rankings;
    }

    /** week = current | last */
    @GetMapping("/api/rankings/weekly")
    public RankingResultDto weekly(@RequestAttribute("userId") long userId,
                                   @RequestParam(defaultValue = "current") String week) {
        return rankings.weekly(userId, week);
    }

    /** month = current | last */
    @GetMapping("/api/rankings/monthly")
    public RankingResultDto monthly(@RequestAttribute("userId") long userId,
                                    @RequestParam(defaultValue = "current") String month) {
        return rankings.monthly(userId, month);
    }
}
