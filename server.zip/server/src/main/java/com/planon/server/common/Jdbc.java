package com.planon.server.common;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

/** JdbcTemplate 보조 함수 */
public final class Jdbc {
    private Jdbc() {
    }

    /** INSERT 후 AUTO_INCREMENT id 반환 */
    public static long insert(JdbcTemplate jdbc, String sql, Object... args) {
        KeyHolder keys = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            return ps;
        }, keys);
        Number key = keys.getKey();
        if (key == null) throw new IllegalStateException("생성된 id가 없습니다: " + sql);
        return key.longValue();
    }

    public static int count(JdbcTemplate jdbc, String sql, Object... args) {
        Integer n = jdbc.queryForObject(sql, Integer.class, args);
        return n == null ? 0 : n;
    }

    /** 드라이버 설정에 따라 Timestamp 또는 LocalDateTime 으로 오므로 둘 다 받음 */
    public static java.time.LocalDateTime dateTime(Object o) {
        if (o == null) return null;
        if (o instanceof java.sql.Timestamp t) return t.toLocalDateTime();
        if (o instanceof java.time.LocalDateTime t) return t;
        throw new IllegalArgumentException("시간 값이 아님: " + o.getClass());
    }

    public static java.time.LocalDate date(Object o) {
        if (o == null) return null;
        if (o instanceof java.sql.Date d) return d.toLocalDate();
        if (o instanceof java.time.LocalDate d) return d;
        if (o instanceof java.time.LocalDateTime t) return t.toLocalDate();
        throw new IllegalArgumentException("날짜 값이 아님: " + o.getClass());
    }

    public static java.time.LocalTime time(Object o) {
        if (o == null) return null;
        if (o instanceof java.sql.Time t) return t.toLocalTime();
        if (o instanceof java.time.LocalTime t) return t;
        throw new IllegalArgumentException("시각 값이 아님: " + o.getClass());
    }

    /** 결과가 없으면 null */
    public static Long longOrNull(JdbcTemplate jdbc, String sql, Object... args) {
        List<Long> rows = jdbc.queryForList(sql, Long.class, args);
        return rows.isEmpty() ? null : rows.get(0);
    }
}
