package com.planon.server.common;

/**
 * 포인트·경험치·레벨 규칙. 앱 util/LevelRule.java 와 같은 값이어야 합니다.
 */
public final class LevelRule {
    private LevelRule() {
    }

    // ---------- 포인트 ----------
    public static final int PLAN_POINT = 10;
    public static final int FAIL_PENALTY = 10;

    // ---------- 레벨: 필요 경험치 = 15 + 2 × (L−1) ----------
    public static final int BASE_NEED = 15;
    public static final int NEED_STEP = 2;
    public static final int MAX_LEVEL = 50;
    public static final int LEVELS_PER_STAGE = 10;

    // ---------- 주간 경험치 ----------
    public static final int[] RANK_EXP = {60, 45, 35, 25};
    public static final int SOLO_RANK_EXP = 35;
    public static final int COMPLETION_FULL_EXP = 25;   // 달성률 100%
    public static final int COMPLETION_HIGH_EXP = 15;   // 80% 이상
    public static final int COMPLETION_HALF_EXP = 5;    // 50% 이상
    public static final int REVIEW_EXP = 15;            // 투표권 받은 인증에 모두 투표
    public static final int PARTY_GOAL_EXP = 10;        // 파티 전체 제출·인정률 70% 이상
    public static final double PARTY_GOAL_RATE = 0.7;

    /** 레벨 L → L+1 에 필요한 경험치 */
    public static int needForNext(int level) {
        return BASE_NEED + NEED_STEP * (level - 1);
    }

    /** 레벨 L 에 도달하는 데 필요한 누적 경험치 */
    public static int totalForLevel(int level) {
        int total = 0;
        for (int l = 1; l < level; l++) total += needForNext(l);
        return total;
    }

    public static int levelFor(int totalExp) {
        int level = 1;
        while (level < MAX_LEVEL && totalExp >= totalForLevel(level + 1)) level++;
        return level;
    }

    public static int stageFor(int level) {
        return Math.min(MAX_LEVEL / LEVELS_PER_STAGE, (level - 1) / LEVELS_PER_STAGE + 1);
    }

    public static int rankExp(int rank, int memberCount) {
        if (memberCount <= 1) return SOLO_RANK_EXP;
        if (rank < 1 || rank > RANK_EXP.length) return 0;
        return RANK_EXP[rank - 1];
    }

    public static int completionExp(int done, int total) {
        if (total == 0) return 0;
        double rate = done / (double) total;
        if (rate >= 1.0) return COMPLETION_FULL_EXP;
        if (rate >= 0.8) return COMPLETION_HIGH_EXP;
        if (rate >= 0.5) return COMPLETION_HALF_EXP;
        return 0;
    }

    /**
     * 투표 결과 판정 (자정에 한 번): 미인정 수가 인정 수보다 많으면 실패, 같으면 인정.
     * 투표하지 않은 사람은 어느 쪽에도 세지 않습니다.
     */
    public static boolean approved(int approves, int rejects) {
        return rejects <= approves;
    }
}
