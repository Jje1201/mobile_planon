package com.planon.server.notification;

import com.google.auth.oauth2.GoogleCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Firebase Cloud Messaging(HTTP v1)으로 푸시를 보냅니다.
 * application.properties 의 planon.fcm.credentials-file / project-id 가 비어 있으면 아무것도 하지 않습니다
 * (알림은 DB 알림함에 저장되고, 앱이 주기적으로 확인해 휴대폰 알림으로 보여줍니다).
 */
@Service
public class PushService {

    private static final Logger log = LoggerFactory.getLogger(PushService.class);
    private static final String SCOPE = "https://www.googleapis.com/auth/firebase.messaging";

    private final JdbcTemplate jdbc;
    private final String credentialsFile;
    private final String projectId;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private GoogleCredentials credentials;
    private boolean warned;

    public PushService(JdbcTemplate jdbc,
                       @Value("${planon.fcm.credentials-file:}") String credentialsFile,
                       @Value("${planon.fcm.project-id:}") String projectId) {
        this.jdbc = jdbc;
        this.credentialsFile = credentialsFile == null ? "" : credentialsFile.trim();
        this.projectId = projectId == null ? "" : projectId.trim();
    }

    public boolean isEnabled() {
        return !credentialsFile.isEmpty() && !projectId.isEmpty() && Files.exists(Path.of(credentialsFile));
    }

    /** DB 트랜잭션이 성공적으로 끝난 뒤에만 보냄 (롤백되면 푸시도 안 감) */
    public void sendAfterCommit(long userId, String type, String title, String body, Long planId) {
        if (!isEnabled()) {
            if (!warned) {
                log.info("FCM 설정이 없어 푸시는 보내지 않습니다 (알림함에는 저장됨)");
                warned = true;
            }
            return;
        }
        Runnable task = () -> executor.submit(() -> send(userId, type, title, body, planId));
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    task.run();
                }
            });
        } else {
            task.run();
        }
    }

    private void send(long userId, String type, String title, String body, Long planId) {
        try {
            List<String> tokens = jdbc.queryForList(
                    "SELECT fcm_token FROM device_tokens WHERE user_id = ?", String.class, userId);
            if (tokens.isEmpty()) return;
            String accessToken = accessToken();
            for (String token : tokens) {
                String json = "{\"message\":{\"token\":" + q(token)
                        + ",\"notification\":{\"title\":" + q(title) + ",\"body\":" + q(body) + "}"
                        + ",\"android\":{\"priority\":\"high\",\"notification\":{\"channel_id\":\"planon_default\"}}"
                        + ",\"data\":{\"type\":" + q(type) + ",\"planId\":" + q(planId == null ? "" : planId.toString())
                        + ",\"title\":" + q(title) + ",\"body\":" + q(body) + "}}}";
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create("https://fcm.googleapis.com/v1/projects/" + projectId + "/messages:send"))
                        .timeout(Duration.ofSeconds(15))
                        .header("Authorization", "Bearer " + accessToken)
                        .header("Content-Type", "application/json; charset=UTF-8")
                        .POST(HttpRequest.BodyPublishers.ofString(json))
                        .build();
                HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() == 404 || response.body().contains("UNREGISTERED")) {
                    jdbc.update("DELETE FROM device_tokens WHERE fcm_token = ?", token);
                } else if (response.statusCode() >= 300) {
                    log.warn("FCM 전송 실패 {}: {}", response.statusCode(), response.body());
                }
            }
        } catch (Exception e) {
            log.warn("푸시 전송 중 오류", e);
        }
    }

    private synchronized String accessToken() throws Exception {
        if (credentials == null) {
            try (InputStream in = new FileInputStream(credentialsFile)) {
                credentials = GoogleCredentials.fromStream(in).createScoped(List.of(SCOPE));
            }
        }
        credentials.refreshIfExpired();
        return credentials.getAccessToken().getTokenValue();
    }

    private static String q(String s) {
        if (s == null) return "\"\"";
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.append('"').toString();
    }
}
