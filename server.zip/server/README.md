# PLAN:ON 서버 (Spring Boot + MySQL)

- Spring Boot 4.1 · Java 17+ · JdbcTemplate · Flyway · MySQL 8
- 앱 API 전체: `PlanOn/docs/server-api.md` · 연결 방법·문제 해결: `PlanOn/docs/connect-guide.md`
- 요청 예시: `test-api.http` (IntelliJ HTTP Client)

## 실행

1. MySQL 에 `planon_db` DB, `planon` 계정 준비 (`application.properties` 의 값과 같게)
2. `ServerApplication` 실행 → `http://localhost:8080/api/health`
3. 시작할 때 Flyway 가 `V2__settlement_and_exp.sql`, `V3__achievements_and_records.sql`, `V4__remember_login.sql`, `V5__party_scope_and_withdraw.sql` 을 차례로 적용합니다 (V1 은 그대로).
   테이블은 cmd 에서 직접 만들지 마세요. 먼저 만들어 두면 V3 가 "이미 있는 테이블" 오류로 실패합니다.

## 패키지

```
com.planon.server
├─ auth/          회원가입·로그인 (BCrypt, 토큰 발급), 기기 저장 로그인(RememberService)
├─ user/          내 정보 (레벨, 주간·누적 포인트, 주간 순위), 회원 탈퇴(AccountService)
├─ party/         파티 만들기·가입·나가기·캐릭터 (한 사람 한 파티, 최대 4명)
├─ plan/          일정, 인증(사진 여러 장·추가), 투표, 자정 확정
├─ ranking/       주간·월간 순위, 주간 결산, 경험치 장부(ExpService)
├─ achievement/   하루 기록·연속 기록·파티 하루 기록, 업적 판정·조회, 월간 랭킹 확정
├─ notification/  알림함, FCM 푸시(선택)
├─ job/           매시 정각 작업(확정·미수행·결산·정리), 23:00 투표 알림, 시작 시 경험치 점검
├─ config/        토큰, 로그인 검사(AuthInterceptor), 사진 저장, 트랜잭션
└─ common/        규칙(LevelRule, TimeRule), DTO, 오류 처리
```

## 정기 작업 (한국 시간)

| 언제 | 하는 일 |
|---|---|
| 매시 0분 5초 | 투표 마감이 지난 인증 확정 → 지난 TODO 일정 미수행 → 주간 결산 → 하루 기록·업적 → 월간 랭킹 확정·월간 업적 → 90일 지난 알림 삭제 |
| 매일 23:00 | 아직 투표 안 한 사람에게 마감 알림 |
| 서버 시작 | 위 작업 한 번 + 경험치 장부 점검 (`planon.exp.auto-repair`) |

서버가 꺼져 있던 동안 밀린 확정·결산은 켜진 뒤 첫 실행에서 처리됩니다 (결산은 최근 8주까지).

## 경험치 일관성 (exp_events ↔ users)

- `exp_events` 가 원본, `users.total_exp / level` 은 합계를 담아둔 캐시
- 지급은 `ExpService.grant()` 한 곳에서만: 회원 행을 `FOR UPDATE` 로 잠그고 장부 INSERT 와 users UPDATE 를 **같은 트랜잭션**에서 실행
- `(user_id, settlement_id, source)` UNIQUE → 결산이 두 번 돌아도 두 번 지급되지 않음
- 서버 시작 때 장부 합계와 캐시를 비교해 다르면 장부 기준으로 고침. V2 이전에 들어간 경험치(장부 없음)는 지우지 않고 `ADJUST` 한 줄로 옮김
